package com.umeng.example.xp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.umeng.example.R;
import com.umeng.ui.BaseSinglePaneActivity;
import com.umeng.xp.common.ExchangeConstants;
import com.umeng.xp.common.ExchangeStrings;
import com.umeng.xp.controller.ExchangeDataService;
import com.umeng.xp.view.ExchangeViewManager;

/**
 * 小把手展示样例
 * @author Lucas Xu
 *
 */
public class HandlerExample extends BaseSinglePaneActivity {
	private static ExchangeDataService exchangeDataService2;

	@Override
	protected Fragment onCreatePane() {
		return new HandlerExampleFragment();
	}
	
	public static class HandlerExampleFragment extends Fragment{
		Context mContext;
		
		@Override
	    public void onAttach(Activity activity) {
	        super.onAttach(activity);
	        mContext = activity;
	    }
		
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View root = inflater.inflate(
					R.layout.umeng_example_xp_banner_activity, container,
					false);
			
			/*		// 应用联盟集成方式， 请在AndroidManifest.xml中添加 UMENG_APPKEY
			ExchangeDataService exchangeDataService = new ExchangeDataService();
			ExchangeViewManager viewMgr = new ExchangeViewManager(this, exchangeDataService);
			viewMgr.addView(parent, ExchangeConstants.type_image_entry);
	*/		
			
			/**
			 * 两种方式的逻辑不同 模式1 请求数据在现实ImageView  之前 模式2 请求数据将在ImageView 点击之后
			 */
			
			//把手图片服务器提供 云端不配置图片将不显示
			final ExchangeDataService exchangeDataService = new ExchangeDataService();
			ImageView imageview = (ImageView) root.findViewById(R.id.imageview);
			new ExchangeViewManager(mContext, exchangeDataService)
				.addView(ExchangeConstants.type_list_curtain, imageview);
			
			//SDK定义图片，将无视云端配置图片
			exchangeDataService2 = new ExchangeDataService();
			ImageView imageview2 = (ImageView) root.findViewById(R.id.imageview2);
			ExchangeViewManager viewManager = new ExchangeViewManager(mContext, exchangeDataService2);
			viewManager.addView(ExchangeConstants.type_list_curtain, imageview2,mContext.getResources().getDrawable(R.drawable.umeng_example_handler));
		
			return root;
		}
		
	}
	
	
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}
}