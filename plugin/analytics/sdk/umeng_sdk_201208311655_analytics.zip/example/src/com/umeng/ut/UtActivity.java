package com.umeng.ut;

import android.app.Activity;
import android.os.Bundle;

public class UtActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
//		setContentView(R.layout.umeng_home);
//
//		String url = "http://ex.puata.info/uploads/cross_promotions/logos/4e4facee431fe361fc0000aa.png";
//		final ImageView iv = (ImageView) this.findViewById(com.umeng.example.R.id.imageView1);		
//    	ResUtil.bindDrawable(this, iv, url, false);
//		//Assert.assertNotNull(iv.getDrawable());
//		ResUtil.bindDrawable(this, iv, url, true);		
	}
}
