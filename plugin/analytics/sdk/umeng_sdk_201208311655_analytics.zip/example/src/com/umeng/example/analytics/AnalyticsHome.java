package com.umeng.example.analytics;

import java.util.HashMap;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import android.webkit.WebChromeClient;
import android.webkit.WebView;


import com.umeng.analytics.MobclickAgent;
import com.umeng.analytics.MobclickAgentJSInterface;
import com.umeng.example.R;
import com.umeng.ui.BaseSinglePaneActivity;

public class AnalyticsHome extends BaseSinglePaneActivity {	
	private Context mContext;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mContext = this;	
		MobclickAgent.setDebugMode(true);
		
//		MobclickAgent.setAutoLocation(true);
//		MobclickAgent.setSessionContinueMillis(5000);
//		MobclickAgent.setUpdateOnlyWifi(false);
		
		MobclickAgent.onError(this);
		//MobclickAgent.onError(this);
		//MobclickAgent.updateOnlineConfig(this);
		
		MobclickAgent.updateOnlineConfig(this);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		MobclickAgent.onResume(mContext);
	}
	
	@Override
	public void onPause() {
		super.onPause();
		MobclickAgent.onPause(mContext);
	}
	

	@Override
	protected Fragment onCreatePane() {
		return new AnalyticsHomeDashboardFragment();	
	}
	
	public static class AnalyticsHomeDashboardFragment extends Fragment {
		Context mContext;		
		
		private Button online_config;
		private Button event;
		private Button kv_event;
		
		private Button event_begin;
		private Button event_end;
		private Button event_duration;
		private Button crash;
		private WebView webview;

		private View.OnClickListener listener = new View.OnClickListener() {
			
			public void onClick(View v) {
		
				int id = v.getId();
				if(id == R.id.umeng_example_analytics_online_config){
					
					String onlineParams= MobclickAgent.getConfigParams(mContext, "abc");//the demo param's key is 'abc'
					if(onlineParams.equals("")){
						Toast.makeText(mContext, "Get No Online Params", Toast.LENGTH_SHORT).show();
					}else
						Toast.makeText(mContext, "Online Params:"+ onlineParams, Toast.LENGTH_SHORT).show();
				}else if(id == R.id.umeng_example_analytics_event){
					
					MobclickAgent.onEvent(mContext, "click");
					MobclickAgent.onEvent(mContext, "click", "button");
					
				}else if(id == R.id.umeng_example_analytics_ekv){
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("type", "popular");
					map.put("artist", "JJLin");
					
					MobclickAgent.onEvent(mContext, "music", map);
				}else if(id == R.id.umeng_example_analytics_duration){
					
					// We need manual to compute the Events duration 
					MobclickAgent.onEventDuration(mContext, "book", 12000);
					MobclickAgent.onEventDuration(mContext, "book", "chapter1", 23000);
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("type", "popular");
					map.put("artist", "JJLin");
					
					MobclickAgent.onEventDuration(mContext, "music", map, 2330000);
			
					
				}else if(id == R.id.umeng_example_analytics_event_begin){
					//Log.i("duration", "start");
					//when the events start
					MobclickAgent.onEventBegin(mContext, "music");
					
					MobclickAgent.onEventBegin(mContext, "music", "one");
					
					HashMap<String, String> map = new HashMap<String, String>();
					map.put("type", "popular");
					map.put("artist", "JJLin");
					
					MobclickAgent.onKVEventBegin(mContext, "music", map, "flag0");
					
				}else if(id == R.id.umeng_example_analytics_event_end){
					
					MobclickAgent.onEventEnd(mContext, "music");
					MobclickAgent.onEventEnd(mContext, "music", "one");	
					
					MobclickAgent.onKVEventEnd(mContext, "music", "flag0");
				}else if(id == R.id.umeng_example_analytics_make_crash){
					"123".substring(10);
				}
			}
		};
		
		
		@Override
	    public void onAttach(Activity activity) {
	        super.onAttach(activity);
	        mContext = activity;
	    }
		
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View root = inflater.inflate(
					R.layout.umeng_example_analytics, container,
					false);
				findViews(root);
				//important , so that you can use js to call Uemng APIs
				new MobclickAgentJSInterface(mContext, webview, new WebChromeClient());
				webview.loadUrl("file:///android_asset/demo.html");
			return root;
		}
		
		private void findViews(View root){
			online_config= (Button) root.findViewById(R.id.umeng_example_analytics_online_config);
			event= (Button) root.findViewById(R.id.umeng_example_analytics_event);
			kv_event = (Button) root.findViewById(R.id.umeng_example_analytics_ekv);

			event_begin = (Button) root.findViewById(R.id.umeng_example_analytics_event_begin);
			event_end  = (Button) root.findViewById(R.id.umeng_example_analytics_event_end);
			event_duration = (Button) root.findViewById(R.id.umeng_example_analytics_duration);
			crash = (Button)root.findViewById(R.id.umeng_example_analytics_make_crash);
			
			online_config.setOnClickListener(listener);
			event.setOnClickListener(listener);
			kv_event.setOnClickListener(listener);
			
			event_begin.setOnClickListener(listener);
			event_end.setOnClickListener(listener);
			event_duration.setOnClickListener(listener);
			crash.setOnClickListener(listener);
			
			webview = (WebView) root.findViewById(R.id.webview);
		}
	}
}