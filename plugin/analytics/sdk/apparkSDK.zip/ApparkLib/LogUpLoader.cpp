//
//  LogUpLoader.cpp
//  ApparkTest
//
//  Created by steve fan on 12-2-9.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#include <iostream>
#include "LogUpLoader.h"
#include "Device_Wrapper.h"
#include "CommonDef.h"
#include "ApparkSDK.h"

using namespace ApparkSDK;

static void notifyFunc(void *pClass, void* pHttpOperator, bool val)
{
    CHttpRequest *rap = (CHttpRequest *)pClass;
    rap->getSuccesfulInfo(val);
}


CLogUploader::CLogUploader()
{
//    m_pHttpOperator = new CHttpRequest();
//    m_pHttpOperator->SetRequestURL(APPPARK_DEFAULTURL);
//    CALLBACK_FUNC func = notifyFunc;
//    m_pHttpOperator->SetNotifyFunc(func);
}


CLogUploader::~CLogUploader()
{
//    delete m_pHttpOperator;
//    m_pHttpOperator = NULL;
}


inline void CLogUploader::FormatTime(time_t time, std::string& outputString)
{
    tm * key_tm;
    key_tm = localtime(&time);
    char timeStamp[32];
    sprintf(timeStamp, "%04d-%02d-%02d%s%02d:%02d:%02d", key_tm->tm_year+1900, 
            key_tm->tm_mon + 1, key_tm->tm_mday,"%20", 
            key_tm->tm_hour,key_tm->tm_min, key_tm->tm_sec);
    string temp = string(timeStamp);
    outputString = temp;
}


inline long CLogUploader::filesize(FILE *stream)
{
    long curpos, length;
    curpos = ftell(stream);
    fseek(stream, 0L, SEEK_END);
    length = ftell(stream);
    fseek(stream, curpos, SEEK_SET);
    return length;
}


bool CLogUploader::UploadGameDataFile(char * fullpath, int transfertype, void * UserParam)
{
    CApparkSDK * apkSDK = NULL;
    apkSDK = (CApparkSDK *)m_pApparkSDK;
    bool bIsUsing3G = (0 == apkSDK->m_cDeviceInfo.m_sNetWork_type.compare(CURRENT_NET_CONNECTION_3G));
    if ((apkSDK->m_cDeviceInfo.m_sNetWork_type.compare(CURRENT_NET_CONNECTION_NONE) == 0) ||
        (bIsUsing3G && !apkSDK->m_pSettingManager->Check3GLimition()))
    {
        return false;
    }
    
    char *message = GetFileContent(fullpath);
    if(!message)
        return false;

    std::string deviceString;
    deviceString.append("m=D&a=liberty&udid=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sDeviceId.c_str());
    deviceString.append("&mac=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sMacAdress.c_str());
    deviceString.append("&appid=");
    deviceString.append(apkSDK->m_strAppID);
    deviceString.append("&appversion=");
    deviceString.append(apkSDK->m_strAppVersion);
    deviceString.append("&sdkversion=");
    deviceString.append(apkSDK->m_strSDKVersion);

    deviceString.append("&timestamp=");
    time_t timeNow= time(0);
    string sTimeStamp;
    FormatTime(timeNow, sTimeStamp);
    deviceString.append(sTimeStamp);

    deviceString.append("&data=");
    int nLength = 0;
    char *outBuffer = NULL;
    nLength =  CEncryptionManager::Base64Encode((const unsigned char *)message, NULL, strlen(message));
    outBuffer = (char *)malloc(nLength + 4);
    ZeroMemory(outBuffer, nLength + 4);
    CEncryptionManager::Base64Encode((const unsigned char *)message, ( unsigned char *)outBuffer, strlen(message));    
    deviceString.append(outBuffer);

    free(outBuffer);
    free(message);

    message = (char *)deviceString.c_str();

    bool bRet = UpLoadMessage(message, (char *)APPPARK_LIBERYURL);
    if (bRet && bIsUsing3G)
        apkSDK->m_pSettingManager->Update3GUploadingSize((unsigned int)nLength);

    return bRet;
}


bool CLogUploader::UploadMassDataFile(char * fullpath, int transfertype, void * UserParam)
{
    CApparkSDK * apkSDK = NULL;
    apkSDK = (CApparkSDK *)m_pApparkSDK;
    bool bIsUsing3G = (0 == apkSDK->m_cDeviceInfo.m_sNetWork_type.compare(CURRENT_NET_CONNECTION_3G));
    if ((apkSDK->m_cDeviceInfo.m_sNetWork_type.compare(CURRENT_NET_CONNECTION_NONE) == 0) ||
        (bIsUsing3G && !apkSDK->m_pSettingManager->Check3GLimition()))
    {
        return false;
    }
    
    char *message = GetFileContent(fullpath);
    if(!message)
        return false;
    
    std::string deviceString;
    deviceString.append("m=D&a=liberty&mass=1&udid=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sDeviceId.c_str());
    deviceString.append("&mac=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sMacAdress.c_str());
    deviceString.append("&appid=");
    deviceString.append(apkSDK->m_strAppID);
    deviceString.append("&appversion=");
    deviceString.append(apkSDK->m_strAppVersion);
    deviceString.append("&sdkversion=");
    deviceString.append(apkSDK->m_strSDKVersion);
    
    deviceString.append("&timestamp=");
    time_t timeNow= time(0);
    string sTimeStamp;
    FormatTime(timeNow, sTimeStamp);
    deviceString.append(sTimeStamp);
    
    deviceString.append("&data=");
    int nLength = 0;
    char *outBuffer = NULL;
    nLength =  CEncryptionManager::Base64Encode((const unsigned char *)message, NULL, strlen(message));
    outBuffer = (char *)malloc(nLength + 4);
    ZeroMemory(outBuffer, nLength + 4);
    CEncryptionManager::Base64Encode((const unsigned char *)message, ( unsigned char *)outBuffer, strlen(message));    
    deviceString.append(outBuffer);
    
    free(outBuffer);
    free(message);
    
    message = (char *)deviceString.c_str();
    
    bool bRet = UpLoadMessage(message, (char *)APPPARK_LIBERYURL);
    if (bRet)
        apkSDK->m_pSettingManager->Update3GUploadingSize((unsigned int)nLength);

    return bRet;
}


bool CLogUploader::UploadAGDFile(char * fullpath, int transfertype, void * UserParam)
{
    CApparkSDK * apkSDK = NULL;
    apkSDK = (CApparkSDK *)m_pApparkSDK;
    if (apkSDK->m_cDeviceInfo.m_sNetWork_type.compare(CURRENT_NET_CONNECTION_NONE) == 0)
    {
        return false;
    }

    char *message = GetFileContent(fullpath);
    if (!message)
        return false;

    std::string deviceString;
    deviceString.append("m=D&a=session&udid=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sDeviceId.c_str());
    deviceString.append("&mac=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sMacAdress.c_str());
    deviceString.append("&appid=");
    deviceString.append(apkSDK->m_strAppID);
    deviceString.append("&appversion=");
    deviceString.append(apkSDK->m_strAppVersion);
    deviceString.append("&sdkversion=");
    deviceString.append(apkSDK->m_strSDKVersion);
    deviceString.append("&timestamp=");
    time_t timeNow= time(0);
    string sTimeStamp;
    FormatTime(timeNow, sTimeStamp);
    deviceString.append(sTimeStamp);

    deviceString.append("&data=");
    int nLength = 0;
    char *outBuffer = NULL;
    nLength =  CEncryptionManager::Base64Encode((const unsigned char *)message, NULL, strlen(message));
    outBuffer = (char *)malloc(nLength + 4);
    ZeroMemory(outBuffer, nLength + 4);
    CEncryptionManager::Base64Encode((const unsigned char *)message, (unsigned char *)outBuffer, strlen(message));
    deviceString.append(outBuffer);

#ifdef DEBUG
    printf("deviceString si %s\r\n", deviceString.c_str());
#endif

    free(outBuffer);
    free(message);
    message = (char *)deviceString.c_str();

    return UpLoadMessage(message, (char *)APPPARK_SESSIONURL);
}


bool CLogUploader::UploadFile(char * fullpath, int transfertype, void * UserParam)
{
    CApparkSDK * apkSDK = NULL;
    apkSDK = (CApparkSDK *)m_pApparkSDK;
    bool bIsUsing3G = (0 == apkSDK->m_cDeviceInfo.m_sNetWork_type.compare(CURRENT_NET_CONNECTION_3G));
    if ((apkSDK->m_cDeviceInfo.m_sNetWork_type.compare(CURRENT_NET_CONNECTION_NONE) == 0) ||
        (bIsUsing3G && !apkSDK->m_pSettingManager->Check3GLimition()))
    {
        return false;
    }

    char *message = GetFileContent(fullpath);
    CDeviceInfo deviceInfo;
    std::string deviceString;
    deviceString.append("m=D&a=liberty&udid=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sDeviceId.c_str());
    deviceString.append("&mac=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sMacAdress.c_str());
    deviceString.append("&appid=");
    deviceString.append(apkSDK->m_strAppID);
    deviceString.append("&appversion=");
    deviceString.append(apkSDK->m_strAppVersion);
    deviceString.append("&sdkversion=");
    deviceString.append(apkSDK->m_strSDKVersion);
    deviceString.append("&timestamp=");
    time_t timeNow= time(0);
    string sTimeStamp;
    FormatTime(timeNow, sTimeStamp);
    deviceString.append(sTimeStamp);

    deviceString.append("&data=");
    
    int nLength = 0;
    char *outBuffer = NULL;
    nLength =  CEncryptionManager::Base64Encode((const unsigned char *)message, NULL, strlen(message));
    outBuffer = (char *)malloc(nLength + 4);
    ZeroMemory(outBuffer, nLength + 4);
    CEncryptionManager::Base64Encode((const unsigned char *)message, ( unsigned char *)outBuffer, strlen(message));

    deviceString.append(outBuffer);
    printf("deviceString si %s\r\n\n", deviceString.c_str());
    free(message);
    message = (char *)deviceString.c_str();
     
    bool bRet = UpLoadMessage(message, (char *)APPPARK_GATHERURL);
    if (bIsUsing3G && bRet)
        apkSDK->m_pSettingManager->Update3GUploadingSize((unsigned int)nLength);

    return bRet;
}


bool CLogUploader::UpLoadMessage(char *message, char *requestURL)
{
    CHttpRequest request;
    request.SetRequestURL(requestURL);
    CALLBACK_FUNC func = notifyFunc;
    request.SetNotifyFunc(func);
    request.SetMessageToServer(message);
    request.m_iOperationMethod = iOperationMethodPost;
    bool requestRet = request.StartRequest(cCommunicationTypeSync, NULL);

#ifdef DEBUG
    printf("the responscode is %lu, receiveData is %s\r\n\n", request.m_iOperationResult, 
           request.m_cReceivedData.c_str());
    if (requestRet)
    {
        printf("post successful!\r\n");
    }
    else
    {
        printf("post faild!\r\n");
    }
#endif

    if (request.m_iOperationResult == HttpStatusCodeOK)
    {
        if (CheckHttpResult(&request))
        {
            return true;
        }
    }
    return false;
}


bool CLogUploader::UpLoadMessage(char *message, char *requestURL, OperationMethod method)
{
    CHttpRequest request;
    request.SetRequestURL(requestURL);
    CALLBACK_FUNC func = notifyFunc;
    request.SetNotifyFunc(func);
    request.m_iOperationMethod = method;
    request.StartRequest(cCommunicationTypeSync, NULL);

#ifdef DEBUG
    printf("the responscode is %lu, receiveData is %s\r\n\n", request.m_iOperationResult, 
           request.m_cReceivedData.c_str());
#endif

    if (request.m_iOperationResult == HttpStatusCodeOK)
    {
        if (CheckHttpResult(&request))
        {
            return true;
        }
    }
    return false;
}

/*
bool CLogUploader::UpLoadMessage(char *message, CHttpRequest *pHttpRequest)
{
    pHttpRequest->SetMessageToServer(message);
    pHttpRequest->m_iOperationMethod = iOperationMethodPost;
    bool requestRet = pHttpRequest->StartRequest(cCommunicationTypeSync, NULL);

#ifdef DEBUG
    printf("the responscode is %lu, receiveData is %s\r\n\n", pHttpRequest->m_iOperationResult, 
           pHttpRequest->m_cReceivedData.c_str());
    if (requestRet)
    {
        printf("post successful!\r\n");
    }
    else
    {
        printf("post faild!\r\n");
    }
#endif
    
    if (pHttpRequest->m_iOperationResult == HttpStatusCodeOK)
    {
        if (CheckHttpResult(pHttpRequest))
        {
            return true;
        }
    }
    return false;
}*/


bool CLogUploader::UploadMessage(char *message)
{
    CHttpRequest cHttpOperator;
    cHttpOperator.SetMessageToServer(message);
    cHttpOperator.m_iOperationMethod = iOperationMethodPost;
    bool requestRet = cHttpOperator.StartRequest(cCommunicationTypeAsync, NULL);

#ifdef DEBUG
    printf("the responscode is %lu, receiveData is %s\r\n", cHttpOperator.m_iOperationResult, 
           cHttpOperator.m_cReceivedData.c_str());
    printf("the responscode is %lu, receiveData is %s\r\n\n", cHttpOperator.m_iOperationResult, 
           cHttpOperator.m_cReceivedData.c_str());

    if (requestRet)
    {
        printf("post successful!\r\n");
    }
    else
    {
        printf("post faild!\r\n");
    }
#endif
    
    if (cHttpOperator.m_iOperationResult == HttpStatusCodeOK)
    {
        if (CheckHttpResult(&cHttpOperator))
        {
            return true;
        }
    }

    return false;
}


//appversion,sdkversion,area,language,network_type,timestamp
bool CLogUploader::UploadGatherInfo()
{
    CApparkSDK * apkSDK = NULL;
    apkSDK = (CApparkSDK *)m_pApparkSDK;
    if (apkSDK->m_cDeviceInfo.m_sNetWork_type.compare(CURRENT_NET_CONNECTION_NONE) == 0)
    {
        return false;
    }

    std::string deviceString;
    deviceString.append(APPPARK_GATHERURL);
    deviceString.append("&udid=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sDeviceId.c_str());
    deviceString.append("&mac=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sMacAdress.c_str());
    deviceString.append("&appid=");
    deviceString.append(apkSDK->m_strAppID);
    deviceString.append("&appversion=");
    deviceString.append(apkSDK->m_strAppVersion);
    deviceString.append("&sdkversion=");
    deviceString.append(apkSDK->m_strSDKVersion);

    deviceString.append("&timestamp="); 
    time_t timeNow= time(0);
    string sTimeStamp;
    FormatTime(timeNow, sTimeStamp);
    deviceString.append(sTimeStamp);

    deviceString.append("&area=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sArea);
    deviceString.append("&language=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sLanguage);
    deviceString.append("&network_type=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sNetWork_type);
    deviceString.append("&deviceToken=");
    deviceString.append(apkSDK->m_strDeviceToken);
    deviceString.append("&osversion=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sOsversion);
    deviceString.append("&deviceType=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sDeviceType);
    deviceString.append("&jailbreak=");
    deviceString.append(apkSDK->m_cDeviceInfo.m_sJailbreak);

#if DEBUG
    printf("the gather info is %s", deviceString.c_str());
#endif

    char *message = (char *)deviceString.c_str();
    bool ret = UpLoadMessage(message, message, iOperationMethodGet);
    return ret;
}


char * CLogUploader::GetFileContent(char *fullPath)
{
    FILE * pFile;
    pFile = fopen (fullPath,"rb");
    char *message = NULL;
    if (pFile!=NULL)
    {
        long flen = filesize(pFile);
        if (flen > 5)
        {
            message = (char *)malloc(flen+1);
            if (message == NULL)
            {
                fclose(pFile);
                return message;
            }

            fseek(pFile, 0L, SEEK_SET);
            fread(message, flen, 1, pFile);
            message[flen] = 0;
            fclose(pFile);
        }
        else
        {
            fclose(pFile);
            remove(fullPath);
        }
    }
    return message;
}


bool  CLogUploader::CheckHttpResult(CHttpRequest *httpOperator)
{
    bool bRet = false;
    CDictionaryDataGather jsonReader ;
    jsonReader.InitWithDescription(httpOperator->m_cReceivedData.c_str());
    const char * pszStatus = jsonReader.GetItemStringValue("status");
    if (pszStatus)
    {
        string strRet;
        strRet.assign(pszStatus);
        transform(strRet.begin(), strRet.end(), strRet.begin(), ::tolower);
        if (0 == strRet.compare("ok"))
            bRet = true;
    }
    return bRet;
}


void CLogUploader::UploadResultNotice(CHttpRequest *HttpOperator, void * param, bool success)
{
    
}

