//
//  HttpRequest.cpp
//  ApparkTest
//
//  Created by steve fan on 12-2-7.
//  Contributed by lvyile on 12-2-8.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#include <iostream>
#include "HttpRequest.h"

using namespace ApparkSDK;

void * AsynThreadFunc(void * param);

void * AsynThreadFunc(void * param)
{
    bool bRet = false;

    CHttpRequest * pHttpOperator = (CHttpRequest *)param;

    if (iOperationMethodPost == pHttpOperator->m_iOperationMethod)
    {
        curl_easy_setopt( pHttpOperator->m_curlHandle, CURLOPT_TIMEOUT, 60L);
        if( pHttpOperator->performPost(pHttpOperator->m_sRequestURL, pHttpOperator->m_sMessageToServer) )
        {
            std::string webResponseStr = "";
            pHttpOperator->getLastWebResponse( webResponseStr );                
            pHttpOperator->m_cReceivedData = webResponseStr;
            bRet = true;
        }
    }
    else if (iOperationMethodGet == pHttpOperator->m_iOperationMethod)
    {
        curl_easy_setopt( pHttpOperator->m_curlHandle, CURLOPT_TIMEOUT, 60L);
        if( pHttpOperator->performGet( pHttpOperator->m_sRequestURL ) )
        {
            std::string webResponseStr = "";
            pHttpOperator->getLastWebResponse( webResponseStr );
            pHttpOperator->m_cReceivedData = webResponseStr;
            bRet = true;
        }
    }

    if (pHttpOperator->m_fCallBackFunc)
    {
        pHttpOperator->m_fCallBackFunc(pHttpOperator->m_pCallbackParam, param, bRet);
    }

    return NULL;
}


/*++
 * @method: CHttpRequest::CHttpRequest
 *
 * @description: constructor
 *
 * @input: none
 *
 * @output: none
 *
 *--*/
CHttpRequest::CHttpRequest():
m_curlHandle( NULL )
{
    /* Clear callback buffers */
    clearCurlCallbackBuffers();
    
    /* Initialize cURL */
    m_curlHandle = curl_easy_init();
    if( NULL == m_curlHandle )
    {
        GetErrorMessage();
    }
    m_strLocalFilename.clear();
}


/*++
 * @method: CHttpRequest::~CHttpRequest
 *
 * @description: destructor
 *
 * @input: none
 *
 * @output: none
 *
 *--*/
CHttpRequest::~CHttpRequest()
{
    /* Cleanup cURL */
    if( m_curlHandle )
    {
        curl_easy_cleanup( m_curlHandle );
        m_curlHandle = NULL;
    }
}


/*++
 * @method: CHttpRequest::isCurlInit
 *
 * @description: method to check if cURL is initialized properly
 *
 * @input: none
 *
 * @output: true if cURL is intialized, otherwise false
 *
 *--*/
bool CHttpRequest::isCurlInit()
{
    return ( NULL != m_curlHandle ) ? true : false;
}


void CHttpRequest::SetRequestURL(const char *url)
{
#ifdef DEBUG
    printf("\nSet URL : %s\n\n", url);
#endif
    m_sRequestURL.clear();
    m_sRequestURL.assign(url);
}


void CHttpRequest::SetMessageToServer(const char *message){
    m_sMessageToServer.clear();
    m_sMessageToServer.assign(message);
#if DEBUG
//    printf("m_sMessageToServer is %s\r\n\n",m_sMessageToServer.c_str());
#endif
    
}


void CHttpRequest::SetNotifyFunc(CALLBACK_FUNC func)
{
    m_fCallBackFunc = func;
}


void CHttpRequest::getSuccesfulInfo(bool ret)
{
    if (ret)
    {
#if DEBUG
        printf("call backTest successful\r\n");
#endif
    }
    else{
#if DEBUG
        printf("call backTest faild\r\n");
#endif
    }
}


bool CHttpRequest::StartRequest(CommunicationType type, void * pCallBackParam)
{
#ifdef DEBUG
    printf("\n\n Start Request : %s\n\n", m_sRequestURL.c_str());
#endif
    bool bRet = false;
    m_cReceivedData = "";
    if (cCommunicationTypeSync == type)
    {    //同步 
        if (iOperationMethodPost == m_iOperationMethod)
        {
            curl_easy_setopt( m_curlHandle, CURLOPT_TIMEOUT, 60L);
            if( performPost(m_sRequestURL, m_sMessageToServer) )
            {
                std::string webResponseStr = "";
                getLastWebResponse( webResponseStr );                
                m_cReceivedData = webResponseStr;
                bRet = true;
            }
        }
        else if (iOperationMethodGet == m_iOperationMethod)
        {
            curl_easy_setopt( m_curlHandle, CURLOPT_TIMEOUT, 60L);
            if( performGet( m_sRequestURL ) )
            {
                std::string webResponseStr = "";
                getLastWebResponse( webResponseStr );
                m_cReceivedData = webResponseStr;
                bRet = true;
            }
        }
    }
    else if (cCommunicationTypeAsync == type)
    {
        m_pCallbackParam = pCallBackParam;
        int nRet = pthread_create(&m_pTID,
                                 (const pthread_attr_t *)NULL,
                                 &AsynThreadFunc,
                                 (void *)this);
        bRet = (nRet == 0);
    }

    return bRet;
}


void CHttpRequest::CancelRequest()
{
    //只供异步实现，同步实现没意义 
    curl_easy_pause(m_curlHandle, CURLPAUSE_ALL);
    curl_easy_reset(m_curlHandle);    
}


const char * CHttpRequest::GetErrorMessage()
{
    m_errorBuffer[CHttpRequestDefaults::CHTTPREQUEST_DEFAULT_BUFFSIZE-1] = CHttpRequestDefaults::CHTTPREQUEST_EOS;
    m_sErrorMessage.assign(m_errorBuffer);
    return m_errorBuffer;
}


void CHttpRequest::GetStatusCode()
{
    unsigned long httpStatusCode = 0;
    curl_easy_getinfo( m_curlHandle, CURLINFO_HTTP_CODE, &httpStatusCode );
    m_iOperationResult = httpStatusCode;    
}


/*++
 * @method: CHttpRequest::prepareStandardParams
 *
 * @description: method to set standard params into cURL. this is an internal method.
 *               CHttpRequest users should not use this method.
 *
 * @input: none
 *
 * @output: none
 *
 * @remarks: internal method
 *
 *--*/
void CHttpRequest::prepareStandardParams()
{
    /* Restore any custom request we may have */
    curl_easy_setopt( m_curlHandle, CURLOPT_CUSTOMREQUEST, NULL );
    
    /* Clear callback and error buffers */
    clearCurlCallbackBuffers();

    /* Set buffer to get error */
    curl_easy_setopt( m_curlHandle, CURLOPT_ERRORBUFFER, m_errorBuffer );
        
    /* Prepare cURL callback data and error buffer */
    /* Set callback function to get response */
    curl_easy_setopt( m_curlHandle, CURLOPT_WRITEFUNCTION, curlCallback );
    curl_easy_setopt( m_curlHandle, CURLOPT_WRITEDATA, this );
}


/*++
 * @method: CHttpRequest::performGet
 *
 * @description: method to send http GET request. this is an internal method.
 *               CHttpRequest users should not use this method.
 *
 * @input: getUrl - url
 *
 * @output: none
 *
 * @remarks: internal method
 *
 *--*/
bool CHttpRequest::performGet( const std::string& getUrl )
{
#ifdef DEBUG
    printf("\n\n Perform Get : %s\n\n", getUrl.c_str());
#endif
    /* Prepare standard params */
    prepareStandardParams();
    
    /* Set http request and url */
    curl_easy_setopt( m_curlHandle, CURLOPT_NOSIGNAL, 1);
    curl_easy_setopt( m_curlHandle, CURLOPT_HTTPGET, 1 );
    curl_easy_setopt( m_curlHandle, CURLOPT_TIMEOUT, 60L);
    curl_easy_setopt( m_curlHandle, CURLOPT_URL, getUrl.c_str() );
    
    /* Send http request */
    if( CURLE_OK == curl_easy_perform( m_curlHandle ) )
    {
        GetStatusCode();
        return m_iOperationResult == HttpStatusCodeOK;
    }

    GetStatusCode();    

    return false;
}


bool CHttpRequest::performDownload(const std::string& fileUrl, const std::string& localFile)
{
#ifdef DEBUG
    printf("\n\nPerform Download : %s to : %s", fileUrl.c_str(), localFile.c_str());
#endif
    /* Check paramters */
    if (fileUrl.empty() || localFile.empty())
        return false;

    m_strLocalFilename = localFile;
    m_nWriteSize = 0;
    m_pFileHandle = fopen(m_strLocalFilename.c_str(), "wb+");
    if (!m_pFileHandle)
        return false;

    /* Restore any custom request we may have */
    curl_easy_setopt(m_curlHandle, CURLOPT_CUSTOMREQUEST, NULL);

    /* Clear callback and error buffers */
    clearCurlCallbackBuffers();

    /* Set buffer to get error */
    curl_easy_setopt(m_curlHandle, CURLOPT_ERRORBUFFER, m_errorBuffer);

    /* Prepare cURL callback data and error buffer */
    /* Set callback function to get response */
    curl_easy_setopt(m_curlHandle, CURLOPT_WRITEFUNCTION, curlDownloadCallback);
    curl_easy_setopt(m_curlHandle, CURLOPT_WRITEDATA, this);

    /* Set http request and url */
    curl_easy_setopt(m_curlHandle, CURLOPT_HTTPGET, 1);
    curl_easy_setopt(m_curlHandle, CURLOPT_URL, fileUrl.c_str());

    curl_easy_setopt( m_curlHandle, CURLOPT_NOSIGNAL, 1);

    /* Send http request */
    if(CURLE_OK == curl_easy_perform(m_curlHandle))
    {
        GetStatusCode();
        fseek(m_pFileHandle, 0, SEEK_END);
        int nSaveFileSize = ftell(m_pFileHandle);
        fclose(m_pFileHandle);
        return (HttpStatusCodeOK == m_iOperationResult && nSaveFileSize == m_nWriteSize);
    }

    fclose(m_pFileHandle);
    GetStatusCode();

    return false;
}

/*++
 * @method: CHttpRequest::performPost
 *
 * @description: method to send http POST request. this is an internal method.
 *               CHttpRequest users should not use this method.
 *
 * @input: postUrl - url,
 *         dataStr - data to be posted
 *
 * @output: none
 *
 * @remarks: internal method
 *
 *--*/
bool CHttpRequest::performPost( const std::string& postUrl, std::string dataStr )
{
#ifdef DEBUG
    printf("Perform Post : %s to %s", dataStr.c_str(), postUrl.c_str());
#endif
    /* Prepare standard params */
    prepareStandardParams();
    
    /* urlencode data */
    if( dataStr.length() )
    {
        /* Data should already be urlencoded once */
//        std::string dataKey;
//        std::string dataValue;
//        size_t nPos = dataStr.find_first_of( "=" );
//        if( std::string::npos != nPos )
//        {
//            dataKey = dataStr.substr( 0, nPos );
//            dataValue = dataStr.substr( nPos + 1 );
//            dataValue = urlencode( dataValue );
//            dataStr.assign( dataKey );
//            printf("dataKey[%s]\n", dataKey.c_str());
//            printf("dataValue[%s]\n\n", dataValue.c_str());            
//            dataStr.append( "=" );
//            dataStr.append( dataValue );
//        }
    }
    
    /* Set http request, url and data */
    curl_easy_setopt( m_curlHandle, CURLOPT_POST, 1 );
    curl_easy_setopt( m_curlHandle, CURLOPT_NOSIGNAL, 1);
    curl_easy_setopt( m_curlHandle, CURLOPT_URL, postUrl.c_str() );
    if( dataStr.length() )
    {
        curl_easy_setopt( m_curlHandle, CURLOPT_POSTFIELDS, dataStr.c_str() );
    }
    
    
    /* Send http request */
    if( CURLE_OK == curl_easy_perform( m_curlHandle ) )
    {
        GetStatusCode();        
        return HttpStatusCodeOK == m_iOperationResult;
    }

    GetStatusCode();
    
    return false;
}


bool CHttpRequest::performPost( const std::string& postUrl, const char * pszPostData, size_t length)
{
    bool bRet = false;
    if (pszPostData && length > 0)
    {
        curl_easy_setopt( m_curlHandle, CURLOPT_POST, 1 );
        curl_easy_setopt( m_curlHandle, CURLOPT_NOSIGNAL, 1);
        curl_easy_setopt( m_curlHandle, CURLOPT_URL, postUrl.c_str() );
        curl_easy_setopt( m_curlHandle, CURLOPT_POSTFIELDS, pszPostData );
        curl_easy_setopt( m_curlHandle, CURLOPT_POSTFIELDSIZE, length );
    }

    if( CURLE_OK == curl_easy_perform( m_curlHandle ) )
    {
        GetStatusCode();        
        bRet = HttpStatusCodeOK == m_iOperationResult;
    }
    else
        GetStatusCode();
    
    return bRet;
}


/*++
 * @method: CHttpRequest::saveLastWebResponse
 *
 * @description: method to save http responses. this is an internal method
 *               and CHttpRequest users need not use this.
 *
 * @input: data - character buffer from cURL,
 *         size - size of character buffer
 *
 * @output: size of data stored in our buffer
 *
 * @remarks: internal method
 *
 *--*/
int CHttpRequest::saveLastWebResponse( char*& data, size_t size )
{
    int bytesWritten = 0;
    if( data && size )
    {
        /* Append data in our internal buffer */
        m_callbackData.append( data, size );
        bytesWritten = (int)size; 
    }
    return bytesWritten;
}


/*++
 * @method: CHttpRequest::getLastWebResponse
 *
 * @description: method to get http response for the most recent request sent.
 *               twitcurl users need to call this method and parse the XML
 *               data returned by CHttpRequest to see what has happened.
 *
 * @input: outWebResp - string in which CHttpRequest's response is supplied back to caller
 *
 * @output: none
 *
 *--*/
void CHttpRequest::getLastWebResponse( std::string& outWebResp )
{
    outWebResp = "";
    if( m_callbackData.length() )
    {
        outWebResp = m_callbackData;
    }
}


/*++
 * @method: CHttpRequest::curlCallback
 *
 * @description: static method to get http response back from cURL.
 *               this is an internal method, users of CHttpRequest need not
 *               use this.
 *
 * @input: as per cURL convention.
 *
 * @output: size of data stored in our buffer
 *
 * @remarks: internal method
 *
 *--*/
int CHttpRequest::curlCallback( char* data, size_t size, size_t nmemb, CHttpRequest* pRequestObj )
{
    int writtenSize = 0;
    if( ( NULL != pRequestObj ) && ( NULL != data ) )
    {
        /* Save http response in twitcurl object's buffer */
        writtenSize = pRequestObj->saveLastWebResponse( data, ( size*nmemb ) );
    }
    return writtenSize;
}


int CHttpRequest::curlDownloadCallback( char* data, size_t size, size_t nmemb, CHttpRequest* pRequestObj )
{
    int writternSize = 0;
    if (NULL != pRequestObj && NULL != data)
    {
        if (!pRequestObj->m_strLocalFilename.empty())
        {
            writternSize = fwrite(data, size, nmemb, pRequestObj->m_pFileHandle);
            pRequestObj->m_nWriteSize += writternSize;
        }
    }
    return writternSize;
}


/*++
 * @method: CHttpRequest::clearCurlCallbackBuffers
 *
 * @description: method to clear callback buffers used by cURL. this is an
 *               internal method and CHttpRequest users need not use this.
 *
 * @input: none
 *
 * @output: none
 *
 * @remarks: internal method
 *
 *--*/
void CHttpRequest::clearCurlCallbackBuffers()
{
    m_callbackData = "";
    memset( m_errorBuffer, 0, CHttpRequestDefaults::CHTTPREQUEST_DEFAULT_BUFFSIZE );
}


std::string CHttpRequest::char2hex( char dec )
{
	char dig1 = (dec&0xF0)>>4;
	char dig2 = (dec&0x0F);
	if ( 0<= dig1 && dig1<= 9) dig1+=48;    //0,48 in ascii
	if (10<= dig1 && dig1<=15) dig1+=65-10; //A,65 in ascii
	if ( 0<= dig2 && dig2<= 9) dig2+=48;
	if (10<= dig2 && dig2<=15) dig2+=65-10;
    
    std::string r;
	r.append( &dig1, 1);
	r.append( &dig2, 1);
	return r;
}


std::string CHttpRequest::urlencode( const std::string &c )
{
    std::string escaped;
	int max = c.length();
	for(int i=0; i<max; i++)
	{
		if ( (48 <= c[i] && c[i] <= 57) ||//0-9
			(65 <= c[i] && c[i] <= 90) ||//ABC...XYZ
			(97 <= c[i] && c[i] <= 122) || //abc...xyz
			(c[i]=='~' || c[i]=='-' || c[i]=='_' || c[i]=='.')
			)
		{
			escaped.append( &c[i], 1);
		}
		else
		{
			escaped.append("%");
			escaped.append( char2hex(c[i]) );//converts char 255 to string "FF"
		}
	}
	return escaped;
}


