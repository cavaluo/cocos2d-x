//
//  LogManager.cpp
//  ApparkTest
//
//  Created by steve fan on 12-2-7.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#include <iostream>
#include "LogManager.h"
#include "HttpRequest.h"
#include "DictionaryDataGather.h"
#include "EncryptionManager.h"
#include <cstdio>
#include "ApparkSDK.h"
#include "BaseAlgorithm.h"

#define SAVE_LOG_LIMIT_TIME 1

using namespace ApparkSDK;

static void notifyFunc(void *pClass, bool val)
{
    CHttpRequest *rap = (CHttpRequest *)pClass;
    rap->getSuccesfulInfo(val);
}


static inline int CompareTime(tm * first, tm * second)
{
    int nRet = second->tm_hour - first->tm_hour;
    if (0 == nRet)
    {
        nRet = second->tm_min - first->tm_min;
        if (0 == nRet)
        {
            nRet = second->tm_sec - first->tm_sec;
        }
    }
    return nRet;
}

CLogManager::CLogManager():
m_sCurrentLogFileName(""),
m_iCurrentLogFilesSize(0),
m_sDefaultDir("")
{
    m_sCurrentLogFileName = "";
    
    m_sDefaultDir.assign(APPPARK_DEFAULTDIR);

#ifdef DEBUG
    printf("m_sDefaultDir is %s\r\n", m_sDefaultDir.c_str());
#endif

    m_fileManager.m_sDefaultDir = m_sDefaultDir;
    
    m_pLogUpLoader = new CLogUploader();
    
    m_iGameDataLastSaveTime = 0;
    m_iAGDLastSaveTime = 0;
    m_iMassLastSaveTime = 0;
    m_bIsUploading = false;
    m_aFilesToUpload.clear();
}


CLogManager::~CLogManager()
{
    SaveLogToFile();
    delete m_pLogUpLoader;
    m_pLogUpLoader = NULL;
}


void * CLogManager::UploadLogsThreadFunc(void * param)
{
    vector<string>::iterator iter;
    vector<int> arrUploadIndex;
    vector<int>::iterator iterInt;
    int i = 0;

    CLogManager * logManager = (CLogManager *)param;
//    logManager->m_bIsUploading = true;
    arrUploadIndex.clear();

    if (logManager && logManager->m_aFilesToUpload.size() > 0)
    {
        for (iter = logManager->m_aFilesToUpload.begin(); iter != logManager->m_aFilesToUpload.end(); iter++)
        {
            int nFindPos = iter->find(APPPARK_AGD_File_Prefix);
            bool bSendResult = logManager->SendLogToServer((char *)iter->c_str(), 
                                                           (nFindPos >= 0 ? eUserLogTypeAGD : 
                                                            eUserLogTypeGameData));
            if (bSendResult)
                arrUploadIndex.push_back(i);
            i++;
        }

        if (arrUploadIndex.size() > 0)
        {
            i = 0;
            for(iterInt = arrUploadIndex.begin(); iterInt != arrUploadIndex.end(); iterInt++)
            {
                iter = logManager->m_aFilesToUpload.begin();
                logManager->m_aFilesToUpload.erase(iter + *iterInt - i);
                i++;
            }
        }
    }

    if (logManager)
        logManager->m_bIsUploading = false;

    return NULL;
}


void CLogManager::StartLogUploading()
{
#ifdef DEBUG
    printf("\n\nBeen asked starting uploading log thread!\n\n");
#endif

    if (!m_bIsUploading && IsLogUploadingEnable() && m_aFilesToUpload.size() > 0)
    {
        m_bIsUploading = true;
#ifdef DEBUG
        printf("\n\nWill start uploading log thread!\n\n");
#endif
        pthread_t tid;
        int nRet = pthread_create(&tid,
                                  (const pthread_attr_t *)NULL,
                                  &UploadLogsThreadFunc,
                                  (void *)this);

        if (0 != nRet)
            m_bIsUploading = false;
#ifdef DEBUG
        printf("\n\nUploading thread started.\n\n");
#endif
    }
}


void CLogManager::sortFileName(std::vector<std::string>  fileNames)
{
    std::vector<std::string>::iterator iter;
    sort(fileNames.begin(), fileNames.end());
}


bool CLogManager::CheckLogFiles(CDictionaryDataGather& cFileListDict, EUserLogType nCheckType)
{
    bool bRet = false;
    std::vector<std::string>::iterator iter;
    std::vector<std::string> keys = cFileListDict.GetAllMemberNames();
    int fileExist = cFileListDict.GetItemCount();
    
    int i = 0;
    
    std::vector<std::string> fileNames;
    for (iter = keys.begin(); iter != keys.end(); iter++)
    {
        std::string keyStr = *iter;
        
        const char *fileName = cFileListDict.GetItemStringValue(keyStr.c_str());
        fileNames.push_back(fileName);
    }   
    sort(fileNames.begin(), fileNames.end());
    
    for (iter = fileNames.begin(); iter != fileNames.end(); ++iter)
    {
        std::string keyStr = *iter;
        const char *fileName = keyStr.c_str();
        
        if (checkFileNeedUpload((char *)fileName))
        {
            std::string fileFullPath = m_fileManager.fullPathForFile(fileName);
            if (filesize((char *)fileFullPath.c_str()))
            {
                m_aFilesToUpload.push_back(fileFullPath);
                i++;
#ifdef DEBUG
                printf("file %s need sendToServer\r\n", fileName);
#endif
            }
            else
            {
                remove(fileFullPath.c_str());
            }
        }

        if ( eUserLogTypeGameData == nCheckType)
            m_sCurrentLogFileName = fileName;
        else if( eUserLogTypeAGD == nCheckType)
            m_sCurrentAGDLogFileName = fileName;
        else if( eUserLogTypeMassData == nCheckType)
            m_sCurrentMassLogFileName = fileName;
    }
    
    if(i == fileExist)
        bRet = CreateNewFileName(nCheckType);
    else
        bRet = InitDictionaryData(nCheckType);

    return bRet;
}


bool CLogManager::CheckUserLogFiles()
{
    return CheckLogFiles(m_fileManager.m_cGameFileDictionary, eUserLogTypeGameData);
}


bool CLogManager::CheckAGDLogFiles()
{
    return CheckLogFiles(m_fileManager.m_cAGDFileDictionary, eUserLogTypeAGD);
}


bool CLogManager::CheckMassLogFiles()
{
    return CheckLogFiles(m_fileManager.m_cMassFileDictionary, eUserLogTypeMassData);
}


bool CLogManager::InitDictionaryData(EUserLogType logType)
{
    string logFileName;
    if (eUserLogTypeMassData == logType)
        logFileName = m_sCurrentMassLogFileName;
    else
        logFileName = (logType == eUserLogTypeGameData) ? m_sCurrentLogFileName : m_sCurrentAGDLogFileName;

    std::string fileFullPath = m_fileManager.fullPathForFile((char *)logFileName.c_str());
#ifdef DEBUG
    printf("fileFull Path is %s\r\n", fileFullPath.c_str());
#endif
    FILE * pFile = fopen(fileFullPath.c_str(), "rb+");
    if (!pFile)
        pFile = fopen(fileFullPath.c_str(), "wb");

    long flen = filesize(pFile);

    long destLen;
    if (eUserLogTypeMassData)
        destLen = m_cdictDestMassData.GetDescription().length();
    else
        destLen = (logType == eUserLogTypeAGD) ? m_cdictDestAGDData.GetDescription().length():
                    m_cdictDestGameData.GetDescription().length();

    if ((destLen <= 5) && (flen > 0))
    {
        char *pFileContent = (char *)malloc(flen+1); 
        rewind(pFile);
        flen = fread(pFileContent, 1, flen,  pFile);
        pFileContent[flen] = 0;

        if (flen > 0)
        {
            if (logType == eUserLogTypeGameData)
            {
                m_cdictDestGameData.InitWithDescription(pFileContent);
#ifdef DEBUG
                //printf("In InitDictionaryData , the m_cdictDestGameData is %s", m_cdictDestGameData.GetDescription().c_str());
#endif       
            }
            else if(logType == eUserLogTypeAGD){
                m_cdictDestAGDData.InitWithDescription(pFileContent);
#ifdef DEBUG
                //printf("In InitDictionaryData , the m_cdictDestAGDData is %s", m_cdictDestAGDData.GetDescription().c_str());
#endif        
            }
            else if(logType == eUserLogTypeMassData)
            {
                m_cdictDestMassData.InitWithDescription(pFileContent);
#ifdef DEBUG
                //printf("In InitDictionaryData , the m_cdictDestMassData is %s", m_cdictDestMassData.GetDescription().c_str());
#endif
            }
            free(pFileContent);
        }
    }
    fclose(pFile);
    return true;
}


bool CLogManager::InitLogFiles()
{
//    m_iAGDLastSaveTime = time(0);
//    m_iGameDataLastSaveTime = time(0);
//    m_iMassLastSaveTime = time(0);
    int fileExist = m_fileManager.filesExistAtDocumet((char *)m_sDefaultDir.c_str());
    if (fileExist>0)
    {
        bool retAGDCheck = CheckAGDLogFiles();
        bool retUserCheck = CheckUserLogFiles();
        bool retMassCheck = CheckMassLogFiles();
        
        return retUserCheck && retAGDCheck && retMassCheck;
    }
    else
    {
        bool createLogFileret = CreateNewFileName(eUserLogTypeGameData);
        bool createAGDFileRet = CreateNewFileName(eUserLogTypeAGD);
        bool createMassFileRet = CreateNewFileName(eUserLogTypeMassData);
        
        bool ret = createAGDFileRet && createLogFileret && createMassFileRet;
        return  ret;
    }
    return false;
}


bool CLogManager::Init(void *apparkSDK, CLocalSettingManager *localSettingManager, const char* userDir)
{
    
    m_pLogUpLoader->m_pApparkSDK = apparkSDK;
    m_pLocalSettingManager = localSettingManager;
    if (userDir)
    {
        m_sDefaultDir.clear();
        m_sDefaultDir.assign(userDir);
    }
    else
    {
        m_sDefaultDir.clear();
        m_sDefaultDir.assign(APPPARK_DEFAULTDIR);
    }
    m_fileManager.m_sDefaultDir = m_sDefaultDir;
    bool bRet = InitLogFiles();
    
    StartLogUploading();
    
    return bRet;
//    return Init(localSettingManager, userDir);
}


//bool CLogManager::Init(CLocalSettingManager * localSettingManager, const char* userDir)
//{
//}


bool CLogManager::SaveLog(char * logInfo, EUserLogType logType )
{
    if (!logInfo)
    {
        return false;
    }
    string sLog = logInfo;
#ifdef DEBUG
    printf("In SaveLog the logInfo is %s\n", logInfo);
#endif
    bool ret = false;
    switch (logType)
    {
        case eUserLogTypeAGD:
            ret = SaveLog((char *)sLog.c_str(), m_sCurrentAGDLogFileName, logType);
            break;
        case eUserLogTypeGameData:
            if (m_pLocalSettingManager->getEnableUserLog())
                ret = SaveLog((char *)sLog.c_str(), m_sCurrentLogFileName, logType);
            break;
        case eUserLogTypeMassData:
            if (m_pLocalSettingManager->getEnableUserLog()) {
                ret = SaveLog((char *)sLog.c_str(), m_sCurrentMassLogFileName, logType);
            }
        default:
            break;
    }

    return ret;
}


void CLogManager::InsertItemToDictionary(std::string logInfo, CDictionaryDataGather& dict)
{
    time_t  tim = time(0); 
    clock_t tim_clock   = clock();

    char timeKey[32] = {0};
    sprintf(timeKey, "%ld_%lu",tim, tim_clock);
    std::string sTimeKey(timeKey);
    
    int nLogInfoLength = logInfo.length();
    char * base64Buffer;

    int nBufferLen = CEncryptionManager::Base64Encode((const unsigned char *)logInfo.c_str(), NULL, nLogInfoLength);
    base64Buffer = (char *)malloc(nBufferLen + 4);
    ZeroMemory(base64Buffer, nBufferLen + 4);

    CEncryptionManager::Base64Encode((const unsigned char *)logInfo.c_str(), (unsigned char *)base64Buffer, nLogInfoLength);
    CEncryptionManager::ConfuseString(base64Buffer);

    dict.InsertItem(timeKey, base64Buffer);
    free(base64Buffer); 
}


inline void CLogManager::WriteToFile(const char *content, const char *fullPath)
{
    m_iCurrentLogFilesSize  = strlen(content);
    m_iCurrentAGDLogFilesSize = strlen(content);
    FILE *pFile = fopen(fullPath, "wb");
    if (pFile)
    {
        rewind(pFile);
        fwrite(content, 1, strlen(content), pFile);
        fflush(pFile);
        fclose(pFile);
#if DEBUG
        printf("after write file [%s] size is %ld\r\n\n", fullPath, m_iCurrentLogFilesSize);
#endif
    }
}


bool CLogManager::SaveLog(char * logInfo, std::string logFileName, EUserLogType logType)
{
    if (!logInfo || !*logInfo)
        return false;

    string strLogInfo(logInfo);

    std::string fileFullPath = m_fileManager.fullPathForFile((char *)logFileName.c_str());
    time_t curretTime = time(NULL);
    switch (logType)
    {
        case eUserLogTypeAGD:
        {
            if (curretTime - m_iAGDLastSaveTime > SAVE_LOG_LIMIT_TIME)
            {
                InsertItemToDictionary(strLogInfo, m_cdictDestAGDData);
                if (m_cdictDestAGDData.GetDescription().length() > 0)
                {
                    string dest = m_cdictDestAGDData.GetDescription();
                    m_iAGDLastSaveTime = curretTime;
                    WriteToFile(dest.c_str(), fileFullPath.c_str());
                }
            }
            else
            {
                InsertItemToDictionary(strLogInfo, m_cdictDestAGDData);
            }

            if (m_iCurrentLogFilesSize > m_pLocalSettingManager->getAGDLogFileSizeLimit() && !m_bIsUploading)
            {
                m_aFilesToUpload.push_back(fileFullPath);
                StartLogUploading();
                return  CreateNewFileName(eUserLogTypeAGD);
            }
        }
            break;
        case eUserLogTypeGameData:
        {
            if (curretTime - m_iGameDataLastSaveTime > SAVE_LOG_LIMIT_TIME)
            {
                InsertItemToDictionary(strLogInfo, m_cdictDestGameData);
                if(m_cdictDestGameData.GetDescription().length() > 0)
                {
                    string dest = m_cdictDestGameData.GetDescription();
                    m_iGameDataLastSaveTime = curretTime;
                    WriteToFile(dest.c_str(), fileFullPath.c_str());
                }
            }
            else
            {
                InsertItemToDictionary(strLogInfo, m_cdictDestGameData);
            }

            if (m_iCurrentLogFilesSize > m_pLocalSettingManager->getLogFileSizeLimit() && !m_bIsUploading)
            {
                m_aFilesToUpload.push_back(fileFullPath.c_str());
                StartLogUploading();
                return  CreateNewFileName(eUserLogTypeGameData);
            }
        }
            break;
        case eUserLogTypeMassData:
        {
            if (curretTime - m_iMassLastSaveTime > SAVE_LOG_LIMIT_TIME)
            {
                InsertItemToDictionary(strLogInfo, m_cdictDestMassData);
                if(m_cdictDestMassData.GetDescription().length() > 0)
                {
                    string dest = m_cdictDestMassData.GetDescription();
                    m_iMassLastSaveTime = curretTime;
                    WriteToFile(dest.c_str(), fileFullPath.c_str());
                }
            }
            else
            {
                InsertItemToDictionary(strLogInfo, m_cdictDestMassData);
            }

            if (m_iCurrentLogFilesSize > m_pLocalSettingManager->getLogFileSizeLimit() && !m_bIsUploading)
            {
                m_aFilesToUpload.push_back(fileFullPath.c_str());
                StartLogUploading();
                return  CreateNewFileName(eUserLogTypeMassData);
            }
        }
            break;
        default:
            break;
    }
    return true;
}


bool CLogManager::SaveLogToFile()
{
    long len = m_cdictDestGameData.GetDescription().length();
    time_t currentTime = time(0);

    if (len > 5)
    {
        string dest = m_cdictDestGameData.GetDescription();
#if DEBUG
        printf("dest is %s", dest.c_str());
#endif
        m_iGameDataLastSaveTime = currentTime;
        std::string fileFullPath = m_fileManager.fullPathForFile((char *)m_sCurrentLogFileName.c_str());
        WriteToFile(dest.c_str(), fileFullPath.c_str());
        m_cdictDestGameData.CleanUp();
    }

    len = m_cdictDestAGDData.GetDescription().length();
    if (len > 5)
    {
        string dest = m_cdictDestAGDData.GetDescription();
#if DEBUG
        printf("AGD dest is %s", dest.c_str());
#endif
        m_iAGDLastSaveTime = currentTime;
        std::string fileFullPath = m_fileManager.fullPathForFile((char *)m_sCurrentAGDLogFileName.c_str());
        WriteToFile(dest.c_str(), fileFullPath.c_str());
        m_cdictDestAGDData.CleanUp();
    }

    len = m_cdictDestMassData.GetDescription().length();
    if (len > 5)
    {
        string dest = m_cdictDestMassData.GetDescription();
#if DEBUG
        printf("Mess dest is %s", dest.c_str());
#endif
        m_iMassLastSaveTime = currentTime;
        std::string fileFullPath = m_fileManager.fullPathForFile((char *)m_sCurrentMassLogFileName.c_str());
        WriteToFile(dest.c_str(), fileFullPath.c_str());
        m_cdictDestMassData.CleanUp();
    }
    return true;
}


bool CLogManager::UploadGatherInfo()
{
    return m_pLogUpLoader->UploadGatherInfo();
}


bool CLogManager::SendLogToServer(char * fullpath, EUserLogType logType)
{
    bool ret = false;

    if (eUserLogTypeAGD == logType)
        ret = m_pLogUpLoader->UploadAGDFile(fullpath, 0, NULL);
    else if(eUserLogTypeGameData == logType)
        ret =m_pLogUpLoader->UploadGameDataFile(fullpath, 0, NULL);
    else if(eUserLogTypeMassData == logType)
        ret = m_pLogUpLoader->UploadMassDataFile(fullpath, 0, NULL);

    if (ret)
    {
        int removeRet = std::remove(fullpath);
        ret = removeRet == 0;
#ifdef DEBUG
        if (removeRet == 0)
            printf("remove file %s\r\n",fullpath);
#endif
    }

    return ret;
}


inline long CLogManager::filesize(FILE *stream)
{
    long nReturn = 0;
    if(stream)
    {
        long curpos, length;
        curpos = ftell(stream);
        fseek(stream, 0L, SEEK_END);
        length = ftell(stream);
        fseek(stream, curpos, SEEK_SET);
        nReturn = length;
    }
    return nReturn;
}


inline long CLogManager::filesize(char *pszFilename)
{
    long nRet = 0; 
    FILE *f = fopen(pszFilename, "rb");
    if (f)
    {
        nRet = filesize(f);
        fclose(f);
    }
    return nRet;
}


bool CLogManager::checkFileNeedUpload(char *filename, EUserLogType logType)
{
    string sFileName;
    sFileName.assign(filename);
    size_t firstPos =sFileName.find_first_of("g") + 1;
    size_t lastPos = sFileName.find_first_of(".");

    string timeStr = sFileName.substr(firstPos, lastPos - firstPos);
    time_t  lTimeFile = atol(timeStr.c_str());

    time_t  timCur= time(0); 
    long lTimeInterval = timCur - lTimeFile;
    long forceUploadTime = (logType == eUserLogTypeGameData)?m_pLocalSettingManager->getForceUploadTime():m_pLocalSettingManager->getAGDForceUploadTime();

    if (lTimeInterval > forceUploadTime)
        return true;

    std::string filePath = m_fileManager.fullPathForFile(filename);
    FILE *pFile = fopen(filePath.c_str(), "rb");
    long fileSize = filesize(pFile);

    long fileSizeLimit = (logType == eUserLogTypeGameData || logType == eUserLogTypeMassData) ? 
                            m_pLocalSettingManager->getLogFileSizeLimit() : m_pLocalSettingManager->getAGDLogFileSizeLimit();

    if (fileSize >= fileSizeLimit)
        return true;

    return false;
}


bool  CLogManager::CreateNewFileName(EUserLogType logType)
{
    char fileName[128];
    time_t tim = time(0);
    string filePrefix;
    if (eUserLogTypeMassData == logType)
        filePrefix = APPPARK_MASS_File_Prefix;
    else
        filePrefix = (logType == eUserLogTypeGameData) ? APPPARK_File_Prefix : APPPARK_AGD_File_Prefix;
    sprintf(fileName, "%s%ld.%s", filePrefix.c_str(), tim, APPPARK_File_Suffix);

    switch (logType)
    {
        case eUserLogTypeAGD:
        {
            m_sCurrentAGDLogFileName.clear();
            m_sCurrentAGDLogFileName.assign(fileName);
            m_iCurrentAGDLogFilesSize = 0;
            m_cdictDestAGDData.CleanUp();
            return m_fileManager.createNewFile((char *)m_sCurrentAGDLogFileName.c_str());;
        }
            break;
        case eUserLogTypeGameData:
        {
            m_sCurrentLogFileName.clear();
            m_sCurrentLogFileName.assign(fileName);
            m_iCurrentLogFilesSize = 0;
            m_cdictDestGameData.CleanUp();
            return m_fileManager.createNewFile((char *)m_sCurrentLogFileName.c_str());
        }
            break;
        case eUserLogTypeMassData:
        {
            m_sCurrentMassLogFileName.clear();
            m_sCurrentMassLogFileName.assign(fileName);
            m_iCurrentMassLogFileSize = 0;
            m_cdictDestMassData.CleanUp();
            return m_fileManager.createNewFile((char *)m_sCurrentMassLogFileName.c_str());
        }
            break;
        default:
            break;
    }

    return false;
}


bool CLogManager::IsLogUploadingEnable()
{
    bool bRet = false;
    if (m_pLocalSettingManager->getEnableUploadLog())
    {
        if (m_pLocalSettingManager->getUploadTimeBegin() >= m_pLocalSettingManager->getUploadTimeEnd())
        {
            bRet = true;
        }
        else
        {
            time_t curTime = time(NULL);
            tm * fmtCurTime = localtime(&curTime);
            time_t beginTime, endTime;
            beginTime = m_pLocalSettingManager->getUploadTimeBegin();
            endTime = m_pLocalSettingManager->getUploadTimeEnd();
            tm * fmtBeginTime = localtime(&beginTime);
            tm * fmtEndTime = localtime(&endTime);
            if (CompareTime(fmtBeginTime, fmtCurTime) >= 0 && CompareTime(fmtCurTime, fmtEndTime) >= 0)
                bRet = true;
        }
    }
    return bRet;
}


void CLogManager::SaveCrashLog(char * logInfo)
{
//    SaveLog(logInfo, m_sCurrentLogFileName, eUserLogTypeGameData);
    SaveLog(logInfo, eUserLogTypeGameData);
}


//bool CLogManager::SaveLog(char * logInfo)
//{
//    return SaveLog(logInfo, eUserLogTypeGameData);
//}


bool CLogManager::SaveMassiveDataLog(char * logInfo)
{
    return SaveLog(logInfo, eUserLogTypeMassData);
}
