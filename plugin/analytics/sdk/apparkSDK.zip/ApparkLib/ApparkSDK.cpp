//
//  ApparkSDK.cpp
//  ApparkTest
//
//  Created by XiaoFeng on 12-1-31.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#include "ApparkSDK.h"
#include "CommonDef.h"
#include <pthread.h>

using namespace ApparkSDK;


CApparkSDK::CApparkSDK()
{
    m_bIsInitialized = false;
    m_pLogManager = NULL;
    m_pSettingManager = NULL;
    m_pUserAnalyticLog = NULL;
    m_pDataGather = NULL;
    m_pGameDataManager = NULL;
    m_strSDKVersion = APPARK_SDK_VERSION;
}

CApparkSDK::~CApparkSDK()
{
    CleanUp();
}


void CApparkSDK::CleanUp()
{
    SafeDeletePtr(m_pLogManager);
    SafeDeletePtr(m_pSettingManager);
    SafeDeletePtr(m_pUserAnalyticLog);
    SafeDeletePtr(m_pDataGather);
    SafeDeletePtr(m_pGameDataManager);
    SafeDeletePtr(m_pFileManger);
    m_bIsInitialized = false;
}


bool CApparkSDK::InitAppark(const char * pszAppID, const char * pszAppVersion, const char * pszDeviceToken, const char * pszLogPath)
{
    m_bIsInitialized = false;

    m_strAppID = pszAppID ? pszAppID : "";
    m_strAppVersion = pszAppVersion ? pszAppVersion : "";
    m_strDeviceToken = pszDeviceToken ? pszDeviceToken : "";
    m_strLogPath = pszLogPath ? pszLogPath : "";

    m_cDeviceInfo.GetDeviceInfo();

    m_pSettingManager = new CLocalSettingManager;
    m_pLogManager = new CLogManager();
    m_pUserAnalyticLog = new CUserAnalytic();
    m_pDataGather = new CDataGather();
    m_pGameDataManager = new CGameDataManager();
    m_pFileManger = new CFileManager();

    if(!m_pSettingManager || !m_pLogManager || !m_pUserAnalyticLog ||
       !m_pDataGather || !m_pGameDataManager || !m_pFileManger)
    {
        CleanUp();
        return false;
    }

    if (!pszLogPath) {
        m_pFileManger->m_sDefaultDir = APPPARK_DEFAULTDIR;
    }
    else{
         m_pFileManger->m_sDefaultDir = pszLogPath;
    }
    
    if (!m_pSettingManager->Init(m_pFileManger->fullPathForDir().c_str(), (void *)this))
    {
        CleanUp();
        return false;
    }
    if(!m_pLogManager->Init(this, m_pSettingManager))
    {
        CleanUp();
        return false;
    }
    if(!m_pUserAnalyticLog->Init(m_pLogManager))
    {
        CleanUp();
        return false;
    }
    if(!m_pDataGather->Init(m_pLogManager))
    {
        CleanUp();
        return false;
    }
    if(!m_pGameDataManager->Init())
    {
        CleanUp();
        return false;
    }

    if (m_pSettingManager->m_bNeedFistNotify)
    {
        NotifyServerFirstRun();
    }

    m_pLogManager->StartLogUploading();
    m_bIsInitialized = true;
    return true;
}

//void CApparkSDK::SetDeviceToken(const char * pszToken)
//{
//    m_strDeviceToken = pszToken;
//}

void CApparkSDK::NotifyServerFirstRun()
{
    pthread_t tid;
    pthread_create(&tid, 
                   (const pthread_attr_t *)NULL, 
                   &FirstRunNotifyThreadFunc, 
                   (void *)this);
}


void * CApparkSDK::FirstRunNotifyThreadFunc(void * param)
{
    CApparkSDK * pcApparkSDK = (CApparkSDK *) param;
    if (pcApparkSDK->m_cDeviceInfo.m_sNetWork_type.compare(CURRENT_NET_CONNECTION_NONE) != 0)
    {
        bool bRet = pcApparkSDK->m_pLogManager->UploadGatherInfo();
        pcApparkSDK->m_pSettingManager->m_bNeedFistNotify = !bRet;
        if (bRet)
            pcApparkSDK->m_pSettingManager->RefreshLocalSettingFile();
    }

    return NULL;
}


void CApparkSDK::FlushLogs()
{
    if (m_pLogManager)
        m_pLogManager->SaveLogToFile();
}


void CApparkSDK::NetStatusChange(const char * pszNewStatus)
{
    m_cDeviceInfo.m_sNetWork_type = pszNewStatus;
    if (0 != m_cDeviceInfo.m_sNetWork_type.compare(CURRENT_NET_CONNECTION_NONE))
        m_pLogManager->StartLogUploading();
}


