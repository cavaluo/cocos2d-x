//
//  TimeEvent.h
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-13.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#ifndef ApparkTest_TimeEvent_h
#define ApparkTest_TimeEvent_h

#include "DictionaryDataGather.h"

using namespace std;

namespace ApparkSDK
{
    class CTimeEvent
    {
    public:
        CTimeEvent();

        void StartEvent(const char * pszEventID, const char * pszSessionID, CDictionaryDataGather * pParams);
        void FinishEvent(CDictionaryDataGather * pParams);
        const char * GetEventID();
        string GetEventDiscription();
        bool IsEqualEvent(const char * pszEvendID);

    public:
        string m_strEventID;
        string m_strSessionID;
        time_t m_nStartTime;
        time_t m_nEventDuration;
        CDictionaryDataGather m_cStartParameters;
        CDictionaryDataGather m_cEndParamters;
    };
}


#endif
