//
//  UserAnalytic.h
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-13.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#ifndef ApparkTest_UserAnalytic_h
#define ApparkTest_UserAnalytic_h

#include "CommonDef.h"
#include "TimeEvent.h"
#include "LogManager.h"

using namespace std;

namespace ApparkSDK
{
    class CUserAnalytic
    {
    public:
        CUserAnalytic();
        ~CUserAnalytic();

    public:
        bool Init(CLogManager * pLogManager);
        void LogGPSLocation(double dLongitude, double dLatitude, float fHorizontalAccuracy, float fVerticalAccuracy);
        void StartSession(const char * pszSessionID);
        void SetUserInfo(const char * pszUserName, int nAge, int nGender);
        void LogEvent(const char * pszEventName, CDictionaryDataGather * pEventParams);
        void LogError(const char * pszErrorID, const char *pszErrorMsg, CDictionaryDataGather * pErrorParams);
        void LogTimedEvent(const char * pszEventID, CDictionaryDataGather * pEventParams);
        void EndTimedEvent(const char * pszEventID, CDictionaryDataGather * pEventParams);

        void LogEvent(const char * pszEventMsg);

    protected:
        string m_strUserAppVersion;
        string m_strCurrentSession;
        CLogManager * m_pLogManager;
        vector<CTimeEvent> m_aTimedEventList;
    };
}


#endif
