//
//  LogUpLoader.h
//  ApparkTest
//
//  Created by steve fan on 12-2-9.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#ifndef ApparkTest_LogUpLoader_h
#define ApparkTest_LogUpLoader_h
#include "HttpRequest.h"

namespace ApparkSDK
{
    typedef enum UploadResultDefine
    {
        eUploadResultFalse = 0,
        eUploadResultTrue,
    }EUploadResultDefine;

    typedef void (*RESULT_NOTICE_CALL_BACK)(bool);

    class CLogUploader
    {
    public:
        CLogUploader();
        ~CLogUploader();
        
    public:
        void *m_pApparkSDK;       //ApparkSDK指针 
        int m_iInUploadingProgress; // 当前上传进度百分比(0-100)
        EUploadResultDefine m_eUploadResult;    //提交的返回结果。 
        RESULT_NOTICE_CALL_BACK m_cResultNoticeCallback;    //用于通知上传结果的回调函数指针 
        void * param;   // 用于回调通知的用户自定义参数 

        bool UploadGameDataFile(char * fullpath, int transfertype, void * UserParam);   //向服务器提交游戏数据 
        bool UploadAGDFile(char * fullpath, int transfertype, void * UserParam);   //向服务器提交自动抓取的数据 
        bool UploadMassDataFile(char * fullpath, int transfertype, void * UserParam);   //向服务器提交用户自定义的大数据量数据 
        bool UploadMessage(char *message);  //  向服务器提交JSON数据描述字符串。Message为编码加密后的json描述串。返回值为是否正常启动提交。 
//        bool UpLoadMessage(char *message, CHttpRequest *pHttpRequest);
        bool UpLoadMessage(char *message, char *requestURL);
        bool UploadFile(char * fullpath, int transfertype, void * UserParam);    //向服务器提交log文件。Fullpath为包含全路径的log文件名,transfertype为同步或异步传输,UserParam为回调通知传送的用户自定义参数。返回值异步模式为是否正常启动提交,同步模式为是否正常提交到服务器。 
        
        bool UploadGatherInfo();     //向服务器提交用户设备信息 
        char * GetFileContent(char *fullPath);  //获取文件中 

    protected:
//        CHttpRequest * m_pHttpOperator; // Http通讯类对象 
        bool UpLoadMessage(char *message, char *requestURL, OperationMethod method);

    private:
        inline void FormatTime(time_t time, std::string& outputString);
        inline long filesize(FILE *stream);
        static void UploadResultNotice(CHttpRequest *HttpOperator, void * param, bool success); //回调函数, 用来接收HttpProcessor向服务器提交数据是否成功的通知。并将结果通知调用 者CLogManager
        bool CheckHttpResult(CHttpRequest *httpOperator);
    };
}

#endif
