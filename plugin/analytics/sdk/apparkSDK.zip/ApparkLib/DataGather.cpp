//
//  DataGather.cpp
//  ApparkTest
//
//  Created by lvyile on 2/12/12.
//  Copyright (c) 2012 CocoaChina.com. All rights reserved.
//

#include <iostream>
#include "DataGather.h"
#define LOG_APP_STARTTIME_KEY   "LogAppStartTime"
#define LOG_APP_ENDTIME_KEY     "LogAppEndTime"
#define SESSION_STARTTIME_KEY   "starttime"
#define SESSION_ENDTIME_KEY     "SessionEndTime"
#define DURATIONTIME_KEY        "duration"
#define SESSION_KEY             "session"
#define CRASHLOG_KEY            "crashlog"
#define NETSTATE_KEY            "netstate"
#define LANGUAGE_KEY            "language"
#define TIMEZONE_KEY            "timezone"

using namespace ApparkSDK;

CDataGather::CDataGather()
{
}


CDataGather::~CDataGather()
{
}


bool CDataGather::Init(CLogManager *LogManager)
{
    m_pLogManager= LogManager;
    m_pInfoFormatter = new CDictionaryDataGather;
    return true;
}


void CDataGather::StartDataGathering()
{
}


bool CDataGather::AddToLocalLog(char * message, int Type)
{
    bool ret = m_pLogManager->SaveLog(message, eUserLogTypeAGD);
    return ret;
}


bool CDataGather::LogAppStart(time_t StartTime)
{
    m_lAppStartTime = StartTime;
    return true;
}


bool CDataGather::LogAppFinished(time_t EndTime)
{
//    int  duration = EndTime - m_lAppStartTime;
    std::string timeStamp;
    FormatTime(m_lAppStartTime, timeStamp);
//    CJsonWriter tempWriter;
//    tempWriter.InsertItem(LOG_APP_STARTTIME_KEY, timeStamp);
//    m_pInfoFormatter->InsertItem(<#const char *pszKey#>, <#int nValue#>)
//    m_pInfoFormatter->InsertItem(DURATIONTIME, duration);
    return true;
}


bool CDataGather::LogSessionStart(time_t StartTime)
{
    m_lSessionStartTime = StartTime;
    return true;
}


bool CDataGather::LogSessionEnd(time_t EndTime)
{
//    int  duration = EndTime - m_lSessionStartTime;
//    std::string timeStamp;
//    FormatTime(m_lSessionStartTime, timeStamp);
//    CJsonWriter tempWriter;
//    tempWriter.InsertItem(SESSION_STARTTIME_KEY, timeStamp);
//    m_pInfoFormatter->InsertItem(<#const char *pszKey#>, <#int nValue#>)
//    tempWriter.InsertItem(DURATIONTIME_KEY, duration);
//    m_pInfoFormatter->InsertItem(SESSION_KEY, tempWriter.GetValue());
    return true;

}


bool CDataGather::LogCrashInfo(time_t CrashTime, const char * message)
{
    m_pInfoFormatter->InsertItem(CRASHLOG_KEY, message);
    return true;
}


bool CDataGather::LogNetworkStatus(time_t time, bool AccessStatus)
{
    m_pInfoFormatter->InsertItem(NETSTATE_KEY, AccessStatus?"WIFI":"NONE");
    return true;
}


bool CDataGather::LogLanguageChange(time_t time, char * NewLanguage)
{
    if(!NewLanguage)
        return false;

    int ret = m_sLastLanguageSetting.compare(NewLanguage);
    if (ret == 0) {
        return true;
    }
    return false;
//    m_pInfoFormatter->InsertItem(LANGUAGE_KEY, NewLanguage);
}


bool CDataGather::LogTimeZoneChange(char * NewTimeZone)
{
    if (!NewTimeZone)
        return false;

    int ret = m_sLastTimeZoneSetting.compare(NewTimeZone);
    if (ret == 0)
        return true;

    return false;
}


bool CDataGather::LogInstalledAppChange(const char * AppList)
{
    return false;
}


vector<string> * CDataGather::GetCurrentInstalledApps()
{
    return NULL;
}


char * CDataGather::GetCurrentLanguage()
{
    return (char *)m_sLastLanguageSetting.c_str();
}


char * CDataGather::GetCurrentTimezone()
{
    return (char *)m_sLastTimeZoneSetting.c_str();
}


void CDataGather::FormatTime(time_t time, std::string& outputString)
{
    tm key_tm;
    key_tm = *localtime(&time);
    char timeStamp[32];
    sprintf(timeStamp, "%04d-%02d-%02d%s%02d:%02d:%02d", key_tm.tm_year + 1900, key_tm.tm_mon + 1, key_tm.tm_mday, "%20", 
            key_tm.tm_hour, key_tm.tm_min, key_tm.tm_sec);
    string temp = string(timeStamp);
    outputString = temp;    
}

