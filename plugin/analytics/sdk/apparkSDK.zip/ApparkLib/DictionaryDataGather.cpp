 //
//  DictionaryDataGather.cpp
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-8.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#include <iostream>
#include "DictionaryDataGather.h"
#include "CommonDef.h"
//#include "JsonReader.h"
//#include "JsonWriter.h"
using namespace ApparkSDK;

CDictionaryDataGather::CDictionaryDataGather()
{
    m_cValue.clear();
}


CDictionaryDataGather::~CDictionaryDataGather()
{
    m_cValue.clear();
}


void CDictionaryDataGather::InitWithDescription(const char *pszDescription)
{
    Json::Reader cReader;
    m_cValue.clear();
    if (pszDescription && *pszDescription)
    {
        string strValue = pszDescription;
        cReader.parse(strValue, m_cValue, false);
    }
}


void CDictionaryDataGather::InitWithValue(Json::Value& value)
{
    m_cValue = value;
}


void CDictionaryDataGather::InsertItem(const char *pszKey, int nValue)
{
    m_cValue[pszKey] = nValue;
}


void CDictionaryDataGather::InsertItem(const char *pszKey, double fValue)
{
    m_cValue[pszKey] = fValue;
}


void CDictionaryDataGather::InsertItem(const char *pszKey, const char * pszValue)
{
    m_cValue[pszKey] = pszValue;
}


void CDictionaryDataGather::InsertItem(const char *pszKey, CDictionaryDataGather * subDictionary)
{
    if (subDictionary)
        m_cValue[pszKey] = subDictionary->m_cValue;
}


bool CDictionaryDataGather::DeleteItem(const char *pszKey)
{
    if(!m_cValue.isMember(pszKey))
        return false;

    m_cValue.removeMember(pszKey);

    return true;
}


void CDictionaryDataGather::CleanUp()
{
    m_cValue.clear();
}


bool CDictionaryDataGather::IsKeyValidate(const char *pszKey)
{
    return m_cValue.isMember(pszKey);
}


int CDictionaryDataGather::GetItemIntValue(const char *pszKey, int nDefaultValue)
{
    if (!IsKeyValidate(pszKey, m_cValue) || !m_cValue[pszKey].isNumeric())
        return nDefaultValue;
    
    return m_cValue[pszKey].asInt();
}


double CDictionaryDataGather::GetItemFloatValue(const char *pszKey, double fDefaultValue)
{
    if (!IsKeyValidate(pszKey, m_cValue) || !m_cValue[pszKey].isNumeric())
        return fDefaultValue;
    
    return m_cValue[pszKey].asDouble();
}


const char * CDictionaryDataGather::GetItemStringValue(const char *pszKey)
{
    if (!IsKeyValidate(pszKey, m_cValue) || !m_cValue[pszKey].isString())
        return NULL;
    
    return m_cValue[pszKey].asCString();
}


CDictionaryDataGather * CDictionaryDataGather::GetSubDictionary(const char *pszKey)
{
    CDictionaryDataGather * pNewDictionary;
    if (!IsKeyValidate(pszKey, m_cValue) || (!m_cValue[pszKey].isArray() && 
                                            !m_cValue[pszKey].isObject() && 
                                            !m_cValue[pszKey].isConvertibleTo(Json::arrayValue) &&
                                            !m_cValue[pszKey].isConvertibleTo(Json::objectValue)))
    {
        pNewDictionary = NULL;
    }
    else
    {
        pNewDictionary = new CDictionaryDataGather();
        pNewDictionary->InitWithValue(m_cValue[pszKey]);
    }
    return pNewDictionary;
}


//CDictionaryDataGather * CDictionaryDataGather::GetSubDictionaryFromArray(const char *pszArrayKey, int nIndex)
//{
//    m_cJsonReader.InitWithValue(m_cValue);
//    Json::Value * subValue = m_cJsonReader.GetSubJsonItem(pszArrayKey);
//    if (!subValue)
//        return NULL;
//
//    m_cJsonReader.InitWithValue(*subValue);
//    subValue = m_cJsonReader.GetSubJsonItem(nIndex);
//    if (!subValue)
//        return NULL;
//
//    CDictionaryDataGather * pNewDictionary = new CDictionaryDataGather();
//    pNewDictionary->InitWithDescription(subValue->toStyledString().c_str());
//
//    return pNewDictionary;
//}


string CDictionaryDataGather::GetDescription()
{
    string strReturn = m_cValue.toStyledString();
    return strReturn;
}


bool CDictionaryDataGather::InsertItemToArray(const char *pszArrayKey, int nValue)
{
    Json::Value array;
    if(m_cValue.isMember(pszArrayKey))
    {
        if (!m_cValue[pszArrayKey].isArray() && !m_cValue[pszArrayKey].isConvertibleTo(Json::arrayValue))
            return false;
        
        array = m_cValue[pszArrayKey];
    }
    
    array.append(nValue);
    m_cValue[pszArrayKey] = array;
    
    return true;
}


bool CDictionaryDataGather::InsertItemToArray(const char *pszArrayKey, double fValue)
{
    Json::Value array;
    if(m_cValue.isMember(pszArrayKey))
    {
        if (!m_cValue[pszArrayKey].isArray() && !m_cValue[pszArrayKey].isConvertibleTo(Json::arrayValue))
            return false;
        
        array = m_cValue[pszArrayKey];
    }
    
    array.append(fValue);
    m_cValue[pszArrayKey] = array;
    
    return true;
}


bool CDictionaryDataGather::InsertItemToArray(const char *pszArrayKey, const char * pszValue)
{
    Json::Value array;
    if(m_cValue.isMember(pszArrayKey))
    {
        if (!m_cValue[pszArrayKey].isArray() && !m_cValue[pszArrayKey].isConvertibleTo(Json::arrayValue))
            return false;
        
        array = m_cValue[pszArrayKey];
    }
    
    array.append(pszValue);
    m_cValue[pszArrayKey] = array;
    
    return true;
}


bool CDictionaryDataGather::InsertItemToArray(const char *pszArrayKey, CDictionaryDataGather * subDictionary)
{
    Json::Value array;
    if(m_cValue.isMember(pszArrayKey))
    {
        if (!m_cValue[pszArrayKey].isArray() && !m_cValue[pszArrayKey].isConvertibleTo(Json::arrayValue))
            return false;
        
        array = m_cValue[pszArrayKey];
    }
    
    array.append(subDictionary->m_cValue);
    m_cValue[pszArrayKey] = array;
    
    return true;
}


int CDictionaryDataGather::GetItemCount()
{
    return m_cValue.size();
}


DicItemType CDictionaryDataGather::GetItemType(int nIndex)
{
    return (DicItemType)m_cValue[nIndex].type();
}


DicItemType CDictionaryDataGather::GetItemType(const char *pszKey)
{
    return (DicItemType)m_cValue[pszKey].type();
}


vector<string> CDictionaryDataGather::GetAllMemberNames()
{
    return m_cValue.getMemberNames();
}


int CDictionaryDataGather::GetIntValueFromArray(const char *pszArrayKey, int nIndex, int nDefaultValue)
{
    int nRet = nDefaultValue;
    Json::Value * arrayValue = ValidateArrayItem(pszArrayKey, nIndex);
    if (arrayValue)
    {
        if ((*arrayValue)[nIndex].isNumeric())
            nRet = (*arrayValue)[nIndex].asInt();
    }

    return nRet;
}


double CDictionaryDataGather::GetFloatValueFromArray(const char *pszArrayKey, int nIndex, double fDefaultValue)
{
    double fRet = fDefaultValue;
    Json::Value * arrayValue = ValidateArrayItem(pszArrayKey, nIndex);
    if (arrayValue)
    {
        if ((*arrayValue)[nIndex].isNumeric())
            fRet = (*arrayValue)[nIndex].asDouble();
    }
    
    return fRet;
}


const char * CDictionaryDataGather::GetStringValueFromArray(const char *pszArrayKey, int nIndex)
{
    Json::Value * arrayValue = ValidateArrayItem(pszArrayKey, nIndex);
    if (arrayValue)
    {
        if ((*arrayValue)[nIndex].isString())
            return (*arrayValue)[nIndex].asCString();
    }
    
    return NULL;
}


CDictionaryDataGather * CDictionaryDataGather::GetSubItemFromArray(const char *pszArrayKey, int nIndex)
{
    Json::Value * arrayValue = ValidateArrayItem(pszArrayKey, nIndex);
    if (arrayValue)
    {
        if ((*arrayValue)[nIndex].isArray() || (*arrayValue)[nIndex].isObject())
        {
            CDictionaryDataGather * pNewDictionary = new CDictionaryDataGather();
            pNewDictionary->InitWithValue((*arrayValue)[nIndex]);
            return pNewDictionary;
        }
    }
    
    return NULL;
}


DicItemType CDictionaryDataGather::GetItemTypeFromArray(const char *pszArrayKey, int nIndex)
{
    Json::Value * arrayValue = ValidateArrayItem(pszArrayKey, nIndex);
    if (arrayValue)
        return (DicItemType)((*arrayValue)[nIndex].type());
    
    return (DicItemType)Json::nullValue;
}


inline bool CDictionaryDataGather::IsKeyValidate(const char *pszKey, Json::Value& root)
{
    if (root.isNull() || !root.isMember(pszKey))
        return false;
    
    return true;
}


inline Json::Value * CDictionaryDataGather::ValidateArrayItem(const char *pszArrayKey, int nIndex)
{
    if (!IsKeyValidate(pszArrayKey, m_cValue) && !m_cValue[pszArrayKey].isArray() && !m_cValue[pszArrayKey].isConvertibleTo(Json::arrayValue))
        return NULL;
    if (!m_cValue[pszArrayKey].isValidIndex(nIndex))
        return NULL;
    
    return &m_cValue[pszArrayKey];
}



