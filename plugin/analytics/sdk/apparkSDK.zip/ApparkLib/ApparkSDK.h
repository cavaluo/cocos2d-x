//
//  ApparkSDK.h
//  ApparkTest
//
//  Created by XiaoFeng on 12-1-31.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#ifndef ApparkTest_ApparkSDK_h
#define ApparkTest_ApparkSDK_h

#include <iostream>
#include "CommonDef.h"
#include "LocalSettingManager.h"
#include "LogManager.h"
#include "DataGather.h"
#include "UserAnalytic.h"
#include "GameDataManager.h"
#include "Device_Wrapper.h"
#include "FileManger_Wrapper.h"

using namespace std;
using namespace ApparkSDK;

namespace ApparkSDK
{
    class CApparkSDK
    {
        
    public:
        CApparkSDK();
        ~CApparkSDK();
        bool InitAppark(const char * pszAppID, const char * pszAppVersion, const char * pszDeviceToken, const char * pszLogPath = NULL);
        void SetGPSInfo(double dLongitude, double dLatitude, float fHorizontalAccuracy, float fVerticalAccuracy);
        bool IsInitialized();
        void NotifyServerFirstRun();
//        void SetDeviceToken(const char * pszToken);

    public: // SDK 内部使用 
        string& GetLogPath();
        string& GetAppVersion();
        string& GetAppID();
        string& GetSDKVersion();

        void FlushLogs();
        void NetStatusChange(const char * pszNewStatus);

    public:
        bool    m_bIsInitialized;
        string  m_strLogPath;
        string  m_strAppID;
        string  m_strAppVersion;
        string  m_strDeviceToken;
        string  m_strSDKVersion;
        double  m_dLongitude;
        double  m_dLatidude;
        float   m_fHorizontalAccuracy;
        float   m_fVerticalAccuracy;
        CDeviceInfo m_cDeviceInfo;
        CLogManager * m_pLogManager;
        CLocalSettingManager * m_pSettingManager;
        CUserAnalytic * m_pUserAnalyticLog;
        CDataGather * m_pDataGather;
        CGameDataManager * m_pGameDataManager;
        CFileManager * m_pFileManger;

    protected:
        void CleanUp();

    private:
        static void * FirstRunNotifyThreadFunc(void * param);
    };
}

#endif
