//
//  HttpRequest.h
//  ApparkTest
//
//  Created by steve fan on 12-2-7.
//  Contributed by lvyile on 12-2-8.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#ifndef _HTTPREQUEST_H_
#define _HTTPREQUEST_H_

#include <iostream>
#include <string>
#include "curl.h"
#include <pthread.h>

namespace ApparkSDK
{

    /* Default values used in CHttpRequest */
    namespace CHttpRequestDefaults
    {
        /* Constants */
        const int CHTTPREQUEST_DEFAULT_BUFFSIZE = 1024;
        const char CHTTPREQUEST_EOS = 0;
    };

    typedef void (*CALLBACK_FUNC)(void *, void *, bool) ;

    typedef enum _HttpStatusCode // HTTP状态码 
    {
        HttpStatusCodeContinue = 100,   // Continue指示客户端可能继续其请求。 
        HttpStatusCodeSwitchingProtocols = 101, // SwitchingProtocols 指示正在更改协议版本或协议。 
        HttpStatusCodeOK = 200, // OK 指示请求成功，且请求的信息包含在响应中。 这是最常接收的状态代码。 
        HttpStatusCodeCreated = 201,    // Created 指示请求导致在响应被发送前创建新资源。 
        HttpStatusCodeAccepted = 202,   // Accepted 指示请求已被接受做进一步处理。 
        HttpStatusCodeNonAuthoritativeInformation = 203,    // NonAuthoritativeInformation 指示返回的元信息来自缓存副本而不是原始服务器，因此可能不正确。 
        HttpStatusCodeNoContent = 204,  // NoContent 指示已成功处理请求并且响应已被设定为无内容。 
        HttpStatusCodeResetContent = 205,   // ResetContent 指示客户端应重置（或重新加载）当前资源。 
        HttpStatusCodePartialContent = 206, // PartialContent 指示响应是包括字节范围的 GET 请求所请求的部分响应。 
        HttpStatusCodeMultipleChoices = 300,    // MultipleChoices 指示请求的信息有多种表示形式。 默认操作是将此状态视为重定向，并遵循与此响应关联的 Location 头的内容。如果 HttpWebRequest.AllowAutoRedirect 属性为 false，则 MultipleChoices 将导致引发异常。MultipleChoices 是 Ambiguous 的同义词。 
        HttpStatusCodeMovedPermanently = 301,   // MovedPermanently 指示请求的信息已移到 Location 头中指定的 URI 处。 接收到此状态时的默认操作为遵循与响应关联的 Location 头。MovedPermanently 是 Moved 的同义词。 
        HttpStatusCodeFound = 302,  // Found 指示请求的信息位于 Location 头中指定的 URI 处。 接收到此状态时的默认操作为遵循与响应关联的 Location 头。 原始请求方法为 POST 时，重定向的请求将使用 GET 方法。如果 HttpWebRequest.AllowAutoRedirect 属性为 false，则 Found 将导致引发异常。Found 是 Redirect 的同义词。 
        
        HttpStatusCodeSeeOther = 303,   // 作为 POST 的结果，SeeOther 将客户端自动重定向到 Location 头中指定的 URI。 用 GET 生成对 Location 头所指定的资源的请求。如果 HttpWebRequest.AllowAutoRedirect 属性为 false，则 SeeOther 将导致引发异常。SeeOther 是 RedirectMethod 的同义词。 
        HttpStatusCodeNotModified = 304,    // NotModified 指示客户端的缓存副本是最新的。 未传输此资源的内容。 
        HttpStatusCodeUseProxy = 305,   // UseProxy 指示请求应使用位于 Location 头中指定的 URI 的代理服务器。 
        HttpStatusCodeUnused = 306, // Unused 是未完全指定的 HTTP/1.1 规范的建议扩展。 
        HttpStatusCodeTemporaryRedirect = 307,  // TemporaryRedirect 指示请求信息位于 Location 头中指定的 URI 处。 接收到此状态时的默认操作为遵循与响应关联的 Location 头。 原始请求方法为 POST 时，重定向的请求还将使用 POST 方法。如果 HttpWebRequest.AllowAutoRedirect 属性为 false，则 TemporaryRedirect 将导致引发异常。TemporaryRedirect 是 RedirectKeepVerb 的同义词。 
        HttpStatusCodeBadRequest = 400, // BadRequest 指示服务器未能识别请求。 如果没有其他适用的错误，或者不知道准确的错误或错误没有自己的错误代码，则发送 BadRequest。 
        HttpStatusCodeUnauthorized = 401,   // Unauthorized 指示请求的资源要求身份验证。 WWW-Authenticate 头包含如何执行身份验证的详细信息。 
        HttpStatusCodePaymentRequired = 402,    // 保留 PaymentRequired 以供将来使用。 
        HttpStatusCodeForbidden = 403,  // Forbidden 指示服务器拒绝满足请求。 
        HttpStatusCodeNotFound = 404,   // NotFound 指示请求的资源不在服务器上。 
        HttpStatusCodeMethodNotAllowed = 405,   //  MethodNotAllowed 指示请求的资源上不允许请求方法（POST 或 GET）。 
        HttpStatusCodeNotAcceptable = 406,  // NotAcceptable 指示客户端已用 Accept 头指示将不接受资源的任何可用表示形式。 
        HttpStatusCodeProxyAuthenticationRequired = 407,    // ProxyAuthenticationRequired 指示请求的代理要求身份验证。 Proxy-authenticate 头包含如何执行身份验证的详细信息。 
        HttpStatusCodeRequestTimeout = 408, // RequestTimeout 指示客户端没有在服务器期望请求的时间内发送请求。 
        HttpStatusCodeConflict = 409,   // Conflict 指示由于服务器上的冲突而未能执行请求。 
        HttpStatusCodeGone = 410,   // Gone 指示请求的资源不再可用。 
        HttpStatusCodeLengthRequired = 411, // LengthRequired 指示缺少必需的 Content-length 头。 
        HttpStatusCodePreconditionFailed = 412, // PreconditionFailed 指示为此请求设置的条件失败，且无法执行此请求。 条件是用条件请求标头（如 If-Match、If-None-Match 或 If-Unmodified-Since）设置的。 
        HttpStatusCodeRequestEntityTooLarge = 413,  // RequestEntityTooLarge 指示请求太大，服务器无法处理。 
        HttpStatusCodeRequestUriTooLong = 414,  // RequestUriTooLong 指示 URI 太长。 
        HttpStatusCodeUnsupportedMediaType = 415,   // UnsupportedMediaType 指示请求是不支持的类型。 
        HttpStatusCodeRequestedRangeNotSatisfiable = 416,   // RequestedRangeNotSatisfiable 指示无法返回从资源请求的数据范围，因为范围的开头在资源的开头之前，或因为范围的结尾在资源的结尾之后。 
        HttpStatusCodeExpectationFailed = 417,  // ExpectationFailed 指示服务器未能符合 Expect 头中给定的预期值。 
        HttpStatusCodeInternalServerError = 500,    // InternalServerError 指示服务器上发生了一般错误。 
        HttpStatusCodeNotImplemented = 501,     // NotImplemented 指示服务器不支持请求的函数。 
        HttpStatusCodeBadGateway = 502,     // BadGateway 指示中间代理服务器从另一代理或原始服务器接收到错误响应。 
        HttpStatusCodeServiceUnavailable = 503,     // ServiceUnavailable 指示服务器暂时不可用，通常是由于过多加载或维护。 
        HttpStatusCodeGatewayTimeout = 504,     // GatewayTimeout 指示中间代理服务器在等待来自另一个代理或原始服务器的响应时已超时。 
        HttpStatusCodeHttpVersionNotSupported = 505,    // HttpVersionNotSupported 指示服务器不支持请求的 HTTP 版本。 
    }EHttpStatusCode;
    
    typedef enum _CommunicationType // 通讯类型 
    {
        cCommunicationTypeSync = 0, //√ 同步 
        cCommunicationTypeAsync,    // 异步 
    }CommunicationType;
    
    typedef enum _iOperationMethod // 通讯类型 
    {
        iOperationMethodPost = 0,   // √ Post
        iOperationMethodGet,        // √ Get
        iOperationMethodPut,        // Put
    }OperationMethod;
    
    class CHttpRequest
    {
    public:
        CHttpRequest();
        ~CHttpRequest();

    public:
        OperationMethod m_iOperationMethod; //√ 数据访问类型,post、get、put等 
                                            //////////如何用上边的宏呢？HttpStatusCode
        unsigned long m_iOperationResult; //√ 服务器请求返回的状态值 
        std::string m_cReceivedData;   //√ 服务器获取的数据 

        void SetRequestURL(const char *url);  //√ 设定访问服务器的URL地址 
        void SetMessageToServer(const char * message);    //√ 设定向服务器提交的消息内容。 
        void SetNotifyFunc(CALLBACK_FUNC func); //√ 设定回调函数指针。 
        bool StartRequest(CommunicationType type, void * pCallBackParam); //启动与服务器通讯。type为通讯类型,分为同步和异步。返回值为与服务器交互是否成功。异步通 讯返回成功只表示启动成功,通讯的最终结果在回调函数中通知调用者。 pCallBackParam为在异步通讯时用户指定的调用通知函数向调用者传回的参数 指针。 
        bool BeginAsynTransfer();
        //////////暂不实现 
        void CancelRequest();
        const char * GetErrorMessage(); //√ 获取错误信息 
        void getSuccesfulInfo(bool ret);

    public:
        //////////暂不实现 
        CALLBACK_FUNC m_fCallBackFunc;  //异步通讯服务器返回结果通知回调函数指针。 
        std::string m_sErrorMessage;    //√ 错误信息 
        std::string m_sMessageToServer; //向服务器提交的数据 
        std::string m_sRequestURL;      //√ 连接服务器的URL地址 
                                        //////////暂不实现    
        void * m_sUserParam;            //用户设定的在回调时传回的参数指针 
        void * m_pCallbackParam;
        pthread_t m_pTID;

        // 内部调用，不是UML图上的 
        bool performGet( const std::string& getUrl );   //√ curl同步Get
        bool performPost( const std::string& postUrl, std::string dataStr = "" ); //√ curl同步Post
        bool performPost( const std::string& postUrl, const char * pszPostData, size_t length);
        
        bool performDownload(const std::string& fileUrl, const std::string& localFile);   // 下载文件到本地 

        /* cURL data */
        CURL* m_curlHandle;     //curl实例句柄 
        char m_errorBuffer[CHttpRequestDefaults::CHTTPREQUEST_DEFAULT_BUFFSIZE];
        std::string m_callbackData; 

        /* cURL APIs */
        bool isCurlInit();        //检测是否初始化curl
        int saveLastWebResponse(  char*& data, size_t size );
        void getLastWebResponse( std::string& outWebResp /* out */ );

    private:
        /* Internal cURL related methods */
        static int curlCallback( char* data, size_t size, size_t nmemb, CHttpRequest* pRequestObj );
        static int curlDownloadCallback( char* data, size_t size, size_t nmemb, CHttpRequest* pRequestObj );
        void clearCurlCallbackBuffers();
        void prepareStandardParams();    
        void GetStatusCode();

        std::string char2hex( char dec );
        std::string urlencode( const std::string &c );

        std::string m_strLocalFilename;
        int         m_nWriteSize;
        FILE        *m_pFileHandle;
    };

}
#endif
