//
//  LocalSettingManager.h
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-9.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#ifndef ApparkTest_LocalSettingManager_h
#define ApparkTest_LocalSettingManager_h

#include <time.h>
//#include "JsonReader.h"
//#include "JsonWriter.h"
#include "HttpRequest.h"
#include "CommonDef.h"

using namespace std;

#define UPLOADING_LIMITION_3G   (500 * 1024)
#define UPLOADING_CYCLE_3G      (60 * 60 * 24)

#define SETTING_FILE_NAME   "Appark.crs"

#define DEFAULT_SET_LOGSIZE         (30720)     // 默认log文件分割大小30K
#define DEFAULT_SET_AGDLOGSIZE      (30720)     // 默认AGDLog文件分割大小 
#define DEFAULT_SET_STARTTIME       0           // 默认全时间都可以上传 
#define DEFAULT_SET_ENDTIME         0
#define DEFAULT_SET_LASTUPDATE      0           // 未更新过数据 
#define DEFAULT_SET_UPDATEGAP       (60*60*4)   // 默认SDK设置每4小时更新一次 
#define DEFAULT_SET_FORCEUP         (60*60*3)   // 默认超过3小时的Log文件强制上传 
#define DEFAULT_SET_AGDFORCEUP      (60*60)     // 默认超过1小时的AGDLog文件强制上传 
#define DEFAULT_SET_USE3GNET        1
#define DEFAULT_SET_LOGUPLOADING    1
#define DEFAULT_SET_ENABLEUSERLOG   1
#define DEFAULT_SET_NEEDFIRSTNOTIFY 0

#define DEFAULT_SET_LASTUPLOADTIME  0
#define DEFAULT_SET_UPLOADCOUNT     0

#define APPARK_SETKEY_LOGSIZE           "LogFileSize"
#define APPAPPARK_SETKEY_AGDLOGSIZE     "AGDLogFileSize"
#define APPARK_SETKEY_STARTTIME         "UploadStartTime"
#define APPARK_SETKEY_ENDTIME           "UploadEndTime"
#define APPARK_SETKEY_LASUPDATE         "LastUpdate"
#define APPARK_SETKEY_UPDATEGAP         "UpdateGap"
#define APPARK_SETKEY_FORCEUP           "ForceUp"
#define APPARK_SETKEY_AGDFORCEUP        "AGDForceUp"
#define APPARK_SETKEY_USE3GNET          "Uppload3G"
#define APPARK_SETKEY_NEEDFIRSTNOTIFY   "FirstTimeNotice"
#define APPARK_SETKEY_ENABLELOGUPLOAD   "EnableLogUploading"
#define APPARK_SETKEY_ENABLEUSERLOG     "EnableUserLog"

#define APPARK_SETKEY_LASTUPLOADTIME    "LastUpload"
#define APPARK_SETKEY_UPLOADCOUNT       "UploadCount"

namespace ApparkSDK
{
    class CLocalSettingManager
    {
    public:
        bool Init(const char * pszLogPath, void * pApparkSDK);
        bool ReadLocalSetting(const char * pszSettingFile);
        bool SaveLocalSetting(const char * pszSettingFile);
        void UpdateSettingFromServer();
        void RefreshLocalSettingFile();
        bool IsUserDataUploadable();
        void UpdateUploadCount(unsigned int nSize);

        bool Check3GLimition();
        void Update3GUploadingSize(unsigned int nSize);

        int getLogFileSizeLimit();
        time_t getUploadTimeBegin();
        time_t getUploadTimeEnd();
        time_t getLastUpdateTime();
        time_t getUpdateGap();
        time_t getForceUploadTime();
        bool getUploadBy3G();
        bool getEnableUploadLog();
        bool getEnableUserLog();
        const char * getCurrentLogFileName();
        const char * getCurrentAGDLogFileName();
        int getAGDLogFileSizeLimit();
        time_t getAGDForceUploadTime();
        time_t getLastUploadBeginTime();
        unsigned int getUploadDataCount();

        bool    m_bNeedFistNotify;

    protected:
        void LoadDefaultSetting();
        bool LoadSettingFromEncryptData(char * pszDataBuf, int nSize);
        void LoadSettingFromJsonString(char * pszJson);
        static void * SettingUpdateThreadFunc(void * param);
        void DoSettingUpdate();

#ifdef APPARK_PUNCHBOX_PRIVATE
        bool SetPrivateSetting(bool bEnableLog, bool bEnableUpload);
#endif

    private:
        string  m_strSettingFile;
        int     m_nLogFileSizeLimit;
        time_t  m_nUploadTimeBegin;
        time_t  m_nUploadTimeEnd;
        time_t  m_nLastUpdateTime;
        time_t  m_nUpdateGap;
        time_t  m_nForceUploadTime;
        bool    m_bUploadBy3G;
        bool    m_bEnableUploadLog;
        bool    m_bEnableUserLog;
        std::string m_sCurrentLogFileName;      //当前保存Log记录的文件名 
        std::string  m_sCurrntAGDLogFileName;   //当前保存SDK记录的文件名字 
        int     m_nAGDLogFileSizeLimit;         //针对自动抓取用户数据记录的文件限制 
        time_t  m_nAGDForceUploadTime;          //自动抓取的用户数据上传时间限制 
        time_t  m_nLastUploadBeginTime;
        unsigned int m_nUploadDataCount;
        bool    m_bIsInProcessing;

#ifdef APPARK_PUNCHBOX_PRIVATE
        bool    m_bAppChangeSetting;
        bool    m_bAppSetLog;
        bool    m_bAppSetUploading;
#endif

    protected:
        void *  m_pApparkSDK;
    };

}


#endif
