//
//  TimeEvent.cpp
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-13.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#include <iostream>
#include "TimeEvent.h"
#include "LogManager.h"
#include "CommonDef.h"

using namespace ApparkSDK;

CTimeEvent::CTimeEvent()
{
    m_strEventID    = "";
    m_strSessionID  = "";
    m_nStartTime    = 0;
    m_nEventDuration= 0;

    m_cStartParameters.CleanUp();
    m_cEndParamters.CleanUp();
}


void CTimeEvent::StartEvent(const char * pszEventID, const char * pszSessionID, CDictionaryDataGather * pParams)
{
    m_strEventID        = pszEventID;
    m_strSessionID      = pszSessionID;
    m_nStartTime        = time(NULL);
    m_cStartParameters  = *pParams;
}


void CTimeEvent::FinishEvent(CDictionaryDataGather * pParams)
{
    m_cEndParamters  = *pParams;
    time_t curTime   = time(NULL);
    m_nEventDuration = curTime - m_nStartTime;
}


const char * CTimeEvent::GetEventID()
{
    return m_strEventID.c_str();
}


string CTimeEvent::GetEventDiscription()
{
    CDictionaryDataGather TimeEventDict;
    tm * startTime = localtime(&m_nStartTime);
    char szBuf[32] = {0};
    sprintf(szBuf, "%04d-%02d-%02d %02d:%02d:%02d", startTime->tm_year + 1900, 
            startTime->tm_mon + 1, startTime->tm_mday, startTime->tm_hour, 
            startTime->tm_min, startTime->tm_sec);
    TimeEventDict.InsertItem(USERLOG_TIMEVENT_BEGIN, szBuf);
    TimeEventDict.InsertItem(USERLOG_TIMEVENT_DURATION, (int)m_nEventDuration);
    TimeEventDict.InsertItem(USERLOG_TYPE_KEY, USERLOG_TYPE_TIMEEVENT);
    TimeEventDict.InsertItem(USERLOG_SESSION_ID, m_strSessionID.c_str());
    TimeEventDict.InsertItem(USERLOG_EVENT_ID, m_strEventID.c_str());
    TimeEventDict.InsertItem(USERLOG_TIMEVENT_BEGINPARAM, &m_cStartParameters);
    TimeEventDict.InsertItem(USERLOG_TIMEVENT_ENDPARAM, &m_cEndParamters);
    string strReturn = TimeEventDict.GetDescription();
    return strReturn;
}


bool CTimeEvent::IsEqualEvent(const char * pszEvendID)
{
    if (!pszEvendID) {
        return false;
    }
    return 0 == m_strEventID.compare(pszEvendID);
}


