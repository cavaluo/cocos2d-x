//
//  EncryptionManager.cpp
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-1.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#include "EncryptionManager.h"
#include "SupportingFiles/BaseAlgorithm.h"

using namespace ApparkSDK;

#define XXTEA_ALIGNMENT_BYTES   8

const uint32_t DefaultEncryptKey[4] = { 0x474DC838, 0xBB095D81, 0xE38E718F, 0x3FA91527 };

//const char szKey[]= "474DC838BB095D81";

size_t CEncryptionManager::Base64Encode(const unsigned char * pInputBuffer, 
                                        unsigned char * pOutputBuffer, 
                                        size_t nLength)
{
    size_t nResult = 0;

    if(pInputBuffer && pOutputBuffer && nLength > 0)
        return EnBase64(pOutputBuffer, pInputBuffer, nLength);
    else if(nLength > 0)
        nResult = ((nLength / 3) + (nLength % 3 ? 1 : 0)) * 4;

    return nResult;
}

size_t CEncryptionManager::Base64Decode(const unsigned char * pInputBuffer, 
                                        unsigned char * pOutputBuffer)
{
    size_t nResult = 0;

    if(pInputBuffer && pOutputBuffer)
    {
        return UnBase64(pOutputBuffer, pInputBuffer, strlen((char *)pInputBuffer));
    }
    else if(pInputBuffer)
    {
        nResult = strlen((char *)pInputBuffer);
        if(nResult)
            nResult = ((nResult / 4) + (nResult % 4 ? 1 : 0)) * 3;
    }

    return nResult;
}


size_t CEncryptionManager::XXTEAEncode(const unsigned char * pInputBuffer, 
                                       unsigned char * pOutputBuffer, 
                                       size_t nLength, 
                                       const_uint_ptr pUserDefineKey)
{
    size_t nResult = 0;
    if (pInputBuffer && pOutputBuffer && nLength > 0)
    {
        nResult = nLength / XXTEA_ALIGNMENT_BYTES + 
                    (nLength % XXTEA_ALIGNMENT_BYTES ? 1 : 0);
        memset(pOutputBuffer, 0, nResult * 8);
        memcpy(pOutputBuffer, pInputBuffer, nLength);
        unsigned int const * pnKey = pUserDefineKey ? (unsigned int const *)pUserDefineKey : DefaultEncryptKey;
        btea((uint32_t *)pOutputBuffer, nResult * 2, pnKey);

        nResult *= 8;
    }
    else if(nLength > 0)
        nResult = ((nLength / XXTEA_ALIGNMENT_BYTES) + 
                   (nLength % XXTEA_ALIGNMENT_BYTES ? 1 : 0)) * XXTEA_ALIGNMENT_BYTES;

    return nResult;
}


bool CEncryptionManager::XXTEADecode(const unsigned char * pInputBuffer, 
                                     unsigned char * pOutputBuffer, 
                                     size_t nLength, 
                                     const_uint_ptr pUserDefineKey)
{
    if(nLength % 4)
        return false;

    bool result = false;

    if(pInputBuffer && pOutputBuffer && nLength > 0)
    {
        int nSize = (nLength / XXTEA_ALIGNMENT_BYTES) * 2;
        memset(pOutputBuffer, 0, nLength);
        memcpy(pOutputBuffer, pInputBuffer, nLength);
        unsigned int const * pnKey = pUserDefineKey ? (unsigned int const *)pUserDefineKey : DefaultEncryptKey;
        btea((uint32_t *)pOutputBuffer, -nSize, pnKey);
        result = true;
    }

    return result;
}


char * CEncryptionManager::URLEncode(const char * pInputBuffer, size_t nLenth)
{
    return tcurlencode(pInputBuffer, nLenth);
}


char * CEncryptionManager::URLDecode(const char * pInputBuffer, size_t * pnOutLength)
{
    return tcurldecode(pInputBuffer, (int *)pnOutLength);
}


void CEncryptionManager::ConfuseString(char * pszText)
{
    int nLength = strlen(pszText);
    char *pCurPos = pszText, *pEndPos = pszText + nLength;
    while (pEndPos - pCurPos > 4)
    {
        char cTemp = *pCurPos;
        *pCurPos = *(pCurPos + 1);
        *(pCurPos + 1) = cTemp;
        pCurPos += 2;
    }
}


