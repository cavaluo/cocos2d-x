//
//  GameDataManager.h
//  ApparkTest
//
//  Created by lvyile on 2/9/12.
//  Copyright (c) 2012 CocoaChina.com. All rights reserved.
//

#ifndef _GAMEDATAMANAGER_H
#define _GAMEDATAMANAGER_H

#include "HttpRequest.h"
#include "EncryptionManager.h"
#include "CommonDef.h"


namespace ApparkSDK
{

    typedef enum _EncryptOperationType {
        EncryptOperationTypeEncryption = 0, // 加密 
        EncryptOperationTypeDecryption, // 解密 
        EncryptOperationTypeNone,   // 不处理 
    } EncryptOperationType;
    
    class CGameDataManager{
    public:
        CGameDataManager();
        ~CGameDataManager();    
    public:
        
        bool Init();  // 初始化函数。SDKBase为SDK基础模块类对象。返回结果为是否初始化成功。    
        bool SubmitGameData(const char * ServerURL, char * LocalFullPath, EncryptOperationType EncryptOperation, const_uint_ptr UserDefineKey=NULL); // 向服务器提交游戏数据。 
        
        bool DownloadGameData(const char * ServerURL, char * LocalFullPath, EncryptOperationType EncryptOperation, const_uint_ptr UserDefineKey=NULL);   // 从服务器下载游戏 数据。 
        
        bool SubmitDataBuffer(const char * ServerURL, char * DataBuffer, EncryptOperationType EncryptOperation, const_uint_ptr UserDefineKey=NULL); //向服务器提交游戏数据。ServerURL为􏰁交到的服务器地址,DataBuffer为需要向服务器􏰁交的数 据缓存,EncryptOperation为对本地文件数据进行哪种加密操作(加密、解密、 不处理),UkerDefineKey为用户定义的密钥数据,如果为空指针使用SDK内置 加密密钥。返回结果为是否􏰁交成功。 
        bool DownloadToBuffer(const char * ServerURL, char ** buffer, EncryptOperationType EncryptOperation, const_uint_ptr UserDefineKey=NULL);    // 从服务器下载游戏 数据。ServerURL为􏰁交到的服务器地址,buffer为用于接收数据缓存指针的指针,数据不再需要时调用者负责释放缓存,EncryptOperation为对从服务器获 取的数据进行哪种加密操作(加密、解密、不处理),UkerDefineKey为用户定 义的密钥数据,如果为空指针使用SDK内置加密密钥。返回结果为是否获取数据 成功 
        
        static bool Encrypt(const unsigned char * input, unsigned char ** output, const_uint_ptr UserDefineKey);
        static bool Decrypt(const unsigned char * input, unsigned char ** output, const_uint_ptr UserDefineKey);
        bool GameDataRequest(const char * ServerURL, bool isSubmit, const char * submitData = NULL);
        
        bool LocalFileReader(const char * LocalFullPath /* IN */, unsigned char ** fileData /* OUT */);
        bool LocalFileWriter(const char * LocalFullPath /* IN */, const char * fileData /* IN */);    
        void LocalBufferWriter(const char * input /* IN */, char ** outBuffer /* OUT */);        
        
        bool HandleDataEncryption(unsigned char * input, unsigned char ** output, EncryptOperationType EncryptOperation, const_uint_ptr UserDefineKey);    

    protected:
        
        CHttpRequest *m_pHttpOperator;     // http通讯处理类对象   
                                           //    CEncryptionManager *m_pEncryptor;  // 对传输数据进行加密、解密的类对象。    
        
    private:
        
    };
    
}

#endif
