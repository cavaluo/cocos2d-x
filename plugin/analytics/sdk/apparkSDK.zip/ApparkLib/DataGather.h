//
//  DataGather.h
//  ApparkTest
//
//  Created by lvyile on 2/12/12.
//  Copyright (c) 2012 CocoaChina.com. All rights reserved.
//

#ifndef _DATAGATHER_H_
#define _DATAGATHER_H_

using namespace std;

//#include "JsonWriter.h"
#include "CommonDef.h"
#include "LocalSettingManager.h"
#include "LogManager.h"
#include "DictionaryDataGather.h"

using namespace ApparkSDK;

namespace ApparkSDK {

    class CDataGather {
    public:
        CDataGather();
        ~CDataGather();

        time_t m_lLastSessionEndTime;  //记录上次SessionEndTime
    // 10个参数 
    protected:
        std::string m_sAppStartTime;    //程序本次启动时间。 
        CLogManager * m_pLogManager;    //log信息处理类对象。        
        time_t m_lAppStartTime;         //程序本次启动时间。 
        time_t m_lSessionStartTime;     //进程本次启动时间。 
        
     private:
        CDictionaryDataGather * m_pInfoFormatter;     //对信息进行格式化的JsonWriter对象。 
        bool m_bLastNetwordStatus;          //上次检测时的网络访问状态。 
        string m_sLastLanguageSetting;      //上次检测时设备的首选语言设置。 
        string m_sLastTimeZoneSetting;      //上次检测时的当前时区设置。 
//        CCrashCatcher *m_pCrashCatcher;   //崩溃信息监测类对象。 
//        CInstalledAppManager *m_pInstalledAppManager       //设备中已安装应用监测类对象。 
//        Array<AppID> OldAppList上次检测时设备中已安装的应用列表。 

        vector<string> OldAppList; //上次检测时设备中已安装的应用列表 
        void FormatTime(time_t time, std::string& outputString);
        
    // 15个函数 
    public:        
        bool Init(CLogManager *LogManager); //初始化函数,由外部传入LogManager指针。返回值为是否初始化成功。 
        void StartDataGathering();  //启动用户数据采集功能。 在mm接口中实现 
        bool AddToLocalLog(char * message, int Type); //将信息保存到Log中。Message为JsonWriter格式化后的json数据􏰀述字符串。返回值为记录是否保存成功。        
        bool LogAppStart(time_t StartTime);    // 记录应用启动时间。StartTime为程序启动时间。返回值为记录是否保存成功。 
        bool LogAppFinished(time_t EndTime);    // 记录应用退出时间。EndTime为程序退出时间。返回值为记录是否保存成功。 
        bool LogSessionStart(time_t StartTime);    // 记录进程启动时间。StartTime为程序启动时间。返回值为记录是否保存成功。 
        bool LogSessionEnd(time_t EndTime);    // 记录进程退出时间。EndTime为程序退出时间。返回值为记录是否保存成功。 
     
        bool LogCrashInfo(time_t CrashTime, const char * message);       //记录应用崩溃。 CrashTime为程序崩溃时间。Message为JsonWriter格式化后的崩溃􏰁述信息。 返回值为记录是否保存成功。 
        bool LogNetworkStatus(time_t time, bool AccessStatus);    //记录网络可访 问状态变化。Time为检测到网络可访问状态改变时间,AccessStatus为网络是 否可访问。返回值为记录是否保存成功。 
        bool LogLanguageChange(time_t time, char * NewLanguage);    //记录当前首 选语言的状态变化.time为检测到首选语言发生变化的时间,NewLanguage为新 的首选语言。返回值为记录是否保存成功。 
        bool LogTimeZoneChange(char * NewTimeZone);      //记录时区设置变化。 NewTimeZone为新的时区设置。返回值为记录是否保存成功。       
        bool LogInstalledAppChange(const char * AppList); //记录用户设备中安装应用发 生的变化。AppList为JsonWriter格式化过的当前安装应用列表。返回值为记录 是否保存成功。 
        vector<string> * GetCurrentInstalledApps();   //获取前次检测时的本机安装应 用列表。返回为应用ID数组。 
        
        char * GetCurrentLanguage();    //获取前次检测时的首选语言设置。返回值为 首选语言􏰁述。 
        char * GetCurrentTimezone();    //获取前次检测时的时区设置。返回值为时区􏰁 述。   };
    };
}

#endif
