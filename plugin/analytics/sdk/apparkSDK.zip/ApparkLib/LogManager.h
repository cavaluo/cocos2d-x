//
//  LogManager.h
//  ApparkTest
//
//  Created by steve fan on 12-2-7.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#ifndef ApparkTest_LogManager_h
#define ApparkTest_LogManager_h

#include "CommonDef.h"
#include "LocalSettingManager.h"
#include "LogUpLoader.h"
#include "FileManger_Wrapper.h"
#include "LocalSettingManager.h"

using namespace ApparkSDK;
using namespace std;

namespace ApparkSDK
{
    class CLogManager
    {
    public:
        CLogManager();
        ~CLogManager();

    public:
        CLocalSettingManager * m_pLocalSettingManager;  //本地数据设置管理类对象 
        std::string m_sCurrentLogFileName;      //当前保存Log记录的文件名 
        std::string m_sCurrentAGDLogFileName;   //当前保存SDK记录的文件名字 
        std::string m_sCurrentMassLogFileName;  //当前保存Mass记录的文件名 
        long m_iCurrentLogFilesSize;            //当前Log文件大小,以字节为单位。 
        long m_iCurrentAGDLogFilesSize;         //当前Log文件大小,以字节为单位。 
        long m_iCurrentMassLogFileSize;         //当前MassLog文件大小,以字节为单位。 
        bool m_bIsUploading;
        CFileManager m_fileManager;

        bool Init(void *apparkSDK, CLocalSettingManager *localSettingManager, const char* userDir = NULL);
//        bool Init(CLocalSettingManager *localSettingManager, const char* userDir = NULL);       //初始化函数， localSettingManager是本地默认设置类，userDir是用户自己指定的存放Log文件的文件夹 
        bool SaveMassiveDataLog(char * logInfo);  //用于记录频繁,大量的数据 
//        bool SaveLog(char * logInfo);


        //!!!!! 下面为内部使用函数，对外发布时必须隐藏 !!!!!!
        bool SaveLog(char * logInfo, EUserLogType logType);      //保存Log信息。LogInfo为需要写入到log文件的字符串, logType为游戏中的数据或是默认抓取的数据 
        bool SaveLog(char * logInfo, std::string logFileName, EUserLogType logType);
        bool SaveLogToFile();       //强制将Dictionary保存到文件 
        bool UploadGatherInfo();    //向服务器提交用户设备信息 
        bool SendLogToServer(char * fullpath, EUserLogType logType);    //向服务器提交log数据 
        void StartLogUploading();   // 启动Log文件上载线程 

        void SaveCrashLog(char * logInfo);
        
    protected:
        bool InitLogFiles();        // 初始化函数,返回值为是否初始化成功 
        bool IsLogUploadingEnable();

    protected:
        vector<string>  m_aFilesToUpload;

    private:
        std::string     m_sDefaultDir;
        time_t          m_iGameDataLastSaveTime;    //用于记录上次保存游戏日志的时间 
        time_t          m_iAGDLastSaveTime;         //用于记录上次保存AGD日志的时间 
        time_t          m_iMassLastSaveTime;        //用于记录上次保存Mass日志的时间 
        bool            m_bCanWriteUserLog;
        bool            m_bCanWriteAGDLog;
        bool            m_bFirstSaveLog;
        CLogUploader *  m_pLogUpLoader;             //用于向服务器􏰁交Log数据的类对象 

        CDictionaryDataGather m_cdictDestGameData;      //需要保存的游戏数据 
        CDictionaryDataGather m_cdictDestAGDData;       //需要保存的自动抓取数据 
        CDictionaryDataGather m_cdictDestMassData;      //需要保存的用户大数据量低优先级数据 

        long LogFileSize(char *filename);
        inline long filesize(FILE *stream);
        inline long filesize(char *pszFilename);
        bool InitDictionaryData(EUserLogType logType);
        void InsertItemToDictionary(std::string logInfo, CDictionaryDataGather& dict);
        inline void WriteToFile(const char *content, const char *fullPath);
        bool checkFileNeedUpload(char *filename, EUserLogType logType = eUserLogTypeGameData);     //检测文件是否需要上传,根据文件类型来区分 
        void sortFileName(std::vector<std::string>  fileNames); //对指定文件夹下的文件按时间排序 
        bool CheckLogFiles(CDictionaryDataGather& cFileListDict, EUserLogType nCheckType);
        bool CheckUserLogFiles();
        bool CheckAGDLogFiles();
        bool CheckMassLogFiles();
        bool CreateNewFileName(EUserLogType logType);

        static void * UploadLogsThreadFunc(void * param);
    };
}

#endif
