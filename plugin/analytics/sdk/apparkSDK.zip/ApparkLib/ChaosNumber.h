//
//  ChaosNumber.h
//  ApparkTest
//
//  Created by XiaoFeng on 12-3-29.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#ifndef ApparkTest_ChaosNumber_h
#define ApparkTest_ChaosNumber_h

typedef enum _valueType
{
    valueNone = 0,
    valueLong,
    valueFloat
}valueType;

namespace ApparkSDK
{
    class CChaosNumber
    {
    public:
        CChaosNumber();
        ~CChaosNumber();
        CChaosNumber(long lValue);
        CChaosNumber(float fValue);
        CChaosNumber(int nValue);
        CChaosNumber(CChaosNumber& another);

    public:
        float GetFloatValue();
        long  GetLongValue();
        void  SetFloatValue(float value);
        void  SetLongValue(long value);
        valueType GetValueType();

    public:
        // 重载操作符 
        operator long();
        operator float();
        operator int();

        // +, -, *, /, ++, --, ==, >=, <=, >, <
        CChaosNumber& operator=(CChaosNumber& another);
        CChaosNumber& operator=(long lValue);
        CChaosNumber& operator=(int nValue);
        CChaosNumber& operator=(float fValue);
        long operator+(long lValue);
        int operator+(int nValue);
        float operator+(float fValue);
        long operator-(long lValue);
        int operator-(int nValue);
        float operator-(float fValue);
        long operator*(long lValue);
        int operator*(int nValue);
        float operator*(float fValue);
        long operator/(long lValue);
        int operator/(int nValue);
        float operator/(float fValue);
        CChaosNumber& operator++();
        CChaosNumber& operator--();
        bool operator==(CChaosNumber& another);
        bool operator==(long lValue);
        bool operator==(int nValue);
        bool operator==(float fValue);
        bool operator>=(CChaosNumber& another);
        bool operator>=(long lValue);
        bool operator>=(int nValue);
        bool operator>=(float fValue);
        bool operator<=(CChaosNumber& another);
        bool operator<=(long lValue);
        bool operator<=(int nValue);
        bool operator<=(float fValue);
        bool operator>(CChaosNumber& another);
        bool operator>(long lValue);
        bool operator>(int nValue);
        bool operator>(float fValue);
        bool operator<(CChaosNumber& another);
        bool operator<(long lValue);
        bool operator<(int nValue);
        bool operator<(float fValue);

    private:
        void  GenerateOrder();
        void  PutValueToMatrix(void * pValue);
        void  GetValueFromMatric(void * pBuffer);

    private:
        char *  m_pMatrix;
        char    m_BytePos[4][2];
        valueType m_ValueType;
    };
}


#endif
