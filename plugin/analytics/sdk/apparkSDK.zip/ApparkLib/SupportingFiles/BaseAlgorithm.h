//
//  BaseAlgorithm.h
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-1.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#ifndef ApparkTest_Base64_h
#define ApparkTest_Base64_h
#ifndef uint32_t
typedef unsigned int uint32_t;
#endif

const char  table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

size_t EnBase64(unsigned char * dest, const unsigned char * src, size_t src_size);
size_t UnBase64(unsigned char * dest, const unsigned char * src, size_t src_size);

void btea(uint32_t *v, int n, uint32_t const key[4]);

char *tcurlencode(const char *ptr, int size);
char *tcurldecode(const char *str, int *sp);

#endif
