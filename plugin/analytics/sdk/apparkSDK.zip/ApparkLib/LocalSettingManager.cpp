//
//  LocalSettingManager.cpp
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-9.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#include <iostream>
#include "CommonDef.h"
#include "LocalSettingManager.h"
#include "DictionaryDataGather.h"
#include "EncryptionManager.h"
#include "HttpRequest.h"
#include "ApparkSDK.h"
#include <pthread.h>

using namespace std;
using namespace ApparkSDK;

bool CLocalSettingManager::Init(const char * pszLogPath, void * pApparkSDK)
{
    if (!pszLogPath) {
        m_strSettingFile = APPPARK_DEFAULTDIR;
    }
    else{
        m_strSettingFile = pszLogPath;
    }

    if (m_strSettingFile[m_strSettingFile.length() - 1] != '/')
        m_strSettingFile += "/";
    m_strSettingFile += SETTING_FILE_NAME;

    LoadDefaultSetting();

    ReadLocalSetting(m_strSettingFile.c_str());

    m_pApparkSDK = pApparkSDK;
    m_bIsInProcessing = false;

#ifdef APPARK_PUNCHBOX_PRIVATE
    m_bAppChangeSetting = false;
    m_bAppSetLog = false;
    m_bAppSetUploading = false;
#endif

    return true;
}

bool CLocalSettingManager::ReadLocalSetting(const char * pszSettingFile)
{
    bool bRet = false;
    FILE * f = fopen(pszSettingFile, "rb");
    if (f)
    {
        fseek(f, 0, SEEK_END);
        int nSize = ftell(f);
        rewind(f);
        if (nSize)
        {
            char * pszBuffer = (char *)malloc(nSize);   // 数据不作为字符串处理，不需要添加额外结束字符 
            ZeroMemory(pszBuffer, nSize);
            nSize = fread(pszBuffer, 1, nSize, f);
            bRet = LoadSettingFromEncryptData(pszBuffer, nSize);
            free(pszBuffer);
        }
        fclose(f);
    }

    return bRet;
}


// 设置数据只在SDK内部使用，本地存储只进行XXTEA加密，不作Base64
bool CLocalSettingManager::SaveLocalSetting(const char * pszSettingFile)
{
    bool bRet = false;
    CDictionaryDataGather dict;
    dict.InsertItem(APPARK_SETKEY_LOGSIZE, m_nLogFileSizeLimit);
    dict.InsertItem(APPAPPARK_SETKEY_AGDLOGSIZE, m_nAGDLogFileSizeLimit);
    dict.InsertItem(APPARK_SETKEY_FORCEUP, (int)m_nForceUploadTime);
    dict.InsertItem(APPARK_SETKEY_USE3GNET, (int)m_bUploadBy3G);
    dict.InsertItem(APPARK_SETKEY_UPDATEGAP, (int)m_nUpdateGap);
    dict.InsertItem(APPARK_SETKEY_LASUPDATE, (int)m_nLastUpdateTime);
    dict.InsertItem(APPARK_SETKEY_AGDFORCEUP, (int)m_nAGDForceUploadTime);
    dict.InsertItem(APPARK_SETKEY_STARTTIME, (int)m_nUploadTimeBegin);
    dict.InsertItem(APPARK_SETKEY_ENDTIME, (int)m_nUploadTimeEnd);
    dict.InsertItem(APPARK_SETKEY_NEEDFIRSTNOTIFY, m_bNeedFistNotify);
    dict.InsertItem(APPARK_SETKEY_ENABLELOGUPLOAD, m_bEnableUploadLog);
    dict.InsertItem(APPARK_SETKEY_ENABLEUSERLOG, m_bEnableUserLog);

    dict.InsertItem(APPARK_SETKEY_LASTUPLOADTIME, (int)m_nLastUploadBeginTime);
    dict.InsertItem(APPARK_SETKEY_UPLOADCOUNT, (int)m_nUploadDataCount);

    string strDictDes = dict.GetDescription();
    int nEncryptSize, nSize = strDictDes.length();
    nEncryptSize = CEncryptionManager::XXTEAEncode((const unsigned char *)strDictDes.c_str(), NULL, nSize);
    char * pszBuffer = (char *)malloc(nEncryptSize + EXTRA_TERMINATOR);
    ZeroMemory(pszBuffer, nEncryptSize + EXTRA_TERMINATOR);
    nSize = CEncryptionManager::XXTEAEncode((const unsigned char *)strDictDes.c_str(), (unsigned char *)pszBuffer, nSize);
    if (nSize > 0)
    {
        FILE * f = fopen(pszSettingFile, "wb+");
        if (f)
        {
            bRet = fwrite(pszBuffer, 1, nSize, f) >= nSize;
            fflush(f);
            fclose(f);
        }
    }

    free(pszBuffer);

    return bRet;
}


void CLocalSettingManager::UpdateSettingFromServer()
{
    pthread_t tid;
    int nRet = pthread_create(&tid,
                              (const pthread_attr_t *)NULL,
                              &SettingUpdateThreadFunc,
                              (void *)this);
#ifdef DEBUG
    if (!nRet)
        printf("\n%s\n", "Setting update thread start OK.");
    else
        printf("\n%s\n", "Setting update thread start failed!");
#endif
}


void CLocalSettingManager::DoSettingUpdate()
{
    time_t curTime = time(NULL);
    int nGap = curTime - m_nLastUpdateTime;
    if (nGap >= m_nUpdateGap)
    {
        CApparkSDK * pAppark = (CApparkSDK *)m_pApparkSDK;
        if (pAppark && pAppark->m_cDeviceInfo.m_sNetWork_type.compare(CURRENT_NET_CONNECTION_NONE) != 0)
        {
            CHttpRequest cHttpOperator;
            string strRequestURL = APPPARK_GETTINGSETURL;
            strRequestURL.append("&appid=");
            strRequestURL.append(pAppark->m_strAppID);
            strRequestURL.append("&appversion=");
            strRequestURL.append(pAppark->m_strAppVersion);
            strRequestURL.append("&sdkversion=");
            strRequestURL.append(pAppark->m_strSDKVersion);
            strRequestURL.append("&area=");
            strRequestURL.append(pAppark->m_cDeviceInfo.m_sArea);
            strRequestURL.append("&network_type=");
            strRequestURL.append(pAppark->m_cDeviceInfo.m_sNetWork_type);
            strRequestURL.append("&deviceType=");
            strRequestURL.append(pAppark->m_cDeviceInfo.m_sDeviceType);

            cHttpOperator.SetRequestURL(strRequestURL.c_str());
            cHttpOperator.m_iOperationMethod = iOperationMethodGet;
            if(cHttpOperator.StartRequest(cCommunicationTypeSync, NULL))
            {
                CDictionaryDataGather cDictRecieve;
                cDictRecieve.InitWithDescription(cHttpOperator.m_cReceivedData.c_str());
                const char * pszTemp = cDictRecieve.GetItemStringValue(SERVER_RETURN_STATUS);
                if(pszTemp && (strcmp(pszTemp, "ok") == 0))
                {
                    string strSetting = cDictRecieve.GetItemStringValue(SERVER_RETURN_DATA);
                    if (strSetting.length() <= 0 )
                        return;
                    char * deCodeBuffer = (char *)malloc(strSetting.length() + 4);
                    char * settingBuffer = (char *)malloc(strSetting.length() + 4);
                    ZeroMemory(deCodeBuffer, strSetting.length() + 4);
                    ZeroMemory(settingBuffer, strSetting.length() + 4);
                    strcpy(deCodeBuffer, strSetting.c_str());
                    CEncryptionManager::ConfuseString(deCodeBuffer);
                    CEncryptionManager::Base64Decode((const unsigned char *)deCodeBuffer, (unsigned char *)settingBuffer);
                    LoadSettingFromJsonString(settingBuffer);
                    free(settingBuffer);
                    free(deCodeBuffer);
                    m_nLastUpdateTime = curTime;
                    RefreshLocalSettingFile();
                }
            }
        }
    }
}


void CLocalSettingManager::LoadSettingFromJsonString(char * pszJson)
{
    if (!pszJson) {
        return;
    }
    CDictionaryDataGather dict;
    dict.InitWithDescription(pszJson);
#ifdef DEBUG
    printf("\n%s\n\n", dict.GetDescription().c_str());
#endif

    int nWaitCount = 0;
    while (m_bIsInProcessing && nWaitCount < 2)
    {
        sleep(1);
        nWaitCount++;
    }

    if (m_bIsInProcessing)
        return;

    m_bIsInProcessing = true;
    // 如果加密数据中的数据无效，则不改变当前设定 
    m_nLogFileSizeLimit     = dict.GetItemIntValue(APPARK_SETKEY_LOGSIZE, m_nLogFileSizeLimit);
    m_nAGDLogFileSizeLimit  = dict.GetItemIntValue(APPAPPARK_SETKEY_AGDLOGSIZE, m_nAGDLogFileSizeLimit);
    m_nForceUploadTime      = dict.GetItemIntValue(APPARK_SETKEY_FORCEUP, m_nForceUploadTime);
    m_nAGDForceUploadTime   = dict.GetItemIntValue(APPARK_SETKEY_AGDFORCEUP, m_nAGDForceUploadTime);

    int nTemp = dict.GetItemIntValue(APPARK_SETKEY_USE3GNET, m_bUploadBy3G);
    m_bUploadBy3G           = nTemp;

    m_nUpdateGap            = dict.GetItemIntValue(APPARK_SETKEY_UPDATEGAP, m_nUpdateGap);
    m_nLastUpdateTime       = dict.GetItemIntValue(APPARK_SETKEY_LASUPDATE, m_nLastUpdateTime);
    m_nUploadTimeBegin      = dict.GetItemIntValue(APPARK_SETKEY_STARTTIME, m_nUploadTimeBegin);
    m_nUploadTimeEnd        = dict.GetItemIntValue(APPARK_SETKEY_ENDTIME, m_nUploadTimeEnd);
    m_bNeedFistNotify       = dict.GetItemIntValue(APPARK_SETKEY_NEEDFIRSTNOTIFY, m_bNeedFistNotify);

    nTemp = dict.GetItemIntValue(APPARK_SETKEY_ENABLELOGUPLOAD, m_bEnableUploadLog);
    m_bEnableUploadLog      = nTemp;

    nTemp = dict.GetItemIntValue(APPARK_SETKEY_ENABLEUSERLOG, m_bEnableUserLog);
    m_bEnableUserLog        = nTemp;

    m_nLastUploadBeginTime  = dict.GetItemIntValue(APPARK_SETKEY_LASTUPLOADTIME, m_nLastUploadBeginTime);
    m_nUploadDataCount      = (unsigned int)dict.GetItemIntValue(APPARK_SETKEY_UPLOADCOUNT, m_nUploadDataCount);
#ifdef APPARK_PUNCHBOX_PRIVATE
    if (m_bAppChangeSetting)
    {
        m_bEnableUploadLog = m_bAppSetUploading;
        m_bEnableUserLog = m_bAppSetLog;
    }
#endif
    m_bIsInProcessing = false;
}


bool CLocalSettingManager::LoadSettingFromEncryptData(char * pszDataBuf, int nSize)
{
    bool bRet = false;

    if(pszDataBuf && (nSize > 0))
    {
        char * pszDecryptBuf = (char *)malloc(nSize + EXTRA_TERMINATOR);
        ZeroMemory(pszDecryptBuf, nSize);

        bRet = CEncryptionManager::XXTEADecode((const unsigned char *)pszDataBuf, (unsigned char *)pszDecryptBuf, nSize);
        if (bRet)
        {
            LoadSettingFromJsonString(pszDecryptBuf);
        }
        free(pszDecryptBuf);
    }

    return bRet;
}

void CLocalSettingManager::LoadDefaultSetting()
{
    m_nLogFileSizeLimit     = DEFAULT_SET_LOGSIZE;
    m_nAGDLogFileSizeLimit  = DEFAULT_SET_AGDLOGSIZE;
    m_nForceUploadTime      = DEFAULT_SET_FORCEUP;
    m_nAGDForceUploadTime   = DEFAULT_SET_AGDFORCEUP;
    m_nUpdateGap            = DEFAULT_SET_UPDATEGAP;
    m_bUploadBy3G           = DEFAULT_SET_USE3GNET;
    m_nLastUpdateTime       = DEFAULT_SET_LASTUPDATE;
    m_nUploadTimeBegin      = DEFAULT_SET_STARTTIME;
    m_nUploadTimeEnd        = DEFAULT_SET_ENDTIME;
    m_bNeedFistNotify       = DEFAULT_SET_NEEDFIRSTNOTIFY;
    m_bEnableUploadLog      = DEFAULT_SET_LOGUPLOADING;
    m_bEnableUserLog        = DEFAULT_SET_ENABLEUSERLOG;

    m_nLastUploadBeginTime  = DEFAULT_SET_LASTUPLOADTIME;
    m_nUploadDataCount      = DEFAULT_SET_UPLOADCOUNT;
}


void CLocalSettingManager::RefreshLocalSettingFile()
{
    SaveLocalSetting(m_strSettingFile.c_str());
}


void * CLocalSettingManager::SettingUpdateThreadFunc(void * param)
{
    CLocalSettingManager * psettingManager = (CLocalSettingManager *)param;
    psettingManager->DoSettingUpdate();
    return NULL;
}



bool CLocalSettingManager::Check3GLimition()
{
    bool bRet = false;
    if (m_bUploadBy3G)
    {
        time_t curTime = time(NULL);
        
        if (curTime - m_nLastUploadBeginTime > UPLOADING_CYCLE_3G)
        {
            m_nLastUploadBeginTime = curTime;
            m_nUploadDataCount = 0;
            bRet = true;
        }
        else
        {
            if (m_nUploadDataCount < UPLOADING_LIMITION_3G)
                bRet = true;
        }
    }
    
    return bRet;
}


void CLocalSettingManager::Update3GUploadingSize(unsigned int nSize)
{
    m_nUploadDataCount += nSize;
}

int CLocalSettingManager::getLogFileSizeLimit()
{
    return m_nLogFileSizeLimit;
}

time_t CLocalSettingManager::getUploadTimeBegin()
{
    return m_nUploadTimeBegin;
}

time_t CLocalSettingManager::getUploadTimeEnd()
{
    return m_nUploadTimeEnd;
}

time_t CLocalSettingManager::getLastUpdateTime()
{
    return m_nLastUpdateTime;
}

time_t CLocalSettingManager::getUpdateGap()
{
    return m_nUpdateGap;
}

time_t CLocalSettingManager::getForceUploadTime()
{
    return m_nForceUploadTime;
}

bool CLocalSettingManager::getUploadBy3G()
{
    return m_bUploadBy3G;
}

bool CLocalSettingManager::getEnableUploadLog()
{
    return m_bEnableUploadLog;
}

bool CLocalSettingManager::getEnableUserLog()
{
    return m_bEnableUserLog;
}

const char * CLocalSettingManager::getCurrentLogFileName()
{
    return m_sCurrentLogFileName.c_str();
}

const char * CLocalSettingManager::getCurrentAGDLogFileName()
{
    return m_sCurrntAGDLogFileName.c_str();
}

int CLocalSettingManager::getAGDLogFileSizeLimit()
{
    return m_nAGDLogFileSizeLimit;
}

time_t CLocalSettingManager::getAGDForceUploadTime()
{
    return m_nAGDForceUploadTime;
}

time_t CLocalSettingManager::getLastUploadBeginTime()
{
    return m_nLastUploadBeginTime;
}

unsigned int CLocalSettingManager::getUploadDataCount()
{
    return m_nUploadDataCount;
}




#ifdef APPARK_PUNCHBOX_PRIVATE
bool CLocalSettingManager::SetPrivateSetting(bool bEnableLog, bool bEnableUpload)
{
    bool bRet = false;

    int nWaitCount = 0;
    while (m_bIsInProcessing && nWaitCount < 2)
    {
        sleep(1);
        nWaitCount++;
    }

    if (!m_bIsInProcessing)
    {
        m_bIsInProcessing   = true;
        m_bAppSetLog        = bEnableLog;
        m_bAppSetUploading  = bEnableUpload;
        m_bAppChangeSetting = true;
        m_bEnableUserLog    = m_bAppSetLog;
        m_bEnableUploadLog  = m_bAppSetUploading;
        m_bIsInProcessing   = false;
        bRet = true;
    }

    return  bRet;
}

#endif

