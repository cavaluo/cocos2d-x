//
//  UserAnalytic.cpp
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-13.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#include <iostream>
#include "CommonDef.h"
#include "DictionaryDataGather.h"
#include "UserAnalytic.h"

using namespace ApparkSDK;

CUserAnalytic::CUserAnalytic()
{
    m_strUserAppVersion = "";
    m_strCurrentSession = "";
    m_pLogManager = NULL;
    m_aTimedEventList.clear();
}


CUserAnalytic::~CUserAnalytic()
{
    int nSize = m_aTimedEventList.size();
    if (m_aTimedEventList.size() > 0)
    {
        CDictionaryDataGather cDictEndParam;
        cDictEndParam.InsertItem(USERLOG_EVENT_AUTOCLOSE, "YES");
        for (int i = 0; i<nSize; i++)
        {
            m_aTimedEventList[i].FinishEvent(&cDictEndParam);
            m_pLogManager->SaveLog((char *)m_aTimedEventList[i].GetEventID(), eUserLogTypeGameData);
        }
    }
    m_aTimedEventList.clear();
}


bool CUserAnalytic::Init(CLogManager * pLogManager)
{
    if (!pLogManager) {
        return false;
    }
    m_pLogManager = pLogManager;
    return true;
}


void CUserAnalytic::LogGPSLocation(double dLongitude, double dLatitude, float fHorizontalAccuracy, float fVerticalAccuracy)
{
    CDictionaryDataGather cDictGPSInfo;
    cDictGPSInfo.InsertItem(USERLOG_TYPE_KEY, USERLOG_TYPE_GPSPOS);
    cDictGPSInfo.InsertItem(USERLOG_SESSION_ID, m_strCurrentSession.c_str());
    cDictGPSInfo.InsertItem(USERLOG_GPSINFO_LONGITUDE, dLongitude);
    cDictGPSInfo.InsertItem(USERLOG_GPSINFO_LATITUDE, dLatitude);
    cDictGPSInfo.InsertItem(USERLOG_GPSINFO_HORIZONTAL, fHorizontalAccuracy);
    cDictGPSInfo.InsertItem(USERLOG_GPSINFO_VERTICAL, fVerticalAccuracy);
    string strDescript = cDictGPSInfo.GetDescription();
    m_pLogManager->SaveLog((char *)strDescript.c_str(), eUserLogTypeAGD);
}


void CUserAnalytic::StartSession(const char * pszSessionID)
{
    if(pszSessionID && *pszSessionID)
        m_strCurrentSession = pszSessionID;
    else
    {
        time_t curTime = time(NULL);
        tm * fmtTime = localtime(&curTime);
        char szTemp[32] = {0};
        sprintf(szTemp, "%04d-%02d-%02d %02d:%02d:%02d", fmtTime->tm_year + 1900, 
                fmtTime->tm_mon + 1, fmtTime->tm_mday, fmtTime->tm_hour, 
                fmtTime->tm_min, fmtTime->tm_sec);
    }
}


void CUserAnalytic::SetUserInfo(const char * pszUserName, int nAge, int nGender)
{
    CDictionaryDataGather cDictUserInfo;
    cDictUserInfo.InsertItem(USERLOG_TYPE_KEY, USERLOG_TYPE_GPSPOS);
    cDictUserInfo.InsertItem(USERLOG_SESSION_ID, m_strCurrentSession.c_str());
    cDictUserInfo.InsertItem(USERLOG_USERINFO_ACCOUNT, pszUserName);
    cDictUserInfo.InsertItem(USERLOG_USERINFO_AGE, nAge);
    cDictUserInfo.InsertItem(USERLOG_USERINFO_GENDER, nGender);
    string strDescript = cDictUserInfo.GetDescription();
    m_pLogManager->SaveLog((char *)strDescript.c_str(), eUserLogTypeAGD);
}


void CUserAnalytic::LogEvent(const char * pszEventName, CDictionaryDataGather * pEventParams)
{
    CDictionaryDataGather cDictLog;
    cDictLog.InsertItem(USERLOG_TYPE_KEY, USERLOG_TYPE_NORMAL);
    cDictLog.InsertItem(USERLOG_SESSION_ID, m_strCurrentSession.c_str());
    cDictLog.InsertItem(pszEventName, pEventParams->GetDescription().c_str());
    string strDescript = cDictLog.GetDescription();
    m_pLogManager->SaveLog((char *)strDescript.c_str(), eUserLogTypeGameData);
}


void CUserAnalytic::LogError(const char * pszErrorID, const char *pszErrorMsg, CDictionaryDataGather * pErrorParams)
{
    CDictionaryDataGather cDictLog;
    cDictLog.InsertItem(USERLOG_TYPE_KEY, USERLOG_TYPE_ERROR);
    cDictLog.InsertItem(USERLOG_SESSION_ID, m_strCurrentSession.c_str());
    cDictLog.InsertItem(USERLOG_ERROR_ID, pszErrorID);
    cDictLog.InsertItem(USERLOG_ERROR_MESSAGE, pszErrorMsg);
    cDictLog.InsertItem(USERLOG_ERROR_PARAM, pErrorParams);
    string strDescript = cDictLog.GetDescription();
    m_pLogManager->SaveLog((char *)strDescript.c_str(), eUserLogTypeGameData);
}


void CUserAnalytic::LogTimedEvent(const char * pszEventID, CDictionaryDataGather * pEventParams)
{
    CTimeEvent newTimeEvent;
    newTimeEvent.StartEvent(pszEventID, m_strCurrentSession.c_str(), pEventParams);
    m_aTimedEventList.push_back(newTimeEvent);
}


void CUserAnalytic::EndTimedEvent(const char * pszEventID, CDictionaryDataGather * pEventParams)
{
    vector<CTimeEvent>::iterator item;
    for (item=m_aTimedEventList.begin(); item != m_aTimedEventList.end(); item++)
    {
        if(item->IsEqualEvent(pszEventID))
        {
            item->FinishEvent(pEventParams);
            string strDescript = item->GetEventDiscription();
            m_pLogManager->SaveLog((char *)strDescript.c_str(),eUserLogTypeGameData);
            m_aTimedEventList.erase(item);
            return;
        }
    }
}

//================== New log style test ==================//

void CUserAnalytic::LogEvent(const char * pszEventMsg)
{
    m_pLogManager->SaveLog((char *)pszEventMsg, eUserLogTypeGameData);
}


