//
//  Compressor.h
//  ApparkTest
//
//  Created by XiaoFeng on 12-5-21.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#ifndef ApparkTest_Compressor_h
#define ApparkTest_Compressor_h

#define DEFAULT_CHUNK_SIZE                  (256 * 1024)
#define MIN_CHUNK_SIZE                      1024

#define COMPRESSOR_ERR_CODE_NONE             0   // 没有错误 
#define COMPRESSOR_ERR_CODE_OUTOFFBUF       -1  // 输出Buffer不足 
#define COMPRESSOR_ERR_CODE_FILE_OPERATION  -2  // 文件操作失败 
#define COMPRESSOR_ERR_CODE_ZIPPROCESS      -3  // 压缩解压缩过程中出错 

namespace ApparkSDK
{
    class CCompressor
    {
    public:
        CCompressor();
        CCompressor(unsigned nChunkSize);
        
    public:
        void setChunkSize(unsigned nNewSize);
        
        size_t compressToBuffer(const char * pszFileName, char * pszOutBuf, size_t bufLen);
        size_t compressToBuffer(const char * pszInputBuf, size_t inputLen, char * pszOutBuf, size_t outputLen);
        bool compressToFile(const char * pszSrcFileName, const char * pszDestFileName);
        bool compressToFile(const char * pszInputBuf, size_t inputlen, const char * pszDestFileName);

        size_t compressToBuffer(const char * pszFileName, char * pszOutBuf, size_t bufLen, int nCompressLevel);
        size_t compressToBuffer(const char * pszInputBuf, size_t inputLen, char * pszOutBuf, size_t outputLen, int nCompressLevel);
        bool compressToFile(const char * pszSrcFileName, const char * pszDestFileName, int nCompressLevel);
        bool compressToFile(const char * pszInputBuf, size_t inputlen, const char * pszDestFileName, int nCompressLevel);
        
        size_t decompressToBuffer(const char * pszFileName, char * pszOutBuf, size_t bufLen);
        size_t decompressToBuffer(const char * pszInputBuf, size_t inputLen, char * pszOutBuf, size_t outputLen);
        bool decompressToFile(const char * pszSrcFileName, const char * pszDestFileName);
        bool decompressToFile(const char * pszInputBuf, size_t inputLen, const char * pszDestFileName);
        
        int getLastCompressorErrorCode();
        
    private:
        int m_nCompressorLastErrorCodeNumber;
        unsigned m_nChunkSize;
    };
}

#endif
