//
//  DictionaryDataGather.h
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-8.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#ifndef ApparkTest_DictionaryDataGather_h
#define ApparkTest_DictionaryDataGather_h

#include "json.h"
//#include "JsonReader.h"
//#include "JsonWriter.h"
using namespace std;

namespace ApparkSDK
{
    typedef enum _DicItemType
    {
        dicItemTypeNull = 0,
        dicItemTypeInt,
        dicItemTypeUInt,
        dicItemTypeFloat,
        dicItemTypeString,
        dicItemTypeBoolean,
        dicItemTypeArray,
        dicItemTypeObject
    }DicItemType;

    class CDictionaryDataGather
    {
    public:
        CDictionaryDataGather();
        ~CDictionaryDataGather();
        
    public:
        void    InitWithDescription(const char *pszDescription);
        void    InsertItem(const char *pszKey, int nValue);
        void    InsertItem(const char *pszKey, double fValue);
        void    InsertItem(const char *pszKey, const char * pszValue);
        void    InsertItem(const char *pszKey, CDictionaryDataGather * subDictionary);
        bool    DeleteItem(const char *pszKey);
        void    CleanUp();
        bool    IsKeyValidate(const char *pszKey);
        
        int             GetItemIntValue(const char *pszKey, int nDefaultValue);
        double          GetItemFloatValue(const char *pszKey, double fDefaultValue);
        const char *    GetItemStringValue(const char *pszKey);
        CDictionaryDataGather *   GetSubDictionary(const char *pszKey);
//        CDictionaryDataGather *   GetSubDictionaryFromArray(const char *pszArrayKey, int nIndex);

        string          GetDescription();

        bool    InsertItemToArray(const char *pszArrayKey, int nValue);
        bool    InsertItemToArray(const char *pszArrayKey, double fValue);
        bool    InsertItemToArray(const char *pszArrayKey, const char * pszValue);
        bool    InsertItemToArray(const char *pszArrayKey, CDictionaryDataGather * subDictionary);

        int GetIntValueFromArray(const char *pszArrayKey, int nIndex, int nDefaultValue);
        double GetFloatValueFromArray(const char *pszArrayKey, int nIndex, double fDefaultValue);
        const char * GetStringValueFromArray(const char *pszArrayKey, int nIndex);
        CDictionaryDataGather *GetSubItemFromArray(const char *pszArrayKey, int nIndex);
        DicItemType GetItemTypeFromArray(const char *pszArrayKey, int nIndex);

        int         GetItemCount();
        DicItemType GetItemType(int nIndex);
        DicItemType GetItemType(const char *pszKey);
        vector<string> GetAllMemberNames();

    protected:
        Json::Value m_cValue;

    private:
        void InitWithValue(Json::Value& value);
        inline bool IsKeyValidate(const char *pszKey, Json::Value& root);
        inline Json::Value * ValidateArrayItem(const char *pszArrayKey, int nIndex);
//        CJsonWriter m_cJsonWriter;
//        CJsonReader m_cJsonReader;
    };

}
#endif
