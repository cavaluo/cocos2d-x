//
//  GameDataManager.cpp
//  ApparkTest
//
//  Created by lvyile on 2/9/12.
//  Copyright (c) 2012 CocoaChina.com. All rights reserved.
//

#include <iostream>
#include <string.h>
#include "GameDataManager.h"
#include "ApparkSDK.h"

using namespace ApparkSDK;

CGameDataManager::CGameDataManager():
m_pHttpOperator( NULL )
{
    m_pHttpOperator = new CHttpRequest();
}

CGameDataManager::~CGameDataManager()
{
    CHttpRequest * pTemp = m_pHttpOperator;
    m_pHttpOperator = NULL;
    if (pTemp)
        delete pTemp;
}

bool CGameDataManager::Init() 
{
    return m_pHttpOperator != NULL;
}

bool CGameDataManager::GameDataRequest(const char * ServerURL, bool isSubmit, const char * submitData)
{
    m_pHttpOperator->SetRequestURL(ServerURL);
    
    if (isSubmit) {
        m_pHttpOperator->SetMessageToServer(submitData);
        m_pHttpOperator->m_iOperationMethod = iOperationMethodPost;
    } else {
        m_pHttpOperator->m_iOperationMethod = iOperationMethodGet;        
    }
    
    bool ret = m_pHttpOperator->StartRequest(cCommunicationTypeSync, NULL);    
     
    //modify by fanshaoqiang 6.2 19:53
    if (m_pHttpOperator->m_iOperationResult != 200) {
        ret = false;
    }
    return ret;
}

void CGameDataManager::LocalBufferWriter(const char * input /* IN */, char ** outBuffer /* OUT */) {
    char * retbuf = (char*)malloc(strlen(input) + 4);
    memset(retbuf, 0, strlen(input) + 4);
    strcpy(retbuf, input);        
    *outBuffer = retbuf;    
}

bool CGameDataManager::LocalFileWriter(const char * LocalFullPath, const char * fileData)
{
    FILE * pFile;
    pFile = fopen (LocalFullPath,"wb");
    
    if (pFile!=NULL)
    {
        //printf("[%s]", fileData);
        int ret = fwrite(fileData, 1, strlen(fileData), pFile);
        fclose(pFile);                    
        if (0 < ret) {
            return true;
        } else {
            return false;        
        }
        
    }
    
    return false;
}

bool CGameDataManager::LocalFileReader(const char * LocalFullPath, unsigned char ** fileData)
{
    FILE * pFile;
    pFile = fopen (LocalFullPath,"rb");
    
    if (pFile!=NULL)
    {
        long curpos, length;
        curpos = ftell(pFile);                
        fseek(pFile, 0L, SEEK_END);
        length = ftell(pFile);
        fseek(pFile, curpos, SEEK_SET);        

        unsigned char *message = (unsigned char *)malloc(length+1); 
        if (message == NULL) {
            fclose(pFile);
            return false;
        }
        fseek(pFile, 0L, SEEK_SET);
        fread(message, length, 1, pFile);
        message[length] = 0;
//        printf("CGameDataManager::LocalFileReader message is [%s]\r\n", message);
        *fileData = message;
        fclose(pFile);
        
        return true;
    }
    
    return false;
}

bool CGameDataManager::HandleDataEncryption(unsigned char * input, unsigned char ** output, EncryptOperationType EncryptOperation, const_uint_ptr UserDefineKey)
{
    bool ret = false;

    switch (EncryptOperation) {
        case EncryptOperationTypeEncryption:
        {
            ret = CGameDataManager::Encrypt(input, output, UserDefineKey);
            return ret;
        }
            break;
        case EncryptOperationTypeDecryption:
        {
            ret = CGameDataManager::Decrypt(input, output, UserDefineKey);
            return ret;
        }
            break;
        case EncryptOperationTypeNone:
        {
        }
            break;
        default:
            break;
    }

    return ret;
}

bool CGameDataManager::SubmitGameData(const char * ServerURL, char * LocalFullPath, EncryptOperationType EncryptOperation, const_uint_ptr UserDefineKey) 
{
    bool ret = false;
    unsigned char * readyToSubmitData = NULL;
    unsigned char * tmpData = NULL;
    
    ret = LocalFileReader(LocalFullPath, &tmpData);
    if (ret)
    {
        if (tmpData)
        {
            if (EncryptOperationTypeNone != EncryptOperation)
            {
                ret = HandleDataEncryption(tmpData, &readyToSubmitData, EncryptOperation, UserDefineKey);
            }
            else
            {
                readyToSubmitData = tmpData;
                ret = true;
            }
            SafeFreePtr(tmpData);
#ifdef DEBUG
            printf("将要Submit的数据[%s]\r\n", readyToSubmitData);
#endif
        }
        if (ret)
        {
            ret = GameDataRequest(ServerURL, true, (const char *)readyToSubmitData);    
//            printf("请求返回的数据[%d][%s]\r\n", ret , m_pHttpOperator->m_cReceivedData.c_str());

            if (EncryptOperationTypeNone != EncryptOperation)
            {
                SafeFreePtr(readyToSubmitData);            
            }
        }
    }

    return ret;
}


bool CGameDataManager::DownloadGameData(const char * ServerURL, char * LocalFullPath, EncryptOperationType EncryptOperation, const_uint_ptr UserDefineKey)
{
    bool ret = false;    
    unsigned char * readyWriteToFileData = NULL;    
//    printf("开始请求:\r\n");
    ret = GameDataRequest(ServerURL, false, NULL);
//    printf("请求完成:[%ld]\r\n", m_pHttpOperator->m_iOperationResult);
//    printf("下载的数据[%s]\r\n", m_pHttpOperator->m_cReceivedData.c_str());    
    if (ret)
    {
        //modify by fanshaoqiang 2012 06.02 20 :02
        if (m_pHttpOperator->m_cReceivedData.length() > 0 && m_pHttpOperator->m_iOperationResult == 200)
        {
            if (EncryptOperationTypeNone != EncryptOperation) {
//                printf("开始加密:[%d]\r\n", EncryptOperation);                
                ret = HandleDataEncryption((unsigned char *)m_pHttpOperator->m_cReceivedData.c_str(), &readyWriteToFileData, EncryptOperation, UserDefineKey);
//                printf("加密完成:[%d]\r\n", ret);                
//                printf("[%d]处理后的数据[%s]\r\n", EncryptOperation, readyWriteToFileData);        
            }
            else
            {
                readyWriteToFileData = (unsigned char *)m_pHttpOperator->m_cReceivedData.c_str();
                ret = true;
            }
        }
    }
    //*
    if (ret) {
        if (readyWriteToFileData) {
            // 写文件 
            ret = LocalFileWriter(LocalFullPath, (const char *)readyWriteToFileData);
//            printf("写文件成功!\r\n路径[%s]\r\n内容[%s]\r\n", LocalFullPath, (const char *)readyWriteToFileData);                                                        
            if (EncryptOperationTypeNone != EncryptOperation) {

                SafeFreePtr(readyWriteToFileData);      
            }
        }
    }//*/
    
    return ret;
}

bool CGameDataManager::SubmitDataBuffer(const char * ServerURL, char * DataBuffer, EncryptOperationType EncryptOperation, const_uint_ptr UserDefineKey)
{
    bool ret = false;    
    
    unsigned char * readyToSubmitData;    
    
    if (DataBuffer) {
        
        if (EncryptOperationTypeNone != EncryptOperation) {            
            // 强制类型转换 char * TO unsigned char *
            ret = HandleDataEncryption((unsigned char *)DataBuffer, &readyToSubmitData, EncryptOperation, UserDefineKey);
        } else {
            readyToSubmitData = (unsigned char *)DataBuffer;
            ret = true;
        }
        
    }
    
    if (ret)
    {
//        printf("将要Submit的数据[%s]\r\n", readyToSubmitData);
        if (readyToSubmitData) {
            ret = GameDataRequest(ServerURL, true, (const char *)readyToSubmitData);        
//            printf("请求返回的数据[%d][%s]\r\n", ret , m_pHttpOperator->m_cReceivedData.c_str());
        }

        if (EncryptOperationTypeNone != EncryptOperation) {
            SafeFreePtr(readyToSubmitData);
        }
    }
    
    return ret;

 
    return false;
}

bool CGameDataManager::DownloadToBuffer(const char * ServerURL, char ** buffer, EncryptOperationType EncryptOperation, const_uint_ptr UserDefineKey)
{
#ifdef DEBUG
    printf("\n%s\n", ServerURL);
#endif
    bool ret = false;    
    unsigned char * readyWriteToBufferData = NULL;
    
    ret = GameDataRequest(ServerURL, false, NULL);        
    if (ret) {
        if (m_pHttpOperator->m_cReceivedData.length() > 0) {
            
            if (EncryptOperationTypeNone != EncryptOperation) {
                
                ret = HandleDataEncryption((unsigned char *)m_pHttpOperator->m_cReceivedData.c_str(), &readyWriteToBufferData, EncryptOperation, UserDefineKey);
            } else {
                
                readyWriteToBufferData = (unsigned char *)m_pHttpOperator->m_cReceivedData.c_str();                
                ret = m_pHttpOperator->m_iOperationResult == HttpStatusCodeOK;
            }
        }
    }
    
    if (ret) {
        if (readyWriteToBufferData) {
            // 写Buffer
            LocalBufferWriter((const char *)readyWriteToBufferData, buffer);
            
            if (EncryptOperationTypeNone != EncryptOperation) {
                SafeFreePtr(readyWriteToBufferData);
            }
        }
    }
    
    return ret;
}

bool CGameDataManager::Encrypt(const unsigned char * input, unsigned char ** output, const_uint_ptr UserDefineKey)
{
    bool encryptResult = false;
//    printf("CGameDataManager::Encrypt开始分配size1\r\n");
    size_t size1 = CEncryptionManager::XXTEAEncode(input, NULL, strlen((const char*)input), UserDefineKey);    
    unsigned char * tmpOut1 = (unsigned char *)malloc(size1);    // 中间变量1
    if(!tmpOut1)
    {
//        printf("Allocation tmpOut1 buffer error!");
        return false;
    }
    memset(tmpOut1, 0, size1);
//    printf("CGameDataManager::Encrypt实际得到size1[%ld]\r\n", size1);
    
    size_t size2 = CEncryptionManager::Base64Encode(tmpOut1, NULL, size1);   // 因为字符串结尾预留空间，所以加4
//    printf("CGameDataManager::Encrypt开始分配2\r\n");        
    unsigned char * tmpOut2 = (unsigned char *)malloc(size2 + 4);    // 中间变量2
    if(!tmpOut2)
    {
//        printf("Allocation tmpOut2 buffer error!");
        SafeFreePtr(tmpOut1);            
        return false;
    }    
    memset(tmpOut2, 0, size2 + 4);         
//    printf("CGameDataManager::Encrypt实际得到size2[%ld]\r\n", size2);    
    
    size_t size3 = CEncryptionManager::XXTEAEncode(input, tmpOut1, size1, UserDefineKey);    
//    printf("TEA加密返回的长度[%ld]\r\n", size3);
    encryptResult = size3;
    if (size3)
    {
//        printf("实际TEA加密后的buff长度[%ld]\r\n", strlen((const char *)tmpOut1));
        encryptResult = CEncryptionManager::Base64Encode(tmpOut1, tmpOut2, size1);
//        printf("Base64加密[%s]\r\n", tmpOut2);        
//        printf("Base64加密后长度[%ld]\r\n", strlen((const char *)tmpOut2));
        if (encryptResult) {
            *output = tmpOut2;
        }
    }
    
    SafeFreePtr(tmpOut1);    
    
    return encryptResult;
}

/*
-(IBAction)Base64DecodePressed:(id)sender
{
    NSString * strTemp = self.inputTextField.text;
    if(!strTemp || [strTemp length] <= 0)
    {
        NSLog(@"Input is empty!");
        return;
    }
    const char * source = [strTemp cStringUsingEncoding:NSUTF8StringEncoding];
    int size = [Wrapper base64Decode:(const unsigned char *)source output:nil] + 4;
    char * dest = malloc(size);
    if(!dest)
    {
        NSLog(@"Allocation output buffer error!");
        return;
    }
    memset(dest, 0, size);
    size = [Wrapper base64Decode:(const unsigned char *)source output:(unsigned char *)dest];
    NSLog(@"Base64 decode output size : %d", size);
    strTemp = [NSString stringWithCString:dest encoding:NSASCIIStringEncoding];
    strTemp = [strTemp stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@" "]];
    self.outputTextField.text = strTemp;
    free(dest);
}
//*/
/*
-(IBAction)XXTEADecode:(id)sender
{
    if (!self.encodeData)
    {
        NSLog(@"No encrypt data avaliable");
        return;
    }
    int dataSize = self.encodeData.length;
    char *dest = malloc(dataSize + 4);
    if(!dest)
    {
        NSLog(@"Allocation output buffer error!");
        return;
    }
    memset(dest, 0, dataSize + 4);
    bool isDecryptOK = [Wrapper xxteaDecode:self.encodeData.bytes output:(unsigned char *)dest size:dataSize userKey:nil];
    if (!isDecryptOK)
    {
        NSLog(@"Encrypt data size is bad! Not 8 bytes aligned.");
        return;
    }
    NSLog(@"Decrypt data : %s", dest);
    free(dest);
}
//*/
bool CGameDataManager::Decrypt(const unsigned char * input, unsigned char ** output, const_uint_ptr UserDefineKey)
{
    bool decryptReslut = false;
//    printf("CGameDataManager::Decrypt开始分配size1\r\n");    
    size_t size1 = CEncryptionManager::Base64Decode(input, NULL);   // 因为字符串结尾预留空间，所以加4
    unsigned char * tmpOut1 = (unsigned char *)malloc(size1 + 4);    // 中间变量1
    if(!tmpOut1)
    {
//        printf("Allocation tmpOut1 buffer error!");
        return false;
    }
    memset(tmpOut1, 0, size1 + 4);    
//    printf("CGameDataManager::Decrypt实际得到size1[%ld]\r\n", size1);    
    
    unsigned char * tmpOut2 = (unsigned char *)malloc(size1 + 4);    // 中间变量2
    if(!tmpOut2)
    {
//        printf("Allocation tmpOut2 buffer error!");
        SafeFreePtr(tmpOut1);            
        return false;
    }    
    memset(tmpOut2, 0, size1 + 4);         

//    printf("CGameDataManager::Decrypt开始DecodeBase64\r\n");        
    size_t size2 = CEncryptionManager::Base64Decode(input, tmpOut1);
    decryptReslut = size2;        
//    printf("Base64解密后长度[%ld]\r\n", size2);
//    printf("Base64解密后实际得到buff1长度[%ld]\r\n", strlen((const char *)tmpOut1));    
    if (decryptReslut)
    {
//        printf("CGameDataManager::Decrypt开始DecodeTEA\r\n");
        decryptReslut = CEncryptionManager::XXTEADecode(tmpOut1, tmpOut2, size2, UserDefineKey);
//        printf("CGameDataManager::Decrypt:DecodeTEA完成[%d]\r\n", decryptReslut);
//        printf("DecodeTEA最终串[%s]\r\n", tmpOut2);        
        if (decryptReslut) {
            *output = tmpOut2;
        }
    }
    
    SafeFreePtr(tmpOut1);    
    
    return decryptReslut;
}


