//
//  FileManger_Wrapper.h
//  ApparkTest
//
//  Created by steve fan on 12-2-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#ifndef ApparkTest_FileManger_Wrapper_h
#define ApparkTest_FileManger_Wrapper_h
#include <iostream>
#include "DictionaryDataGather.h"

namespace ApparkSDK
{
    class CFileManager
    {
    public:
        CFileManager();

    public:
        std::string m_sDefaultDir;      //用户指定的默认文件夹 
        std::string m_sLatestFileName;  //时间最近的文件名字 
        CDictionaryDataGather m_cGameFileDictionary;    //默认文件夹下所有Log*.apl文件的名字集合 
        CDictionaryDataGather m_cAGDFileDictionary;     //默认文件夹下所有AGD_Log*.apl文件的名字集合 
        CDictionaryDataGather m_cMassFileDictionary;
        CDictionaryDataGather m_cCrashLogDictionary;

    public:
        int filesExistAtDocumet(char *dir);         //获取在默认文件夹下文件的个数，并查找出时间最近的文件名字 
        int crashLogFileList(char * pszCrashLogDir);
        bool createNewFile(const char * fileName);  //创建一个新的文件 
        std::string fullPathForFile(const char * fileName); //获取文件的绝对路径 
        std::string fullPathForDir();               //获取文件夹的绝对路径 
        const char * isSubDictionaryExist(char * root, char * subdir);  // 检查根路径下是否存在指定的子目录 
        int findSpecialFilesInFolder(const char * fullPath, const char * prefix, const char * suffix, CDictionaryDataGather& dict);

    private:
        
    };
}

#endif
