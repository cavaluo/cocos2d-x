//
//  PBAppark.h
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-14.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "ApparkSDK.h" 


@interface PBAppark : NSObject
{
    CApparkSDK *    _apparkSDK;
}

@property (readonly) CApparkSDK * apparkSDK;


+(id)sharedSDK;

-(bool)setupApparkSDK:(NSString *)appID appVersion:(NSString *)appVersion deviceToken:(NSString *)deviceToken logPath:(NSString *)logPath;
-(void)setSessionGap:(double)gapDuration;
-(bool)setDeviceToken:(NSString *)tokenID;

-(void)releaseSDK;

@end
