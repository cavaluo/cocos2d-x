//
//  PBAppark.m
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-14.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#import "PBAppark.h"
#include "PBNetReachability.h"
#include "CommonDef.h"
#import <UIKit/UIKit.h>

#define SESSION_DATE_STYPE  @"yyyy-MM-dd HH:mm:ss"

#ifdef DEBUG
#define APPARK_SERVER_HOST  @"110.173.2.141"
#else
#define APPARK_SERVER_HOST  @"stat.punchbox.org"
#endif

void UncaughtExceptionHandler(NSException *exception);

@interface PBAppark()
{
    PBNetReachability * _netStatusMonitor;
    NSString * _crashLogPath;
    time_t  _applicationStartTime;
    NSDate * _sessionStartTime;
    NSDate * _sessionEndTime;
    bool _isSessionPause;
    NSTimeInterval _newSessionGap;
    time_t _lastCrashLogTime;
}

@property (nonatomic, retain) PBNetReachability * netStatusMonitor;
@property (nonatomic, retain) NSString * crashLogPath;
@property (nonatomic, retain) NSDate * sessionStartTime;
@property (nonatomic, retain) NSDate * sessionEndTime;
@property (nonatomic, assign) bool isSessionPause;

- (void)netStatusChanged:(PBNetReachability *)netObject;

- (void)gatherCrashLogInfo:(int)logCount;
+ (void)setDefaultHandler;
+ (NSUncaughtExceptionHandler*)getHandler;

- (void)checkTempSessionLog;
- (void)saveTempSessionInfo;
- (void)updateTempSessionTokenID;

@end

bool ReadFile(char * pszFileName, char ** pData);


@implementation PBAppark

@synthesize apparkSDK = _apparkSDK;
@synthesize netStatusMonitor = _netStatusMonitor;
@synthesize crashLogPath = _crashLogPath;
@synthesize sessionStartTime = _sessionStartTime;
@synthesize sessionEndTime = _sessionEndTime;
@synthesize isSessionPause = _isSessionPause;


static string strLogPath;
static PBAppark * _sharedAppark = nil;


bool ReadFile(char * pszFileName, char ** pData)
{
    if (!pszFileName || !(*pszFileName) || !pData)
        return false;

    bool bRet = false;
    FILE * f = fopen(pszFileName, "rb");
    if (f)
    {
        fseek(f, 0, SEEK_END);
        int nSize = ftell(f);
        rewind(f);
        if (nSize)
        {
            char * pszBuffer = (char *)malloc(nSize + 4);
            if (pszBuffer)
            {
                ZeroMemory(pszBuffer, nSize + 4);
                fread(pszBuffer, 1, nSize, f);
                *pData = pszBuffer;
                bRet = true;
            }
        }
        fclose(f);
    }

    return bRet;
}

#pragma mark - Life cycle
+(id)sharedSDK
{
    @synchronized(self)
    {
        if(!_sharedAppark)
        {
            _sharedAppark = [[super allocWithZone:nil] init];
        }

        return _sharedAppark;
    }
}

+ (id)allocWithZone:(NSZone *)zone
{
    return [[self sharedSDK] retain];
}

- (id)copyWithZone:(NSZone *)zone
{
    return self;
}

- (id)retain
{
    return self;
}

- (NSUInteger)retainCount
{
    return NSUIntegerMax;  //denotes an object that cannot be released
}

- (oneway void)release
{
    //do nothing
}

- (id)autorelease
{
    return self;
}


-(id)init
{
    self = [super init];
    if (self)
    {
        _apparkSDK = NULL;
        self.netStatusMonitor = [PBNetReachability reachabilityWithHostName:APPARK_SERVER_HOST];
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(netStatusChanged:) 
                                                     name:kReachabilityChangedNotification 
                                                   object:nil];

        _applicationStartTime = 0;
        self.sessionStartTime = nil;
        self.sessionEndTime = nil;
        self.isSessionPause = nil;
        _newSessionGap = 60.0;
        _lastCrashLogTime = 0;
    }

    return self;
}


-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    self.netStatusMonitor = nil;
    [super dealloc];
}


#pragma mark - init & finalize ApparkSDK
-(bool)setupApparkSDK:(NSString *)appID 
           appVersion:(NSString *)appVersion 
          deviceToken:(NSString *)deviceToken 
              logPath:(NSString *)logPath
{
    bool bRet = false;

    SafeDeletePtr(_apparkSDK);
    _apparkSDK = new CApparkSDK();
    if(_apparkSDK)
    {
        if(_apparkSDK->InitAppark([appID cStringUsingEncoding:NSUTF8StringEncoding],
                                  [appVersion cStringUsingEncoding:NSUTF8StringEncoding], 
                                  [deviceToken cStringUsingEncoding:NSUTF8StringEncoding],
                                  (logPath ? [logPath cStringUsingEncoding:NSUTF8StringEncoding] : NULL)))
        {
            bRet = true;
        }
        else
        {
            SafeDeletePtr(_apparkSDK);
        }
    }
    if(!self.netStatusMonitor)
        self.netStatusMonitor = [PBNetReachability reachabilityWithHostName:APPARK_SERVER_HOST];

    [self.netStatusMonitor startNotifier];

    if (PBReachableViaWiFi == [self.netStatusMonitor currentReachabilityStatus])
        _apparkSDK->NetStatusChange(CURRENT_NET_CONNECTION_WIFI);
    else if([self.netStatusMonitor currentReachabilityStatus] == PBReachableViaWWAN)
        _apparkSDK->NetStatusChange(CURRENT_NET_CONNECTION_3G);
    else
        _apparkSDK->NetStatusChange(CURRENT_NET_CONNECTION_NONE);

    [[self class] setDefaultHandler];

    CFileManager * fileManager = self.apparkSDK->m_pFileManger;
    strLogPath = fileManager->isSubDictionaryExist((char *)fileManager->fullPathForDir().c_str(), (char *)CRASHLOG_SUB_PATH);
    if (strLogPath[strLogPath.length() - 1] != '/')
        strLogPath += "/";

    _apparkSDK->m_pSettingManager->UpdateSettingFromServer();
    string strCrashLog = APPPARK_DEFAULTDIR;
    strCrashLog += "/";
    strCrashLog += CRASHLOG_SUB_PATH;
    int nCrashLogCount = _apparkSDK->m_pLogManager->m_fileManager.crashLogFileList((char *)strCrashLog.c_str());
    if (nCrashLogCount > 0)
        [self gatherCrashLogInfo:nCrashLogCount];

    [self checkTempSessionLog];

    [self registerNotifications];
    if (!self.sessionStartTime)
    {
        [self sessionStart];
    }

    _apparkSDK->m_pLogManager->StartLogUploading();
    return bRet;
}


-(void)setSessionGap:(double)gapDuration
{
    _newSessionGap = gapDuration;
    if (_newSessionGap <= 0.0)
        _newSessionGap = 60.0;
}


-(bool)setDeviceToken:(NSString *)tokenID
{
    if([tokenID length] && _apparkSDK)
    {
        if (!_apparkSDK->m_strDeviceToken.empty())
            _apparkSDK->m_strDeviceToken = [tokenID UTF8String];
        [self updateTempSessionTokenID];

        return true;
    }

    return false;
}


-(void)releaseSDK
{
    delete _apparkSDK;
    _apparkSDK = NULL;
}


#pragma mark - status check & log
- (void)netStatusChanged:(NSNotification *)netObject
{
    PBNetReachability * netReach = (PBNetReachability *)netObject.object;
        if([netReach currentReachabilityStatus] == PBReachableViaWiFi)
            _apparkSDK->NetStatusChange(CURRENT_NET_CONNECTION_WIFI);
        else if([netReach currentReachabilityStatus] == PBReachableViaWWAN)
            _apparkSDK->NetStatusChange(CURRENT_NET_CONNECTION_3G);
        else
            _apparkSDK->NetStatusChange(CURRENT_NET_CONNECTION_NONE);
#ifdef DEBUG
    NSLog(@"\n\n\n Current Network Status : %s\n\n\n", _apparkSDK->m_cDeviceInfo.m_sNetWork_type.c_str());
#endif
}


- (void)applicationStart
{
    _applicationStartTime = time(NULL);
    [self saveTempSessionInfo];
}


- (void)sessionStart
{
    if (self.isSessionPause)
    {
        NSDate * nowDate = [NSDate date];
        NSTimeInterval pauseDuration = [nowDate timeIntervalSinceDate:self.sessionEndTime];
        if (pauseDuration >= _newSessionGap)
        {
            [self sessionFinished:[NSString stringWithCString:AGDLOG_SESSION_ENDTYPE_SWITCH encoding:NSUTF8StringEncoding]];
        }
        else
        {
            self.isSessionPause = false;
            return;
        }
    }

    self.sessionStartTime = [NSDate date];
    self.sessionEndTime = nil;
    self.isSessionPause = false;
    [self saveTempSessionInfo];
}


- (void)sessionPause
{
    self.isSessionPause = true;
    self.sessionEndTime = [NSDate date];
    [self saveTempSessionInfo];

    _apparkSDK->FlushLogs();
}


- (void)sessionFinished:(NSString *)reason
{
    NSLog(@"%@", @"Session Finished Evernt");
    int sessionDuration = [self.sessionEndTime timeIntervalSinceDate:self.sessionStartTime];
    if (sessionDuration > 0)
    {
        CDictionaryDataGather root, sessionParam;
        NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:SESSION_DATE_STYPE];
        NSString * dateString = [dateFormatter stringFromDate:self.sessionStartTime];
        sessionParam.InsertItem(AGDLOG_SESSION_STARTKEY, [dateString UTF8String]);
        sessionParam.InsertItem(AGDLOG_SESSION_DURATIONKEY, sessionDuration);
        sessionParam.InsertItem(AGDLOG_APPSTART_KEY, (int)_applicationStartTime);
        sessionParam.InsertItem(AGDLOG_SESSION_ENDTYPE_KEY, [reason UTF8String]);
        [dateFormatter release];

        root.InsertItem(AGDLOG_SESSION_KEY, &sessionParam);
        string strSessionInfo = root.GetDescription();
        _apparkSDK->m_pLogManager->SaveLog((char *)strSessionInfo.c_str(), eUserLogTypeAGD);
    }

    NSString * strSessionLog = [NSString stringWithFormat:@"%s%s", strLogPath.c_str(), SESSION_TEMPLOG];
    remove([strSessionLog UTF8String]);
}


- (void)sessionTerminate
{
    [self sessionFinished:[NSString stringWithCString:AGDLOG_SESSION_ENDTYPE_SHUT encoding:NSUTF8StringEncoding]];
    _apparkSDK->FlushLogs();
}


- (void)saveTempSessionInfo
{
    CDictionaryDataGather cSessionDict;
    cSessionDict.InsertItem(AGDLOG_SESSION_STARTKEY, 
                            [self.sessionStartTime timeIntervalSince1970]);
    cSessionDict.InsertItem(AGDLOG_SESSION_DURATIONKEY, 
                            [self.sessionEndTime timeIntervalSinceDate:self.sessionStartTime]);
    cSessionDict.InsertItem(AGDLOG_APPSTART_KEY, (int)_applicationStartTime);
    if (!_apparkSDK->m_strDeviceToken.empty())
        cSessionDict.InsertItem(AGDLOG_TOKENID_KEY, _apparkSDK->m_strDeviceToken.c_str());
    string strSessionInfo = cSessionDict.GetDescription();

    NSString * strSessionLog = [NSString stringWithFormat:@"%s%s", 
                                strLogPath.c_str(), SESSION_TEMPLOG];
    NSData * saveData = [NSData dataWithBytes:strSessionInfo.c_str() 
                                       length:strSessionInfo.length()];
    [saveData writeToFile:strSessionLog atomically:YES];
}


- (void)checkTempSessionLog
{
    NSData * sessionData;
    NSString * strSessionLog = [NSString stringWithFormat:@"%s%s", strLogPath.c_str(), SESSION_TEMPLOG];
    sessionData = [NSData dataWithContentsOfFile:strSessionLog];
    if (sessionData.length > 0)
    {
        char * pszTemp = (char *)malloc(sessionData.length + 4);
        ZeroMemory(pszTemp, sessionData.length + 4);
        memcpy(pszTemp, (char *)sessionData.bytes, sessionData.length);
        CDictionaryDataGather cSessionInfo, cTempBuf;
        cTempBuf.InitWithDescription((const char *)pszTemp);

        long lStartTime = cTempBuf.GetItemIntValue(AGDLOG_SESSION_STARTKEY, 0);
        long lEndTime = cTempBuf.GetItemIntValue(AGDLOG_SESSION_DURATIONKEY, 0);
        if (lStartTime > 0)
        {
            NSDate * sessionStartDate = [NSDate dateWithTimeIntervalSince1970:lStartTime];
            NSDate * sessionEndDate = [NSDate dateWithTimeInterval:lEndTime sinceDate:sessionStartDate];
            NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:SESSION_DATE_STYPE];
            NSString * dateString = [dateFormatter stringFromDate:sessionStartDate];
            cTempBuf.InsertItem(AGDLOG_SESSION_STARTKEY, [dateString UTF8String]);
            NSDate * crashTime = nil; //[dateFormatter dateFromString:@"1900-01-01 00:00:00"];
            if (_lastCrashLogTime > 0)
                crashTime = [NSDate dateWithTimeIntervalSince1970:_lastCrashLogTime];

            [dateFormatter release];

            if (crashTime > sessionEndDate)
            {
                cTempBuf.InsertItem(AGDLOG_SESSION_ENDTYPE_KEY, AGDLOG_SESSION_ENDTYPE_CRASH);
                cTempBuf.InsertItem(AGDLOG_SESSION_DURATIONKEY, [crashTime timeIntervalSinceDate:sessionStartDate]);
            }
            else
                cTempBuf.InsertItem(AGDLOG_SESSION_ENDTYPE_KEY, AGDLOG_SESSION_ENDTYPE_SWITCH);

            cSessionInfo.InsertItem(AGDLOG_SESSION_KEY, &cTempBuf);
            _apparkSDK->m_pLogManager->SaveLog((char *)cSessionInfo.GetDescription().c_str(), eUserLogTypeAGD);
        }
        SafeFreePtr(pszTemp);
    }

    remove([strSessionLog UTF8String]);
}

- (void)updateTempSessionTokenID
{
    NSData * sessionData;
    NSString * strSessionLog = [NSString stringWithFormat:@"%s%s", strLogPath.c_str(), SESSION_TEMPLOG];
    sessionData = [NSData dataWithContentsOfFile:strSessionLog];
    if (sessionData.length > 0)
    {
        char * pszTemp = (char *)malloc(sessionData.length + 4);
        ZeroMemory(pszTemp, sessionData.length + 4);
        memcpy(pszTemp, (char *)sessionData.bytes, sessionData.length);
        CDictionaryDataGather cTempBuf;
        cTempBuf.InitWithDescription((const char *)pszTemp);

        if (cTempBuf.GetItemStringValue(AGDLOG_SESSION_STARTKEY))
        {
            cTempBuf.InsertItem(AGDLOG_TOKENID_KEY, _apparkSDK->m_strDeviceToken.c_str());
            NSData * saveData = [NSData dataWithBytes:cTempBuf.GetDescription().c_str() 
                                               length:cTempBuf.GetDescription().length()];
            [saveData writeToFile:strSessionLog atomically:YES];
        }
        SafeFreePtr(pszTemp);
    }
}


- (void)registerNotifications
{
    if ([[UIDevice currentDevice].systemVersion floatValue] > 4.0)
    {
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(sessionStart) 
                                                     name:UIApplicationWillEnterForegroundNotification 
                                                   object:nil];

        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(sessionPause) 
                                                     name:UIApplicationDidEnterBackgroundNotification
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(applicationStart) 
                                                     name:UIApplicationDidFinishLaunchingNotification 
                                                   object:nil];
    }
    else
    {
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(sessionStart) 
                                                     name:UIApplicationDidFinishLaunchingNotification 
                                                   object:nil];
    }

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(sessionTerminate) 
                                                 name:UIApplicationWillTerminateNotification 
                                               object:nil];
}


#pragma mark - crash catcher process functions
- (void)gatherCrashLogInfo:(int)logCount
{
    char szTemp[8] = {0};
    string strCrashLog;
    CDictionaryDataGather root;
    char * pszCrashInfo = NULL;
    for (int i = 0; i < logCount; i++)
    {
        sprintf(szTemp, "%d", i + 1);
        strCrashLog = _apparkSDK->m_pLogManager->m_fileManager.m_cCrashLogDictionary.GetItemStringValue(szTemp);
        if (ReadFile((char *)strCrashLog.c_str(), &pszCrashInfo))
        {
            NSString * strTemp = [NSString stringWithCString:strCrashLog.c_str() encoding:NSUTF8StringEncoding];
            strTemp = [strTemp lastPathComponent];
            strTemp = [strTemp stringByDeletingPathExtension];

            long ltemp = atol([strTemp UTF8String]);
            if (ltemp > _lastCrashLogTime)
                _lastCrashLogTime = ltemp;

            root.InsertItem(AGDLOG_CRASHLOG_KEY, pszCrashInfo);
            string strLogInfo = root.GetDescription();
            _apparkSDK->m_pLogManager->SaveCrashLog((char *)strLogInfo.c_str());
            SafeFreePtr(pszCrashInfo);
        }
        remove(strCrashLog.c_str());
    }
}


void UncaughtExceptionHandler(NSException *exception)
{
    NSArray * arr = [exception callStackSymbols];
    NSString * reason = [exception reason];
    NSString * name = [exception name];
    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString * dateString = [dateFormatter stringFromDate:[NSDate date]];
    [dateFormatter release];

    NSString *log = [NSString stringWithFormat:@"Crash log at : %@\nname : %@\nreason : %@\nCallStack :\n%@", 
                     dateString, name, reason, [arr componentsJoinedByString:@"\n"]];
#ifdef DEBUG
    NSLog(@"\n%@\n\n", log);
    NSLog(@"%s\n", strLogPath.c_str());
#endif

    time_t curTime = time(NULL);
    NSString * strCrashLog = [NSString stringWithFormat:@"%s%ld.%s", strLogPath.c_str(), curTime, CRASHLOG_EXT_NAME];
    NSData * saveData = [log dataUsingEncoding:NSUTF8StringEncoding];
    [saveData writeToFile:strCrashLog atomically:YES];
}


+ (void)setDefaultHandler
{
    NSSetUncaughtExceptionHandler (&UncaughtExceptionHandler);
}


+ (NSUncaughtExceptionHandler*)getHandler
{
    return NSGetUncaughtExceptionHandler();
}


@end
