//
//  Device_Wrapper.m
//  ApparkTest
//
//  Created by lvyile on 2/12/12.
//  Copyright (c) 2012 CocoaChina. All rights reserved.
//

#import "Device_Wrapper.h"
#import <UIKit/UIKit.h>
#include "CommonDef.h"
#include "EncryptionManager.h"

#include <sys/socket.h> // Per msqr
#include <sys/sysctl.h>
#include <net/if.h>
#include <net/if_dl.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <mach-o/dyld.h>
#include <fstream>

using namespace ApparkSDK;

const char * macaddress();

void CDeviceInfo::GetDeviceInfo()
{
    UIDevice *device = [UIDevice currentDevice];

    //获取UDID （iOS5.0已经过期）
    NSString* udid = [[UIDevice currentDevice] uniqueIdentifier]; __OSX_AVAILABLE_BUT_DEPRECATED(__MAC_NA,__MAC_NA,__IPHONE_2_0,__IPHONE_5_0);  // a string unique to each device based on various hardware info.
    m_sDeviceId = [udid UTF8String];

    // 获取Mac 地址
    m_sMacAdress = macaddress();

//    std::string m_sSerialNum;       // 2 序列号

    NSString *model = [device model];
    m_sDeviceType = [model UTF8String];      // 3 Platform String 例如 iPhone 4

	NSString *systemVersion = [device systemVersion];
    m_sOsversion = [systemVersion UTF8String];       // 4 iOS 版本

    NSLocale *locale = [NSLocale currentLocale];
	NSString *language;
	if ([[NSLocale preferredLanguages] count] > 0)
	{
		language = [[NSLocale preferredLanguages] objectAtIndex:0];
	}
	else
	{
		language = [locale objectForKey:NSLocaleLanguageCode];
	}
    m_sLanguage = [language UTF8String];        // 5 iOS 当前设置语言
    // 获取当前设置语言的详细描述
//    NSString *lang = [[NSLocale currentLocale] displayNameForKey:NSLocaleLanguageCode value:language];

    m_sArea = [[locale objectForKey:NSLocaleCountryCode] UTF8String];   // 6 iOS 当前设置 Region Format

    m_sJailbreak = isJailBroken()?"YES":"NO";       // 8 是否越狱 YES / NO

    CGSize screenSize = CGSizeZero;
    if([UIScreen instancesRespondToSelector:@selector(currentMode)])
        screenSize = [[UIScreen mainScreen] currentMode].size;
    m_sScreenSize = [NSStringFromCGSize(screenSize) UTF8String];

    if (m_sNetWork_type.empty())
        m_sNetWork_type = CURRENT_NET_CONNECTION_NONE;
}

#pragma mark MAC addy
// Return the local MAC addy
// Courtesy of FreeBSD hackers email list
// Accidentally munged during previous update. Fixed thanks to mlamb.
const char * macaddress()
{
    int                 mib[6];
    size_t              len;
    char                *buf;
    unsigned char       *ptr;
    struct if_msghdr    *ifm;
    struct sockaddr_dl  *sdl;
    
    mib[0] = CTL_NET;
    mib[1] = AF_ROUTE;
    mib[2] = 0;
    mib[3] = AF_LINK;
    mib[4] = NET_RT_IFLIST;
    
    if ((mib[5] = if_nametoindex("en0")) == 0) {
        printf("Error: if_nametoindex error\n");
        return NULL;
    }
    
    if (sysctl(mib, 6, NULL, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 1\n");
        return NULL;
    }
    
    if ((buf = (char *)malloc(len)) == NULL) {
        printf("Could not allocate memory. error!\n");
        return NULL;
    }
    
    if (sysctl(mib, 6, buf, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 2");
        return NULL;
    }
    
    ifm = (struct if_msghdr *)buf;
    sdl = (struct sockaddr_dl *)(ifm + 1);
    ptr = (unsigned char *)LLADDR(sdl);
    NSString *outstring = [NSString stringWithFormat:@"%02X:%02X:%02X:%02X:%02X:%02X", 
                           *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    // NSString *outstring = [NSString stringWithFormat:@"%02X%02X%02X%02X%02X%02X", 
    //                       *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    free(buf);
    
    return [outstring UTF8String];
}

const char iapfree[] = //"/Applications/IAPFree.app";
{0xA0, 0x48, 0x17, 0xD3, 0x27, 0x6B, 0xA6, 0x0D, 0x8E, 0x9C, 0x75, 0x4F, 0x1A, 0xA5, 0x9D, 0xA4, 0x4B, 0x2F, 0x44, 0x25, 0x80, 0x83, 0x93, 0xFB, 0xF7, 0xF9, 0xD2, 0x78, 0x25, 0x8E, 0x56, 0x5B, 0x00};

const char badstorehost[] = //"punchbox.itunes.apple.com" 诱骗伪造itunes store解析的域名
{0xCB, 0xA5, 0x36, 0x0B, 0x7A, 0x31, 0x35, 0x3E, 0x9E, 0x5B, 0xA5, 0xCE, 0xB7, 0x6E, 0x1E, 0x72, 0x88, 0x98, 0x25, 0x8B, 0xA8, 0xB8, 0x30, 0x1E, 0xC1, 0x3A, 0x48, 0xFB, 0xF3, 0xC0, 0xF7, 0x7C};

const char badstoreip[] = //"91.224.160.136"
{0xBE, 0x1E, 0x56, 0x75, 0x8E, 0xF7, 0xFA, 0x75, 0xE7, 0x00, 0x66, 0x67, 0xD8, 0xE8, 0xFB, 0xBA};

bool CDeviceInfo::checkIAPFExist()
{
    bool bRet = false;
    char * szTemp = (char *)malloc(36);
    ZeroMemory(szTemp, 36);
    CEncryptionManager::XXTEADecode((const unsigned char *)iapfree, (unsigned char *)szTemp, 32);
    if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithUTF8String:szTemp]])
    {
        bRet = true;
    }

    ZeroMemory(szTemp, 36);
    CEncryptionManager::XXTEADecode((const unsigned char *)badstorehost, (unsigned char *)szTemp, 32);
    string strHostIP = getHostIPAddress(szTemp);
    if (strHostIP.length() > 0)
    {
        ZeroMemory(szTemp, 36);
        CEncryptionManager::XXTEADecode((const unsigned char *)badstoreip, (unsigned char *)szTemp, 16);
        if (strHostIP.compare(szTemp) == 0)
            bRet = true;
    }

    char szTestHost[] = "stat.punchbox.org";
    strHostIP = getHostIPAddress(szTestHost);
    if (strHostIP.length() > 0 && strHostIP.compare("127.0.0.1") == 0)
    {
        bRet = true;
    }

    free(szTemp);
    return bRet;
}


static const char* jailbreak_apps[] =
{
	"/bin/bash",
	"/Applications/Cydia.app", 
	"/Applications/limera1n.app", 
	"/Applications/greenpois0n.app", 
	"/Applications/blackra1n.app",
	"/Applications/blacksn0w.app",
	"/Applications/redsn0w.app",
	NULL,
};

std::string CDeviceInfo::getUniqueIdentifier()
{
	if ([[UIDevice currentDevice] respondsToSelector:@selector(uniqueIdentifier)])
	{
		return [[[UIDevice currentDevice] uniqueIdentifier] UTF8String];
	}
	
	return nil;
}

bool CDeviceInfo::isJailBroken()
{
#if TARGET_IPHONE_SIMULATOR
	return NO;
#endif
	
	// Check for known jailbreak apps. If we encounter one, the device is jailbroken.
	for (int i = 0; jailbreak_apps[i] != NULL; ++i)
	{
		if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithUTF8String:jailbreak_apps[i]]])
		{
			//NSLog(@"isjailbroken: %s", jailbreak_apps[i]);
			return YES;
		}		
	}
	
	// Check for UDID Faker.
	NSString* fakerPrefPath = @"/var/mobile/Library/Preferences/com.Reilly.UDIDFaker.plist";
	if ([[NSFileManager defaultManager] fileExistsAtPath:fakerPrefPath]) 
	{
		return YES;
	}
	fakerPrefPath = @"/var/mobile/Library/Preferences/com.i4iPhones.UDIDFaker.plist";
	if ([[NSFileManager defaultManager] fileExistsAtPath:fakerPrefPath]) 
	{
		return YES;
	}
	
	// Check for UDID Faker method.
	UIDevice* device = [UIDevice currentDevice];
	if ([device respondsToSelector:@selector(orig_uniqueIdentifier)])
	{
		return YES;
	}
	
	// Check for whether the function pointer of the uniqueIdentifier method is within a certain range.
	uint32_t count = _dyld_image_count();
	void* uikit_loc = 0;
	for (uint32_t i = 0; i < count; ++ i)
	{
		if (!strcmp(_dyld_get_image_name(i), "/System/Library/Frameworks/UIKit.framework/UIKit")) 
		{
			uikit_loc = (void*)_dyld_get_image_header(i);
			break;
		}
	}
	
	// If the unique identifier method doesn't exist anymore, then this check is moot.
	if (!getUniqueIdentifier().c_str())
	{
		return NO;
	}
	
	// Get the memory address of the start of the code block that implements the uniqueIdentifier method.
	IMP funcptr = [UIDevice instanceMethodForSelector:@selector(uniqueIdentifier)];
	// If the address is greater than the address for UIKit, then it's injected code and all bad.
	if ((void*)funcptr < uikit_loc) 
	{
		return YES;
	}
	
	// TODO: Add more checks? This is an arms-race we're bound to lose.
	
	return NO;
}


bool CDeviceInfo::isHostModified(const char * pszHost)
{
    bool bRet = false;
    FILE * f = fopen("/etc/hosts", "rb");
    if (f)
    {
        fseek(f, 0, SEEK_END);
        fwrite("test only\r\n", 1, strlen("test only\r\n"), f);
        fclose(f);
        string strBuf = "";
        ifstream in("/etc/hosts");
        if (in.is_open())
        {
            while(!in.eof() && getline(in, strBuf))
            {
                if(strBuf.empty() || '#' == strBuf[0])
                    continue;
                bRet = isMatchString(strBuf, pszHost);
                if(bRet)
                    break;
            }
            in.close();
        }
    }
    return bRet;
}


inline bool CDeviceInfo::isMatchString(string& strBuf, const char * pszSubStr)
{
    bool bRet = false;
    size_t findPos = string::npos;
    findPos = strBuf.find(pszSubStr);
    if(string::npos != findPos)
    {
        if(0 < findPos)
        {
            if (strBuf[findPos - 1] <= ' ' || strBuf[findPos - 1] > 'z')
            {
                if (findPos + strlen(pszSubStr) >= strBuf.length() - 1)
                {
                    bRet = true;
                }
                else
                {
                    size_t endPos = findPos + strlen(pszSubStr);
                    if (strBuf[endPos] <= ' ' || strBuf[endPos] > 'z')
                    {
                        bRet = true;
                    }
                }
            }
        }
    }

    return bRet;
}


std::string CDeviceInfo::getHostIPAddress(char * host)
{
    string strRet = "";
    const char* szname = host;
    struct hostent* phot ;
    @try
    {
        phot = gethostbyname(szname);
    }
    @catch (NSException * e)
    {
        return strRet;
    }
    
    if (phot == NULL) {
        return strRet;
    }
    
    struct in_addr ip_addr;
    //h_addr_list[0]里4个字节,每个字节8位，此处为一个数组，一个域名对应多个ip地址或者本地时一个机器有多个网卡
    memcpy(&ip_addr,phot->h_addr_list[0],4);
    
    char ip[20] = {0};
    inet_ntop(AF_INET, &ip_addr, ip, sizeof(ip));

    strRet.assign(ip);
    return strRet;
}


