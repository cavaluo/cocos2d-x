//
//  AppDelegate.m
//  ApparkTest
//
//  Created by steve fan on 12-2-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#include "FileManger_Wrapper.h"
#include "CommonDef.h"

using namespace ApparkSDK;

CFileManager::CFileManager():
m_sDefaultDir("")
{
     m_sDefaultDir.assign(APPPARK_DEFAULTDIR);
}

const char * CFileManager::isSubDictionaryExist(char * root, char * subdir)
{
    NSFileManager *manager = [NSFileManager defaultManager];
    NSString * fullPath = [NSString stringWithUTF8String:root];

    fullPath = [NSString stringWithFormat:@"%@%s", fullPath, subdir];

    BOOL isDictionary;
    BOOL dirExist = [manager fileExistsAtPath:fullPath isDirectory:&isDictionary];

    if (!dirExist)
    {
        NSError *errorInfo;
        BOOL isDirCreated =  [manager createDirectoryAtPath:fullPath 
                                withIntermediateDirectories:YES 
                                                 attributes:nil 
                                                      error:&errorInfo];
        if (isDirCreated)
        {
            NSLog(@"[%@]", fullPath);
        }
        else
        {
            return NULL;
        }
    }
    return [fullPath UTF8String];
}


bool CFileManager::createNewFile(const char * fileName)
{
    NSFileManager *manager = [NSFileManager defaultManager];

    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cachesDirectory = [paths objectAtIndex:0];  
#ifdef DEBUG
    printf("m_sDefaultDir in wrapperis %s\r\n", m_sDefaultDir.c_str());
#endif
    NSString *dir = [NSString stringWithCString:m_sDefaultDir.c_str() encoding:NSUTF8StringEncoding];    
    NSString *dirpath = [cachesDirectory stringByAppendingPathComponent:dir];    
#ifdef DEBUG
    NSLog(@" dirpath is [%@], dir is  [%@]", dirpath, dir);
#endif
    BOOL isDictionary;
    BOOL dirExist = [manager fileExistsAtPath:dirpath isDirectory:&isDictionary];
    if (!dirExist)
    {
        NSError *errorInfo;
        BOOL isDirCreated =  [manager createDirectoryAtPath:dirpath 
                                withIntermediateDirectories:YES 
                                                 attributes:nil 
                                                      error:&errorInfo];
        if (isDirCreated)
        {
            NSLog(@"[%@]", dirpath);
        }
        else
        {
            return false;
        }
    }

    NSString *nsFileName = [NSString stringWithCString:fileName encoding:NSUTF8StringEncoding];
    BOOL ret = [manager createFileAtPath:[dirpath stringByAppendingPathComponent:nsFileName] 
                                contents:nil attributes:nil];
    return  ret;
}


int CFileManager::filesExistAtDocumet(char *dir)
{
    NSFileManager *manager = [NSFileManager defaultManager];

    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cachesDirectory = [paths objectAtIndex:0];
    NSString *dirs = [NSString stringWithCString:m_sDefaultDir.c_str() encoding:NSUTF8StringEncoding];    
    NSString *dirpath = [cachesDirectory stringByAppendingPathComponent:dirs];    
    NSDirectoryEnumerator *direnum = [manager enumeratorAtPath:dirpath];

    int count = [paths count];
    NSMutableArray *files = [NSMutableArray arrayWithCapacity:count];
    NSString *filename;
    NSString *strSuffix = [NSString stringWithCString:APPPARK_File_Suffix 
                                             encoding:NSUTF8StringEncoding];
    NSString *strPrefix = [NSString stringWithCString:APPPARK_AGD_File_Prefix 
                                             encoding:NSUTF8StringEncoding];
    NSString *strMassPrefix = [NSString stringWithCString:APPPARK_MASS_File_Prefix 
                                                 encoding:NSUTF8StringEncoding];
    int i = 1;
    int j = 1;
    int k = 1;
    while (filename = [direnum nextObject])
    {
        NSString *pathExtention = [filename pathExtension];
        NSString *strWithOutExtention = [filename stringByDeletingPathExtension];
        NSRange range = [strWithOutExtention rangeOfString:strPrefix];
        if ([pathExtention isEqualToString:strSuffix])
        {
            [files addObject: filename];
            char bufTemp[5];

            if (range.location == NSNotFound)
            {
                range = [strWithOutExtention rangeOfString:strMassPrefix];
                if (range.location == NSNotFound)
                {
                    sprintf(bufTemp, "%d",i);
//                    std::string strKey = bufTemp;
                    m_cGameFileDictionary.InsertItem(bufTemp, [filename cStringUsingEncoding:NSUTF8StringEncoding]);
                    i++;
                }
                else
                {
                    sprintf(bufTemp, "%d", k);
//                    std::string strKey = bufTemp;
                    m_cMassFileDictionary.InsertItem(bufTemp, [filename cStringUsingEncoding:NSUTF8StringEncoding]);
                    k++;
                }
            }
            else
            {
                sprintf(bufTemp, "%d",j);
//                std::string strKey = bufTemp;
                m_cAGDFileDictionary.InsertItem(bufTemp, [filename cStringUsingEncoding:NSUTF8StringEncoding]);
                j++;
            }
        }
    }
    return [files count];
}


int CFileManager::crashLogFileList(char * pszCrashLogDir)
{
    NSFileManager *manager = [NSFileManager defaultManager];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cachesDirectory = [paths objectAtIndex:0];
    NSString *dirs = [NSString stringWithCString:pszCrashLogDir encoding:NSUTF8StringEncoding];    
    NSString *dirpath = [cachesDirectory stringByAppendingPathComponent:dirs];    
    NSDirectoryEnumerator *direnum = [manager enumeratorAtPath:dirpath];

    int i = 1;
    NSString *filename;
    while (filename = [direnum nextObject])
    {
        NSString * pathExtention = [filename pathExtension];
        NSString * strCrashLogExt = [NSString stringWithCString:CRASHLOG_EXT_NAME 
                                                       encoding:NSUTF8StringEncoding];
        if ([pathExtention isEqualToString:strCrashLogExt])
        {
            char bufTemp[5];
            sprintf(bufTemp, "%d",i);
            std::string strKey = bufTemp;
            NSString * strFullPathLog = [dirpath stringByAppendingPathComponent:filename];
            m_cCrashLogDictionary.InsertItem(bufTemp, [strFullPathLog cStringUsingEncoding:NSUTF8StringEncoding]);
            i++;
        }
    }

    return m_cCrashLogDictionary.GetItemCount();
}


std::string CFileManager::fullPathForFile(const char * fileName)
{
    NSString *tempFileName = [NSString stringWithCString:fileName encoding:NSUTF8StringEncoding];
    NSString *fileExtension = [tempFileName pathExtension];
    NSString *fileNameNoExtension = [tempFileName stringByDeletingPathExtension];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cachesDirectory = [paths objectAtIndex:0];    
        NSString *dirs = [NSString stringWithCString:m_sDefaultDir.c_str() encoding:NSUTF8StringEncoding]; 
    NSString *filePath = [cachesDirectory stringByAppendingFormat:@"/%@/%@.%@" ,dirs,fileNameNoExtension, fileExtension];

    std::string fullPath;
    fullPath.assign([filePath cStringUsingEncoding:NSUTF8StringEncoding]);
    return  fullPath;
}


std::string CFileManager::fullPathForDir()
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cachesDirectory = [paths objectAtIndex:0];    
    NSString *dirs = [NSString stringWithCString:m_sDefaultDir.c_str() encoding:NSUTF8StringEncoding]; 
    NSString *filePath = [cachesDirectory stringByAppendingFormat:@"/%@/" ,dirs];

    std::string fullPath;
    fullPath.assign([filePath cStringUsingEncoding:NSUTF8StringEncoding]);
    return  fullPath;
}


int CFileManager::findSpecialFilesInFolder(const char * fullPath, const char * prefix, const char * suffix, CDictionaryDataGather& dict)
{
    dict.CleanUp();

    return dict.GetItemCount();
}

