//
//  PBNetReachability.h
//

#import <Foundation/Foundation.h>
#import <SystemConfiguration/SystemConfiguration.h>


typedef enum 
{
	PBNotReachable = 0,
	PBReachableViaWiFi,
	PBReachableViaWWAN,
} PBNetworkStatus;
#define kReachabilityChangedNotification @"kNetworkReachabilityChangedNotification"

@interface PBNetReachability : NSObject 
{
	BOOL localWiFiRef;
	SCNetworkReachabilityRef reachabilityRef;
}

//reachabilityWithHostName- Use to check the reachability of a particular host name. 
+ (PBNetReachability*) reachabilityWithHostName: (NSString*) hostName;

//reachabilityWithAddress- Use to check the reachability of a particular IP address. 
+ (PBNetReachability*) reachabilityWithAddress: (const struct sockaddr_in*) hostAddress;

//reachabilityForInternetConnection- checks whether the default route is available.  
//  Should be used by applications that do not connect to a particular host
+ (PBNetReachability*) reachabilityForInternetConnection;

//reachabilityForLocalWiFi- checks whether a local wifi connection is available.
+ (PBNetReachability*) reachabilityForLocalWiFi;


/*!	\fn isUsingWifi
 *	\brief Checks whether the current device is using a wifi for its data connection.
 *
 *	\param n/a
 *	\return A boolean indicating whether the current device is using a wifi for its data connection.
 */
+ (BOOL) isUsingWifi;


/*!	\fn isUsingInternet
 *	\brief Checks whether the current device is using a cell tower for its data connection.
 *
 *	\param n/a
 *	\return A boolean indicating whether the current device is using a cell tower for its data connection.
 */
+ (BOOL) isUsingInternet;


//Start listening for reachability notifications on the current run loop
- (BOOL) startNotifier;
- (void) stopNotifier;

- (PBNetworkStatus) currentReachabilityStatus;
//WWAN may be available, but not active until a connection has been established.
//WiFi may require a connection for VPN on Demand.
- (BOOL) connectionRequired;

@end
