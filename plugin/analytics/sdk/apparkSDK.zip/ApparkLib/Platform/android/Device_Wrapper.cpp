//
//  Device_Wrapper.cpp
//  win32
//
//  Created by zhanghh on 2012-06-11.
//

#include "Device_Wrapper.h"

using namespace ApparkSDK;

void CDeviceInfo::GetDeviceInfo()
{

}
