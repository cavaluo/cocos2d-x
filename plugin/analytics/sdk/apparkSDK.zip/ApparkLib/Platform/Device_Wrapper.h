//
//  Device_Wrapper.h
//  ApparkTest
//
//  Created by steve fan on 12-2-9.
//  Copyright (c) 2012年 CocoaChina. All rights reserved.
//

#ifndef ApparkTest_Device_Wrapper_h
#define ApparkTest_Device_Wrapper_h
#include <iostream>

using namespace std;

namespace ApparkSDK
{
//#define DEVICEID        "udid"
//#define MACADRESS       "mac"
//#define APPID           "appid"
//#define APPVERSION      "appversion"
//#define EQUAL           "="

    class CDeviceInfo {
    public:
        std::string m_sDeviceId;        // 0 udid
        std::string m_sMacAdress;       // 1 Mac地址 
//        std::string m_sSerialNum;       // 2 序列号 
        std::string m_sDeviceType;      // 3 Platform String 例如 iPhone 4
        std::string m_sOsversion;       // 4 iOS 版本 
        std::string m_sLanguage;        // 5 iOS 当前设置语言 
        std::string m_sArea;            // 6 iOS 当前设置 Region Format
        std::string m_sNetWork_type;    // 7 网络类型: 3G / Wi-Fi / 其它 
        std::string m_sJailbreak;       // 8 是否越狱 YES / NO
        std::string m_sScreenSize;      // 9 屏幕分辨率 

    public:
        void GetDeviceInfo();
        bool checkIAPFExist();
        bool isHostModified(const char * pszHost);
        std::string getHostIPAddress(char * host);

    private:
        std::string getUniqueIdentifier();
        bool isJailBroken();
        inline bool isMatchString(string& strBuf, const char * pszSubStr);
    };
}


#endif
