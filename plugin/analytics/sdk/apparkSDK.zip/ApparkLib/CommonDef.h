//
//  CommonDef.h
//  ApparkTest
//
//  Created by XiaoFeng on 12-1-31.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#ifndef _COMMONDEF_H_
#define _COMMONDEF_H_

#define APPARK_SDK_VERSION                  "1.0.1"

//#define APPARK_PUNCHBOX_PRIVATE

#define APPPARK_DEFAULTDIR                  "ApparkLog"
#define APPPARK_File_Prefix                 "Log"
#define APPPARK_File_Suffix                 "apl"
#define APPPARK_AGD_File_Prefix             "AGD_Log"
#define APPPARK_MASS_File_Prefix            "Mass_Log"



#ifdef DEBUG

#define APPPARI_SERVERADDR                  "http://110.173.2.141"
#define APPPARK_DEFAULTURL                  "http://110.173.2.141/appark/www/index.php?"
#define APPPARK_LIBERYURL                   "http://110.173.2.141/appark/www/index.php?m=D&a=liberty"
#define APPPARK_GATHERURL                   "http://110.173.2.141/appark/www/index.php?m=D&a=gather"
#define APPPARK_SESSIONURL                  "http://110.173.2.141/appark/www/index.php?m=D&a=session"
#define APPPARK_GETTINGSETURL               "http://110.173.2.141/appark/www/index.php?m=Initialize&a=set"
//#define APPPARI_SERVERADDR                  "http://192.168.1.250:808"
//#define APPPARK_DEFAULTURL                  "http://192.168.1.250:808/appark/www/index.php?"
//#define APPPARK_LIBERYURL                   "http://192.168.1.250:808/appark/www/index.php?m=D&a=liberty"
//#define APPPARK_GATHERURL                   "http://192.168.1.250:808/appark/www/index.php?m=D&a=gather"
//#define APPPARK_SESSIONURL                  "http://192.168.1.250:808/appark/www/index.php?m=D&a=sission"
//#define APPPARK_GETTINGSETURL               "http://192.168.1.250:808/appark/www/index.php?m=Initialize&a=set"

#else

#define APPPARI_SERVERADDR                  "http://stat.punchbox.org"
#define APPPARK_DEFAULTURL                  "http://stat.punchbox.org/index.php?"
#define APPPARK_LIBERYURL                   "http://stat.punchbox.org/index.php?m=D&a=liberty"
#define APPPARK_GATHERURL                   "http://stat.punchbox.org/index.php?m=D&a=gather"
#define APPPARK_SESSIONURL                  "http://stat.punchbox.org/index.php?m=D&a=session"
#define APPPARK_GETTINGSETURL               "http://stat.punchbox.org/index.php?m=Initialize&a=set"

#endif



// todo zhangxm, const int const * is error when building for android
//#define const_uint_ptr      const int const *
#define const_uint_ptr      const int * const

#define EXTRA_TERMINATOR    4
/*
#define AGDLOG_SESSION_KEY                  "session"
#define AGDLOG_SESSION_STARTKEY             "starttime"
#define AGDLOG_SESSION_DURATIONKEY          "duration"
#define AGDLOG_CRASHLOG_KEY                 "crashinfo"
#define AGDLOG_APPSTART_KEY                 "appstarttime"
#define AGDLOG_SESSION_ENDTYPE_KEY          "endtype"
#define AGDLOG_SESSION_ENDTYPE_SHUT         "close"
#define AGDLOG_SESSION_ENDTYPE_SWITCH       "enterbg"
#define AGDLOG_SESSION_ENDTYPE_CRASH        "crash"

#define USERLOG_TYPE_KEY                    "LogType"
#define USERLOG_TYPE_TIMEEVENT              "TimeEvent"
#define USERLOG_TYPE_GPSPOS                 "GPSPosition"
#define USERLOG_TYPE_NORMAL                 "NormalEvent"
#define USERLOG_TYPE_ERROR                  "ErrorEvent"
#define USERLOG_SESSION_ID                  "SessionID"
#define USERLOG_TIMEVENT_BEGIN              "BeginTime"
#define USERLOG_TIMEVENT_DURATION           "Duration"
#define USERLOG_TIMEVENT_BEGINPARAM         "BeginParam"
#define USERLOG_TIMEVENT_ENDPARAM           "EndParam"
#define USERLOG_EVENT_ID                    "EventID"
#define USERLOG_EVENT_AUTOCLOSE             "AutoClose"
#define USERLOG_GPSINFO_LONGITUDE           "Longitude"
#define USERLOG_GPSINFO_LATITUDE            "Latitude"
#define USERLOG_GPSINFO_HORIZONTAL          "HorizontalAccuracy"
#define USERLOG_GPSINFO_VERTICAL            "VerticalAccuracy"
#define USERLOG_USERINFO_ACCOUNT            "Account"
#define USERLOG_USERINFO_AGE                "Age"
#define USERLOG_USERINFO_GENDER             "Gender"
#define USERLOG_ERROR_ID                    "ErrorID"
#define USERLOG_ERROR_MESSAGE               "ErrorMessage"
#define USERLOG_ERROR_PARAM                 "ErrorParam"
*/

#define AGDLOG_TOKENID_KEY                  "TID"

#define AGDLOG_SESSION_KEY                  "SL"
#define AGDLOG_SESSION_STARTKEY             "SS"
#define AGDLOG_SESSION_DURATIONKEY          "SD"
#define AGDLOG_CRASHLOG_KEY                 "CI"
#define AGDLOG_APPSTART_KEY                 "AS"
#define AGDLOG_SESSION_ENDTYPE_KEY          "SF"
#define AGDLOG_SESSION_ENDTYPE_SHUT         "ST"
#define AGDLOG_SESSION_ENDTYPE_SWITCH       "SE"
#define AGDLOG_SESSION_ENDTYPE_CRASH        "SC"

#define USERLOG_TYPE_KEY                    "LT"
#define USERLOG_TYPE_TIMEEVENT              "TE"
#define USERLOG_TYPE_GPSPOS                 "GL"
#define USERLOG_TYPE_NORMAL                 "NE"
#define USERLOG_TYPE_ERROR                  "EE"
#define USERLOG_SESSION_ID                  "SI"
#define USERLOG_TIMEVENT_BEGIN              "BT"
#define USERLOG_TIMEVENT_DURATION           "TD"
#define USERLOG_TIMEVENT_BEGINPARAM         "BP"
#define USERLOG_TIMEVENT_ENDPARAM           "EP"
#define USERLOG_EVENT_ID                    "EI"
#define USERLOG_EVENT_AUTOCLOSE             "AC"
#define USERLOG_GPSINFO_LONGITUDE           "LO"
#define USERLOG_GPSINFO_LATITUDE            "LA"
#define USERLOG_GPSINFO_HORIZONTAL          "HA"
#define USERLOG_GPSINFO_VERTICAL            "VA"
#define USERLOG_USERINFO_ACCOUNT            "ACC"
#define USERLOG_USERINFO_AGE                "AGE"
#define USERLOG_USERINFO_GENDER             "GD"
#define USERLOG_ERROR_ID                    "ER"
#define USERLOG_ERROR_MESSAGE               "EM"
#define USERLOG_ERROR_PARAM                 "EA"


#define CURRENT_NET_CONNECTION_NONE         "NONE"  // 没有网络连接 
#define CURRENT_NET_CONNECTION_3G           "3G"    // 3G or GPRS 网络 
#define CURRENT_NET_CONNECTION_WIFI         "WIFI"  // Wifi连接 

#define CRASHLOG_SUB_PATH   "crashcatchlog"
#define CRASHLOG_EXT_NAME   "csh"

#define SESSION_TEMPLOG     "tempsession.tmp"

#define SERVER_RETURN_STATUS                "status"
#define SERVER_RETURN_DATA                  "data"


typedef enum UserLogType
{
    eUserLogTypeGameData = 0,
    eUserLogTypeAGD,
    eUserLogTypeMassData,
} EUserLogType;

template <typename Type_>
static inline void SafeDeletePtr(Type_ *ptr)
{
    if(ptr)
    {
        delete ptr;
        ptr = NULL;
    }
}


template <typename Type_>
static inline void SafeDeleteArrayPtr(Type_ *ptr)
{
    if(ptr)
    {
        delete [] ptr;
        ptr = NULL;
    }
}


static inline void SafeFreePtr(void *ptr)
{
    if (ptr) {
        free(ptr);
        ptr = NULL;
    }
}


#define ZeroMemory(ptr, size) \
        { \
            memset(ptr, 0, size); \
        }


#endif
