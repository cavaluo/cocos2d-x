//
//  main.m
//  ApparkTest
//
//  Created by XiaoFeng on 12-1-31.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
