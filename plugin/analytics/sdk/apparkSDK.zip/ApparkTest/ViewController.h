//
//  ViewController.h
//  ApparkTest
//
//  Created by 叶 博 on 12-1-31.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITextFieldDelegate>
{
    UITextField *   _inputTextField;
    UITextField *   _outputTextField;
}

@property (nonatomic, retain) IBOutlet UITextField * inputTextField;
@property (nonatomic, retain) IBOutlet UITextField * outputTextField;


-(IBAction)Base64EncodePressed:(id)sender;
-(IBAction)Base64DecodePressed:(id)sender;
-(IBAction)XXTEAEncode:(id)sender;
-(IBAction)XXTEADecode:(id)sender;
-(IBAction)TestJsonWriter:(id)sender;
-(IBAction)TestJsonReader:(id)sender;
-(IBAction)TestDictionary:(id)sender;

-(IBAction)HttpRequestGet:(id)sender;
-(IBAction)TestLogUploader:(id)sender;

@end
