//
//  Wrapper.h
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-1.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Wrapper : NSObject
{
}

+(int)base64Encode:(const unsigned char *)input output:(unsigned char *)output size:(int)size;
+(int)base64Decode:(const unsigned char *)input output:(unsigned char *)output isConfuse:(BOOL)isConfuse;
+(int)xxteaEncode:(const unsigned char *)input output:(unsigned char *)output size:(int)size userKey:(const int const *)userKey;
+(bool)xxteaDecode:(const unsigned char *)input output:(unsigned char *)output size:(int)size userKey:(const int const *)userKey;

+(void)TestJsonWriter;
+(void)TestJsonReader:(NSString *)strJson;
+(void)TestDictionary:(NSString *)strJson;
+(void)TestSyncHttpGet:(NSString *)strURL;
+(void)TestFileLoader:(NSString *)strFile;
-(void)TestSendToSever:(NSString *)strFile;
+(void)TestSortVector;

+(char *)makeTestJson;
+(void)TestGameDataManager;
+(void)testLocalSettingManager;
+(void)testThreadFunc;

+(void)testCrash;

+(void)testTimeFormat;
+(void)testChaosInt;


+(void)testDecodeDict:(NSString *)strFileName;
+(void)deCodeLogs;

@end