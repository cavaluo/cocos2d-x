//
//  ViewController.m
//  ApparkTest
//
//  Created by XiaoFeng on 12-1-31.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#import "ViewController.h"
#import "Wrapper.h"

#include <sys/socket.h> // Per msqr
#include <sys/sysctl.h>
#include <net/if.h>
#include <net/if_dl.h>


@interface ViewController()
{
    NSData * _encodeData;
    Wrapper * _myWrapper;
}

@property (nonatomic, retain) NSData *  encodeData;
@property (nonatomic, retain) Wrapper * myWrapper;

@end

NSString * strJsonTest = @"{ \
\"Float Value\" : 12.3450, \
\"Int Value\" : 100, \
\"String Value\" : \"test string\", \
\"Test Array\" : [ \
                { \
                    \"Int Item\" : 100 \
                }, \
                { \
                    \"Double Item\" : 123.450 \
                }, \
                { \
                    \"String Item\" : \"array test\" \
                } \
                ], \
\"array num\" : [ \
               { \
                   \"item0\" : 0 \
               }, \
               { \
                   \"item1\" : 1 \
               }, \
               { \
                   \"item2\" : 2 \
               }, \
               { \
                   \"item3\" : 3 \
               }, \
               { \
                   \"item4\" : 4 \
               }, \
               { \
                   \"item5\" : 5 \
               }, \
               { \
                   \"item6\" : 6 \
               }, \
               { \
                   \"item7\" : 7 \
               }, \
               { \
                   \"item8\" : 8 \
               }, \
               { \
                   \"item9\" : 9 \
               } \
               ] \
}";


NSString * strSubJsonTest = @"{ \
\"Float Value\" : 12.3450, \
\"Int Value\" : 200, \
\"String Value\" : \"test string\", \
\"Test Array\" : [ \
                { \
                    \"Int Item\" : 100 \
                }, \
                { \
                    \"Double Item\" : 123.450 \
                }, \
                { \
                    \"String Item\" : \"array test\" \
                } \
                ], \
\"TestSub\" : { \
    \"Sub Value1\" : 1010, \
    \"Sub Value2\" : 10.10, \
    \"Sub Value3\" : \"10\", \
    \"Sub array\" : [ \
                   { \
                       \"sub array item\" : 1011 \
                   } \
                   ] \
    } \
}";

const char * macaddress();

#pragma mark MAC addy
// Return the local MAC addy
// Courtesy of FreeBSD hackers email list
// Accidentally munged during previous update. Fixed thanks to mlamb.
const char * macaddress()
{
    int                 mib[6];
    size_t              len;
    char                *buf;
    unsigned char       *ptr;
    struct if_msghdr    *ifm;
    struct sockaddr_dl  *sdl;
    
    mib[0] = CTL_NET;
    mib[1] = AF_ROUTE;
    mib[2] = 0;
    mib[3] = AF_LINK;
    mib[4] = NET_RT_IFLIST;
    
    if ((mib[5] = if_nametoindex("en0")) == 0) {
        printf("Error: if_nametoindex error\n");
        return NULL;
    }
    
    if (sysctl(mib, 6, NULL, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 1\n");
        return NULL;
    }
    
    if ((buf = (char *)malloc(len)) == NULL) {
        printf("Could not allocate memory. error!\n");
        return NULL;
    }
    
    if (sysctl(mib, 6, buf, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 2");
        return NULL;
    }
    
    ifm = (struct if_msghdr *)buf;
    sdl = (struct sockaddr_dl *)(ifm + 1);
    ptr = (unsigned char *)LLADDR(sdl);
    NSString *outstring = [NSString stringWithFormat:@"%02X:%02X:%02X:%02X:%02X:%02X", 
                           *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    // NSString *outstring = [NSString stringWithFormat:@"%02X%02X%02X%02X%02X%02X", 
    //                       *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    free(buf);
    
    return [outstring UTF8String];
}


@implementation ViewController

@synthesize inputTextField = _inputTextField;
@synthesize outputTextField = _outputTextField;
@synthesize encodeData = _encodeData;
@synthesize myWrapper = _myWrapper;

- (void)dealloc
{
    self.encodeData = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.myWrapper = [[Wrapper alloc] init];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

-(IBAction)Base64EncodePressed:(id)sender
{
/*    CGSize screenSize;
    if([UIScreen instancesRespondToSelector:@selector(currentMode)])
        screenSize = [[UIScreen mainScreen] currentMode].size;
    NSString * scrSize = NSStringFromCGSize(screenSize);
    NSLog(@"%@",scrSize);
    
    macaddress();

    NSString * strTemp = self.inputTextField.text;
    if(!strTemp || [strTemp length] <= 0)
    {
        NSLog(@"Input is empty!");
        return;
    }
    const char * source = [strTemp cStringUsingEncoding:NSUTF8StringEncoding];
    int size = [Wrapper base64Encode:(const unsigned char *)source output:nil size:strlen(source)] + 4;
    char * dest = malloc(size);
    if (!dest)
    {
        NSLog(@"Allocation output buffer error!");
        return;
    }
    memset(dest, 0, size);
    size = [Wrapper base64Encode:(const unsigned char *)source output:(unsigned char *)dest size:strlen(source)];
    strTemp = [NSString stringWithCString:dest encoding:NSASCIIStringEncoding];
    strTemp = [strTemp stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@" "]];
    self.outputTextField.text = strTemp;
    NSLog(@"Base64 encode output size : %d\n%@", size, strTemp);
    free(dest);*/
    NSString * strTemp = self.inputTextField.text;
    if(!strTemp || [strTemp length] <= 0)
    {
        NSLog(@"Input is empty!");
        return;
    }
    const char * source = [strTemp cStringUsingEncoding:NSUTF8StringEncoding];
    int size = [Wrapper base64Decode:(const unsigned char *)source output:nil isConfuse:NO] + 4;
    char * dest = malloc(size);
    if(!dest)
    {
        NSLog(@"Allocation output buffer error!");
        return;
    }
    memset(dest, 0, size);
    //    memcpy(dest, source, size - 4);
    size = [Wrapper base64Decode:(const unsigned char *)source output:(unsigned char *)dest isConfuse:NO];
    NSLog(@"Base64 decode output size : %d", size);
    NSLog(@"Base64 decode output string : %s", dest);
    strTemp = [NSString stringWithCString:dest encoding:NSUTF8StringEncoding];
    strTemp = [strTemp stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@" "]];
    self.outputTextField.text = strTemp;
    free(dest);
}

-(IBAction)Base64DecodePressed:(id)sender
{
//    NSDateFormatter * dateFormatter = [[NSDateFormatter alloc] init];
//    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
//    NSString * dateString = [dateFormatter stringFromDate:[NSDate date]];
//    NSLog(@"%s", [dateString UTF8String]);

    NSString * strTemp = self.inputTextField.text;
    if(!strTemp || [strTemp length] <= 0)
    {
        NSLog(@"Input is empty!");
        return;
    }
    const char * source = [strTemp cStringUsingEncoding:NSUTF8StringEncoding];
    int size = [Wrapper base64Decode:(const unsigned char *)source output:nil isConfuse:YES] + 4;
    char * dest = malloc(size);
    if(!dest)
    {
        NSLog(@"Allocation output buffer error!");
        return;
    }
    memset(dest, 0, size);
//    memcpy(dest, source, size - 4);
    size = [Wrapper base64Decode:(const unsigned char *)source output:(unsigned char *)dest isConfuse:YES];
    NSLog(@"Base64 decode output size : %d", size);
    NSLog(@"Base64 decode output string : %s", dest);
    strTemp = [NSString stringWithCString:dest encoding:NSUTF8StringEncoding];
    strTemp = [strTemp stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@" "]];
    self.outputTextField.text = strTemp;
    free(dest);
}

-(IBAction)XXTEAEncode:(id)sender
{
    NSString * strTemp = self.inputTextField.text;
    if(!strTemp || [strTemp length] <= 0)
    {
        NSLog(@"Input is empty!");
        return;
    }
    const char * source = [strTemp cStringUsingEncoding:NSUTF8StringEncoding];
    int size = [Wrapper xxteaEncode:(const unsigned char *)source output:nil size:strlen(source) userKey:nil] + 4;
    char * dest = malloc(size);
    if(!dest)
    {
        NSLog(@"Allocation output buffer error!");
        return;
    }
    memset(dest, 0, size);
    size = [Wrapper xxteaEncode:(const unsigned char *)source output:(unsigned char *)dest size:strlen(source) userKey:nil];

    int nSize2 = [Wrapper base64Encode:(const unsigned char *)dest output:NULL size:size];
    char * base64Buf = (char *)malloc(nSize2 + 4);
    memset(base64Buf, 0, nSize2 + 4);
    [Wrapper base64Encode:(const unsigned char *)dest output:(unsigned char *)base64Buf size:size];
    printf("\n\nBase 64 Result : %s\n\n", base64Buf);
    free(base64Buf);

    printf("\nEncrypted data :\n");
    for (int i = 0; i < size; i++)
        printf("%02X ", dest[i] & 0x000000FF);
    printf("\n");
    self.encodeData = [NSData dataWithBytes:dest length:size];
    NSLog(@"XXTEA encode data : %@", self.encodeData);
    self.outputTextField.text = [[NSString alloc] initWithData:self.encodeData encoding:NSASCIIStringEncoding];
    NSLog(@"ASCII码[%@]", self.outputTextField.text);
    free(dest);
}


//0xD4, 0x7F, 0x6D, 0xDC, 0xED, 0x5D, 0x5F, 0xD0, 0x0B, 0x31, 0x09, 0x2A};
char szTestData[] = {0x86, 0xAA, 0xF7, 0x75, 0x3B, 0xD3, 0xA2, 0x29, 0x5B, 0xC7, 0xCD, 0xDF};
-(IBAction)XXTEADecode:(id)sender
{
    self.encodeData = [NSData dataWithBytes:szTestData length:12];
    if (!self.encodeData)
    {
        NSLog(@"No encrypt data avaliable");
        return;
    }
    int dataSize = self.encodeData.length;
    char *dest = malloc(dataSize + 4);
    if(!dest)
    {
        NSLog(@"Allocation output buffer error!");
        return;
    }
    memset(dest, 0, dataSize + 4);
    bool isDecryptOK = [Wrapper xxteaDecode:self.encodeData.bytes output:(unsigned char *)dest size:dataSize userKey:nil];
    if (!isDecryptOK)
    {
        NSLog(@"Encrypt data size is bad! Not 8 bytes aligned.");
        return;
    }
    NSLog(@"Decrypt data : %s", dest);
    free(dest);
}

-(IBAction)TestJsonWriter:(id)sender
{
//    [Wrapper TestJsonWriter];
//    [Wrapper testThreadFunc];
//    [Wrapper testCrash];
    [Wrapper deCodeLogs];
}

-(IBAction)TestJsonReader:(id)sender
{
//    [Wrapper TestJsonReader:strJsonTest];
//    [Wrapper testTimeFormat];
    [Wrapper TestFileLoader:nil];
}


-(IBAction)TestDictionary:(id)sender
{
    [Wrapper TestDictionary:strSubJsonTest];
}


-(IBAction)HttpRequestGet:(id)sender
{

    //[Wrapper TestSyncHttpGet:_inputTextField.text];
    [Wrapper TestGameDataManager];
}

-(IBAction)TestLogUploader:(id)sender{
//    [Wrapper TestFileLoader:_inputTextField.text];
//    [Wrapper TestSortVector];
    [Wrapper testChaosInt];
}

-(IBAction)TestSendToSever:(id)sender{
    [self.myWrapper TestSendToSever:_inputTextField.text];
}

#pragma TextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
@end
