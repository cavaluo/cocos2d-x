//
//  DataDeliver.h
//  ApparkTest
//
//  Created by XiaoFeng on 12-4-7.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#ifndef ApparkTest_DataDeliver_h
#define ApparkTest_DataDeliver_h

#define PARAM_URL_UDID      "udid="
#define PARAM_URL_FILEID    "file="
#define PARAM_URL_APPID     "appID="
#define PARAM_URL_APPVER    "appVersion="
#define PARAM_URL_NUMBER    "number="
#define PARAM_URL_TIMEKEY   "m="
#define PARAM_URL_MD5KEY    "v="

#define DATA_DESCRIPT_STATUS    "status"
#define DATA_DESCRIPT_INFO      "info"
#define DATA_DESCRIPT_VERSION   "version"
#define DATA_DESCRIPT_URL       "url"
#define DATA_DESCRIPT_STATUSOK  "ok"

#define VERSION_NOT_INIT        -1
#define VERSION_GAME_DEFAULT    1

#ifdef DEBUG

#define COMMIT_URL  "http://122.49.33.245/bydr/index.php?Peizhi200/upPeizhiInfo/"

#else

#define COMMIT_URL  "http://fishingjoy.punchbox.org/bydr/index.php?Peizhi200/upPeizhiInfo/"

#endif

using namespace std;

typedef void (*DELIVER_CALLBACK)(void *, int, bool, const char *) ;
typedef void (*COMMIT_CALLBACK)(void *, bool, const char *);
typedef void (*ASYNDOWN_CALLBACK)(void *, bool, char *);

class CDataDeliver
{
public:
    CDataDeliver();

public:
    void InitDeliver(const char * pszHost, const char * pszAppID, 
                     const char * pszAppVersion, const char * pszUDID);
    bool IsInitialized();
    bool UpdateData(const char * pszFileID, const char * pszFullPathSaveName, 
                    DELIVER_CALLBACK pCallBackFunc, void * pCallbackParam, 
                    int nCurVersion);

    bool LoadLocalFile(const char * pszFullPath, char ** ppszBuffer);
    bool SaveLocalFile(const char * pszFullPath, char * pszBuffer);
    void DoUpdateFile();

    bool CommitUpdate(const char * pszFileID, int nVersion, 
                      COMMIT_CALLBACK pCommitCallback, void * pCallbackParam);
    void DoCommit();

    bool AsynDownloadToBuffer(const char * pUrl, ASYNDOWN_CALLBACK pAsynCallback,
                              void * pCallbackParam);
    void doAsynDownload();

private:
    static void * UpdateThreadFunction(void * pParam);
    static void * CommitThreadFunction(void * pParam);
    static void * AsynDownThreadFunction(void * pParam);

private:
    bool    m_bInitialized;
    string  m_strHost;
    string  m_strUDID;
    string  m_strAppID;
    string  m_strAppVersion;

    string  m_strRequestURL;
    string  m_strSaveFile;
    string  m_strFileID;
    string  m_strCommitURL;
    string  m_strCommitID;
    string  m_strAsynDownloadUrl;

    DELIVER_CALLBACK  m_pCallbackFunc;
    COMMIT_CALLBACK   m_pCommitCallBack;
    ASYNDOWN_CALLBACK m_pAsynCallback;

    void *  m_pCallbackParam;
    void *  m_pCommitCallbackParam;
    void *  m_pAsynCallbackParam;
    int     m_nCurrentVersion;
};

#endif

// http://www.punchbox.org/test/appark/mail.php?