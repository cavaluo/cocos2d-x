//
//  Wrapper.mm
//  ApparkTest
//
//  Created by XiaoFeng on 12-2-1.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#import "Wrapper.h"
#include "ApparkSDK.h"
#include "EncryptionManager.h"
//#include "JsonReader.h"
//#include "JsonWriter.h"
#include "DictionaryDataGather.h"
#include "LogUpLoader.h"
#include "LogManager.h"
#include "LocalSettingManager.h"
#include "BaseAlgorithm.h"

#include <cstdio>
#include <iostream>
#include <fstream>

#import "HttpRequest.h"
#import "GameDataManager.h"
#import "PBAppark.h"
#include <pthread.h>
#import "Device_Wrapper.h"

#include "ChaosNumber.h"
#include "DataDeliver.h"

using namespace ApparkSDK;

@interface Wrapper ()
{
//    CGameDataManager gameDataManager;
    PBAppark * _appark;
}


@end

@implementation Wrapper

void commitBack(void * pParam, bool success, const char * id);


void commitBack(void * pParam, bool success, const char * id)
{
    
}


static void notifyFunc(void *pClass, void *pHttpOperator, bool val){
    CHttpRequest *rap = (CHttpRequest *)pClass;
    rap->getSuccesfulInfo(val);
}

void * threadFunc(void * param);

-(id)init
{
    self = [super init];
    if (self) {
        _appark = [PBAppark sharedSDK];
        [_appark setupApparkSDK:@"739743927fs" appVersion:@"1.6.4" deviceToken:@"yfuies9erw" logPath:nil];
    }
    return self;
}

+(void)TestGameDataManager {
    //gameDataManager.Init();
    //gameDataManager.m_pEncryptor; // 不必要?
    //gameDataManager.m_pHttpOperator
    
    //gameDataManager.SubmitGameData(<#const char *ServerURL#>, <#char *LocalFullPath#>, <#EncryptOperationType EncryptOperation#>)    
    //gameDataManager.DownloadGameData(<#const char *ServerURL#>, <#char *LocalFullPath#>, <#EncryptOperationType EncryptOperation#>)
    //gameDataManager.SubmitDataBuffer(<#const char *ServerURL#>, <#char *DataBuffer#>, <#EncryptOperationType EncryptOperation#>)
    //gameDataManager.DownloadToBuffer(<#const char *ServerURL#>, <#char **buffer#>, <#EncryptOperationType EncryptOperation#>)
    
    //const char * url = "http://192.168.2.234/~lvyile/"; //
    //const char * url = "http://192.168.1.253/fishjoy_dev/www/index.php";
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];    
    //NSString* testFileName = [NSString stringWithFormat:@"lvTest[%f].txt", [[NSDate date] timeIntervalSince1970]];
    NSString* testFileName = @"lvTest[1328987934.906218].txt";//[NSString stringWithFormat:@"lvTest[%f].txt", [[NSDate date] timeIntervalSince1970]];    
    NSString *fileFullPath = [documentsDirectory stringByAppendingPathComponent:testFileName];
    NSLog(@"fileFullPath[%@]", fileFullPath);
    const char * path = [fileFullPath UTF8String];
    
    CGameDataManager gameDataManager;
    BOOL ret = false;
    
    const char * url = "http://10.0.2.4/~staotao/";        
    ret = gameDataManager.DownloadGameData(url, (char *)path,  EncryptOperationTypeEncryption ); // 加密
    ret = gameDataManager.DownloadGameData(url, (char *)path,  EncryptOperationTypeDecryption );   // 解密
    ret = gameDataManager.DownloadGameData(url, (char *)path,  EncryptOperationTypeNone );      // 不处理
    NSLog(@"DownloadGameData测试结果[%d]", ret);
    NSLog(@"\n\n");    
    
    url = "http://localhost:8888/add.php";
    ret = gameDataManager.SubmitGameData(url, (char *)path, EncryptOperationTypeEncryption); 
    ret = gameDataManager.SubmitGameData(url, (char *)path, EncryptOperationTypeDecryption);    
    ret = gameDataManager.SubmitGameData(url, (char *)path, EncryptOperationTypeNone);
    NSLog(@"SubmitGameData测试结果[%d]", ret);    
    NSLog(@"\n\n");
    
    url = "http://localhost:8888/add.php";    
    ret = gameDataManager.SubmitDataBuffer(url, (char *)"你好123Helloworld", EncryptOperationTypeEncryption);        
    ret = gameDataManager.SubmitDataBuffer(url, (char *)"W5UAmB/3aCVfBlZOPhTJuRQbqq4g3u5+", EncryptOperationTypeDecryption);        
    ret = gameDataManager.SubmitDataBuffer(url, (char *)"ndxiJPLWyjwWJin7Y1YywmSzvwnoDWjd", EncryptOperationTypeDecryption);
    ret = gameDataManager.SubmitDataBuffer(url, (char *)"你好123Helloworld", EncryptOperationTypeNone);        
    NSLog(@"SubmitGameData测试结果[%d]", ret);    
    NSLog(@"\n\n");
    
    //*
    char *buffer = NULL;
    url = "http://192.168.1.253/fishjoy_dev/www/index.php";
    ret = gameDataManager.DownloadToBuffer(url, &buffer,  EncryptOperationTypeEncryption );    // 加密
    ret = gameDataManager.DownloadToBuffer(url, &buffer,  EncryptOperationTypeDecryption );        // 解密
    ret = gameDataManager.DownloadToBuffer(url, &buffer,  EncryptOperationTypeNone );        // 不处理
    NSLog(@"测试结果[%d]\r\n[%s]", ret, buffer);
    NSLog(@"\n\n");
    
    NSString* tStr = [NSString stringWithCString:buffer  encoding:NSUTF8StringEncoding];//NSASCIIStringEncoding
    NSError* error = nil;
    testFileName = [NSString stringWithFormat:@"lvTest[%f].txt", [[NSDate date]  timeIntervalSince1970]];
    fileFullPath = [documentsDirectory stringByAppendingPathComponent:testFileName];
    ret = [tStr writeToFile:fileFullPath atomically:YES encoding:NSUTF8StringEncoding error:&error];
    NSLog(@"DownloadToBuffer测试结果[%d]\r\n错误[%@]", ret, error);    
    //*/
}

+ (void)TestSyncHttpGet:(NSString *)strURL{
    
    //const char* charStr = "http://g.cn/";
    //const char* charStr = "http://www.cocoachina.com";
    const char* charStr = "http://192.168.1.253/fishjoy_dev/www/index.php"; //?m=User&a=query&uid=xiaofeng";
    
    CHttpRequest httpRequest;    
    // 1 设置URL
    //const char* charStr = (const char *)[strURL cStringUsingEncoding:NSUTF8StringEncoding];
    httpRequest.SetRequestURL(charStr);
    NSLog(@"设置URL[%s]", charStr);
    CALLBACK_FUNC func = notifyFunc;
    httpRequest.SetNotifyFunc(func);
    
    // 设置请求方法
    httpRequest.m_iOperationMethod = iOperationMethodGet;
    // 设置
//    httpRequest.SetMessageToServer("method=m=User&a=query&uid=xiaofeng");
    
    // 2 开始同步请求请求
    BOOL requestRet = httpRequest.StartRequest(cCommunicationTypeSync, &httpRequest);
    NSLog(@"请求是否成功[%d]", requestRet);            

    NSLog(@"服务器请求返回的状态值[%ld]", httpRequest.m_iOperationResult);

    if (requestRet) {
        // 3 获取返回值        
//        NSLog(@"服务器获取的数据[%s]", httpRequest.m_cReceivedData.c_str());   
    }
    else{
        NSLog(@"the error is [%s]", httpRequest.GetErrorMessage());
    }
}


+(int)base64Encode:(const unsigned char *)input output:(unsigned char *)output size:(int)size
{
    return CEncryptionManager::Base64Encode(input, output, size);
}


+(int)base64Decode:(const unsigned char *)input output:(unsigned char *)output isConfuse:(BOOL)isConfuse
{
    if (isConfuse && output)
    {
        CEncryptionManager::ConfuseString((char *)input);
    }
    return CEncryptionManager::Base64Decode(input, output);
}


+(int)xxteaEncode:(const unsigned char *)input output:(unsigned char *)output size:(int)size userKey:(const int const *)userKey
{
    return CEncryptionManager::XXTEAEncode(input, output, size, userKey);
}


+(bool)xxteaDecode:(const unsigned char *)input output:(unsigned char *)output size:(int)size userKey:(const int const *)userKey
{
    return CEncryptionManager::XXTEADecode(input, output, size, userKey);
}


+(void)TestJsonWriter
{
/*    NSString * strTemp;
    CJsonWriter objWriter;
    objWriter.InsertItem("Int Value", 100);
    objWriter.InsertItem("Float Value", 12.345);
    objWriter.InsertItem("String Value", "test string");
    assert(objWriter.InsertArrayItem("Test Array", 100));
    assert(objWriter.InsertArrayItem("Test Array", 123.45));
    assert(objWriter.InsertArrayItem("Test Array", "array test"));
    for (int i = 0; i < 10; i++)
    {
        objWriter.InsertArrayItem("array num", i);
    }
    strTemp = [NSString stringWithCString:objWriter.GetDescriptionString() encoding:NSASCIIStringEncoding];
    NSLog(@"Json string :\n%@", strTemp);
    if(!objWriter.InsertArrayItem("Int Value", 200))
        NSLog(@"Can not insert sub item to none array nor object item");
    else
        NSLog(@"Insert sub item to none array nor object item ok");
    objWriter.InsertItem("Int Value", 200);
    strTemp = [NSString stringWithCString:objWriter.GetDescriptionString() encoding:NSASCIIStringEncoding];
    NSLog(@"Json string :\n%@", strTemp);

    CJsonWriter subObj;
    subObj.InsertItem("Sub Value1", 1010);
    subObj.InsertItem("Sub Value2", 10.1);
    subObj.InsertItem("Sub Value3", "10");
    subObj.InsertArrayItem("Sub array", 1011);
    objWriter.InsertItem("TestSub", subObj.GetValue());
    strTemp = [NSString stringWithCString:objWriter.GetDescriptionString() encoding:NSASCIIStringEncoding];
    NSLog(@"Json string with sub json:\n%@", strTemp);*/
}


+(void)TestJsonReader:(NSString *)strJson
{
/*    CJsonReader objReader;
    char * strTemp = (char *)[strJson cStringUsingEncoding:NSUTF8StringEncoding];
    objReader.InitWithDescription(strTemp);
    NSLog(@"%s", objReader.m_cRoot.toStyledString().c_str());
    Json::Value * test = objReader.GetSubJsonItem("Test Array");
    CJsonReader newReader;
    newReader.InitWithValue(*test);
    NSLog(@"%s", newReader.m_cRoot.toStyledString().c_str());

    string key = "Int Value";
    NSLog(@"Get Int value for int member : %d", objReader.GetIntValue(key.c_str(), 0));
    NSLog(@"Get float value for int member : %f", objReader.GetDoubleValue(key.c_str(), 0.0));
    if (objReader.GetStringValue(key.c_str())) 
        NSLog(@"Get string value for int member : %s", objReader.GetStringValue(key.c_str()));
    else
        NSLog(@"Can not get string value for int member");
    Json::Value * tempValue = objReader.GetSubJsonItem(key.c_str());
    if (tempValue) {
        NSLog(@"Get object value for int member : %s", tempValue->toStyledString().c_str());
    } else
        NSLog(@"Can not get object value for int member");

    key = "Float Value";
    NSLog(@"Get Int value for float member : %d", objReader.GetIntValue(key.c_str(), 0));
    NSLog(@"Get float value for float member : %f", objReader.GetDoubleValue(key.c_str(), 0.0));
    if (objReader.GetStringValue(key.c_str()))
        NSLog(@"Get string value for float member : %s", objReader.GetStringValue(key.c_str()));
    else
        NSLog(@"Can not get string value for float member");
    tempValue = objReader.GetSubJsonItem(key.c_str());
    if (tempValue) {
        NSLog(@"Get object value for float member : %s", tempValue->toStyledString().c_str());
    } else
        NSLog(@"Can get object value for float member");

    key = "String Value";
    NSLog(@"Get Int value for string member : %d", objReader.GetIntValue(key.c_str(), 0));
    NSLog(@"Get float value for string member : %f", objReader.GetDoubleValue(key.c_str(), 0.0));
    if (objReader.GetStringValue(key.c_str()))
        NSLog(@"Get string value for string member : %s", objReader.GetStringValue(key.c_str()));
    else
        NSLog(@"Can not get string value for string member");
    tempValue = objReader.GetSubJsonItem(key.c_str());
    if (tempValue) {
        NSLog(@"Get object value for string member : %s", tempValue->toStyledString().c_str());
    } else
        NSLog(@"Can get object value for string member");

    key = "Test Array";
    NSLog(@"Get Int value for obj member : %d", objReader.GetIntValue(key.c_str(), 0));
    NSLog(@"Get float value for obj member : %f", objReader.GetDoubleValue(key.c_str(), 0.0));
    if (objReader.GetStringValue(key.c_str()))
        NSLog(@"Get string value for obj member : %s", objReader.GetStringValue(key.c_str()));
    else
        NSLog(@"Can not get string value for obj member");
    tempValue = objReader.GetSubJsonItem(key.c_str());
    if (tempValue) {
        NSLog(@"Get object value for obj member : %s", tempValue->toStyledString().c_str());
    } else
        NSLog(@"Can get object value for obj member");

    if (objReader.GetItemType(key.c_str()) == Json::objectValue)
        NSLog(@"array sub item is object type");
    if (objReader.GetItemType(key.c_str()) == Json::arrayValue)
        NSLog(@"array sub item is array type");

    CJsonReader testReader;
    testReader.InitWithValue(*tempValue);
    tempValue = testReader.GetSubJsonItem(0);
    NSLog(@"Array item 0 : %s", tempValue->toStyledString().c_str());*/
}

+(void)TestDictionary:(NSString *)strJson
{
    CDictionaryDataGather testDict;
    testDict.InitWithDescription([strJson UTF8String]);
    Json::FastWriter fwriter;
    Json::StyledWriter swriter;

//    NSLog(@"fast writer description : %s\n\n", fwriter.write(testDict.m_cValue).c_str());
//    NSLog(@"style writer description : %s\n\n", swriter.write(testDict.m_cValue).c_str());
    

/*    CDictionaryDataGather dict;

    dict.InsertItem("test 1", 1);
    dict.InsertItem("test 2", 2.0);
    dict.InsertItem("test 3", "333");
    dict.InsertItemToArray("array test", "sub item1", 11);
    dict.InsertItemToArray("array test", "sub item2", 2.2);
    dict.InsertItemToArray("array test", "sub item3", "666");
    printf("Dictionary descript : \n%s\n\n", dict.GetDescription());
    NSString * nsstrTemp = [NSString stringWithUTF8String:dict.GetDescription()];
//    NSLog(@"Dictionary descript : %@\n\n", nsstrTemp);

    CDictionaryDataGather subDict;
    subDict.InsertItem("sub 1", 100);
    subDict.InsertItem("sub 2", 4.4);
    subDict.InsertItem("sub 3", "888");

    dict.InsertItem("sub test", &subDict);
    nsstrTemp = [NSString stringWithUTF8String:dict.GetDescription()];
    NSLog(@"Dictionary descript : %@\n\n", nsstrTemp);

    dict.InitWithDescription([strJson cStringUsingEncoding:NSUTF8StringEncoding]);
    NSLog(@"dict get int member int value : %d", dict.GetItemIntValue("Int Value", 0));
    NSLog(@"dict get int member float value : %f", dict.GetItemFloatValue("Int Value", 0.0));
    if (dict.GetItemStringValue("Int Value")) {
        nsstrTemp = [NSString stringWithCString:dict.GetItemStringValue("Int Value") encoding:NSUTF8StringEncoding];
        NSLog(@"dict get int member string value : %@", nsstrTemp);
    }
    else
        NSLog(@"can not get int member string value");

    NSLog(@"dict get float member int value : %d", dict.GetItemIntValue("Float Value", 0));
    NSLog(@"dict get float member float value : %f", dict.GetItemFloatValue("Float Value", 0.0));
    if (dict.GetItemStringValue("Float Value")) {
        nsstrTemp = [NSString stringWithUTF8String:dict.GetItemStringValue("Float Value")];
        NSLog(@"dict get float member string value : %@", nsstrTemp);
    }
    else
        NSLog(@"can not get float member string value");

    NSLog(@"dict get string member int value : %d", dict.GetItemIntValue("String Value", 0));
    NSLog(@"dict get string member float value : %f", dict.GetItemFloatValue("String Value", 0.0));
    if (dict.GetItemStringValue("String Value")) {
        nsstrTemp = [NSString stringWithUTF8String:dict.GetItemStringValue("String Value")];
        NSLog(@"dict get string member string value : %@", nsstrTemp);
    }
    else
        NSLog(@"can not get string member string value");
    
    CDictionaryDataGather * getSubTest = dict.GetSubDictionary("TestSub");
    if(!getSubTest)
        NSLog(@"Get sub dictionary failed.");
    else
    {
        nsstrTemp = [NSString stringWithUTF8String:getSubTest->GetDescription()];
        NSLog(@"Sub dictionary descript : %@\n\n", nsstrTemp);
    }

    getSubTest = dict.GetSubDictionaryFromArray("Test Array", 1);
    if(!getSubTest)
        NSLog(@"Get sub dictionary from array failed.");
    else
    {
        nsstrTemp = [NSString stringWithUTF8String:getSubTest->GetDescription()];
        NSLog(@"Sub dictionary from array descript : %@\n\n", nsstrTemp);
    }

    nsstrTemp = [NSString stringWithUTF8String:dict.GetDescription()];
    NSLog(@"Dictionary descript : %@\n\n", nsstrTemp);
    dict.DeleteItem("Test Array");
    printf("Dictionary descript after delete:\n %s", dict.GetDescription());
//    nsstrTemp = [NSString stringWithUTF8String:dict.GetDescription()];
//    NSLog(@"Dictionary descript after delete: %@", nsstrTemp);*/
//    [Wrapper makeTestJson];
//    [Wrapper testLocalSettingManager];

//    NSString * postURL;
/*    string strTest = [Wrapper makeTestJson];
    CHttpRequest myRequest;
    myRequest.SetRequestURL("http://192.168.1.250:808/appark/www/index.php?");
    string strData = "m=D&a=liberty&udid=udid&mac=mac&appid=appid&timestamp=timestamp&appversion=appversion&sdkversion=sdkversion";
    strData += strTest.c_str();
    myRequest.SetMessageToServer(strData.c_str());
    myRequest.m_iOperationMethod = iOperationMethodPost;
    if(myRequest.StartRequest(cCommunicationTypeSync, NULL))
        NSLog(@"Post data to sever OK!");
    else
        NSLog(@"Post data to server failed!");*/
/*    int nSize;
    char * deBaseBuf, * deXXBuf;
//    deBaseBuf = (char *)malloc(strlen(szMsgOut)+4);
    deXXBuf = (char *)malloc(strlen(szMsgOut)+4);
//    ZeroMemory(deBaseBuf, strlen(szMsgOut)+4);
    ZeroMemory(deXXBuf, strlen(szMsgOut)+4);
//    nSize = CEncryptionManager::Base64Decode((const unsigned char *)szMsgOut, (unsigned char *)deBaseBuf);
    deBaseBuf = CEncryptionManager::URLDecode(szMsgOut, (size_t *)&nSize);
    nSize = CEncryptionManager::XXTEADecode((const unsigned char *)deBaseBuf, (unsigned char *)deXXBuf, nSize);
    printf("%s\n\n", deXXBuf);
    free(deBaseBuf);
    free(deXXBuf);*/

/*    char szTest[] = "just for test";
    char *pEncode, *pDecode;
    int nSize = CEncryptionManager::Base64Encode((const unsigned char *)szTest, NULL, strlen(szTest));
    pEncode = (char *)malloc(nSize + 4);
    pDecode = (char *)malloc(nSize + 4);
    ZeroMemory(pEncode, nSize + 4);
    ZeroMemory(pDecode, nSize + 4);
    nSize = CEncryptionManager::Base64Encode((const unsigned char *)szTest, (unsigned char *)pEncode, strlen(szTest));
    printf("encode size : %d, \t%s\n\n", nSize, pEncode);
    CEncryptionManager::ConfuseString(pEncode);
    printf("after confuse : %s\n\n", pEncode);
    nSize = CEncryptionManager::Base64Decode((const unsigned char *)pEncode, (unsigned char *)pDecode);
    printf("decode confuse string size : %d,\t%s\n\n", nSize, pDecode);
    CEncryptionManager::ConfuseString(pEncode);
    printf("after 2 confuse : %s\n\n", pEncode);
    ZeroMemory(pDecode, nSize + 4);
    nSize = CEncryptionManager::Base64Decode((const unsigned char *)pEncode, (unsigned char *)pDecode);
    printf("decode 2 confuse string size : %d,\t%s\n\n", nSize, pDecode);
    free(pEncode);
    free(pDecode);*/
}


//udid, mac, appid, data, timestamp, appversion, sdkversion
+(void)TestFileLoader:(NSString *)strFile{
/*    CHttpRequest httpRequest;
    httpRequest.SetRequestURL("http://192.168.1.250:808/appark/www/index.php?m=D&a=liberty&udid=udid&mac=mac&appid=appid&timestamp=timestamp&appversion=appversion&sdkversion=sdkversion");
//    NSLog(@"设置URL[%s]", charStr);
    CALLBACK_FUNC func = notifyFunc;
    httpRequest.SetNotifyFunc(func);

    CLogUploader logUploader(&httpRequest);
    NSString *pPath = [[NSBundle mainBundle] pathForResource:@"test" ofType:@"txt"];
    const char * filepath = [pPath cStringUsingEncoding:NSUTF8StringEncoding];
    FILE *pFile = fopen(filepath, "ab+");
    const char *testJson = [Wrapper makeTestJson];
    fseek(pFile, -1, SEEK_END);
    fwrite(testJson, sizeof(char), strlen(testJson), pFile);
    fclose(pFile);
//    char *pBuffer = new char[strlen(testJson)];
    char *pFilePath = (char *)filepath;
    //void *param= nil;
  logUploader.UploadFile(pFilePath, 0, nil);*/
    
//*    logUploader.UploadMessage();
//    CLogManager logManager;
//    logManager.Init();
//    logManager.*/

    CDeviceInfo di;
    bool bHostModify = di.isHostModified("www.punchbox.org");
    if (bHostModify)
        NSLog(@"punchbox host been modified!");
    bHostModify = di.isHostModified("localhost");
    if (bHostModify)
        NSLog(@"local host been modified!");
    char szHostName[] = "stat.punchbox.org";
    string strHost = di.getHostIPAddress(szHostName);
    printf("%s\n", strHost.c_str());

    bHostModify = di.checkIAPFExist();
/*    CDataDeliver cdd;
    cdd.InitDeliver("http://123.21.32.43", "testappid", "1.0.0", "jflksjafljdfsljdlskf");
    cdd.CommitUpdate("123", 3, &commitBack, (void *)self);*/
}

-(void)TestSendToSever:(NSString *)strFile{


//    PBAppark * apkShare = [PBAppark sharedSDK];
//    [apkShare setupApparkSDK:@"739743927fs" appVersion:@"1.6.4" deviceToken:@"yfuies9erw" logPath:nil];
    CApparkSDK *apparkSDK = _appark.apparkSDK;
//    apparkSDK->m_pLogManager->InitDictionaryData(eUserLogTypeGameData);
//    
//    CLocalSettingManager testManager;
//    testManager.Init(apparkSDK->m_strLogPath.c_str());
//    CLogManager logManager;
//    logManager.Init(apparkSDK, &testManager);
//    for (int i = 0; i<2; i++) {
//        if(i%2 == 0)
//            logManager.SaveLog([Wrapper makeTestJson], eUserLogTypeGameData);
//        else if(i%2 == 1)
//            logManager.SaveLog([Wrapper makeTestJson], eUserLogTypeAGD); 
//    }

    string strTest = "Massive Data Log Test Informations..........";
    for (int i = 0; i<200; i++)
    {
        apparkSDK->m_pLogManager->SaveMassiveDataLog((char *)strTest.c_str());
//        if(i%2 == 0)
//            apparkSDK->m_pLogManager->SaveLog([Wrapper makeTestJson], eUserLogTypeGameData);
//        else if(i%2 == 1)
//            apparkSDK->m_pLogManager->SaveLog([Wrapper makeTestJson], eUserLogTypeAGD); 
    }
//    apparkSDK->m_pLogManager->UploadGatherInfo();
//    apparkSDK->NotifyServerFirstRun();
//    apparkSDK->m_pLogManager->m_pLogUpLoader->TestUpLoadMessage([Wrapper makeTestJson]);
 
//    apparkSDK->m_pLogManager->SaveLogToFile();
//    [apkShare dealloc];
}

+(char *)makeTestJson
{
    CDictionaryDataGather dictTest, dictSub, dictSend;

    dictTest.InsertItem("StartTime", "2012-01-12 10:23:45");

    string strTest = dictTest.GetDescription();

    int nLength = strTest.length();

    int nBufferLen = [Wrapper xxteaEncode:(const unsigned char *)strTest.c_str() output:NULL size:nLength userKey:NULL];

    nBufferLen = [Wrapper base64Encode:(const unsigned char *)strTest.c_str() output:NULL size:nBufferLen];

    char * tempBuffer1 = (char *)malloc(nBufferLen + 4);
    memset(tempBuffer1, 0, nBufferLen + 4);
    char * tempBuffer2;// = (char *)malloc(nBufferLen + 4);

//    nLength = [Wrapper xxteaEncode:(const unsigned char *)strTest.c_str() output:(unsigned char *)tempBuffer1 size:strTest.length() userKey:NULL];
//    nLength = [Wrapper base64Encode:(const unsigned char *)tempBuffer1 output:(unsigned char *)tempBuffer2 size:nLength];


    time_t keytime;
    tm key_tm;
    keytime= time(NULL);

    key_tm = *localtime(&keytime);
    key_tm.tm_sec = 0;
    key_tm.tm_min = 10;
    key_tm.tm_hour = 9;
    key_tm.tm_yday = 2012-1900;
    key_tm.tm_mon = 5;
    key_tm.tm_mday = 18;
    key_tm.tm_isdst = 0;
    key_tm.tm_wday = 0;
    key_tm.tm_yday = 0;
    keytime = timelocal(&key_tm);

    sprintf(tempBuffer1, "%ld", keytime);

//    dictSend.InsertItem((const char *)tempBuffer1, (const char *)tempBuffer2);
    free(tempBuffer1);
//    free(tempBuffer2);

    dictSub.InsertItem("SubItem1", "test1");
    dictSub.InsertItem("SubItem2", 100);
    dictTest.CleanUp();
    dictTest.InsertItem("UserFloatInfo", 12.345);
    dictTest.InsertItem("SubJson", &dictSub);
    dictTest.InsertItem("LongValue", "LonglonglongLonglonglongLonglonglongLonglonglongLonglonglongLonglonglongLonglonglongLonglonglongLonglonglongLonglonglong");
    strTest = dictTest.GetDescription();

    nLength = strTest.length();

//    nBufferLen = [Wrapper xxteaEncode:(const unsigned char *)strTest.c_str() output:NULL size:nLength userKey:NULL];
//    nBufferLen = [Wrapper base64Encode:(const unsigned char *)strTest.c_str() output:NULL size:nBufferLen];
    tempBuffer1 = (char *)malloc(nLength + 4);
    memset(tempBuffer1, 0, nLength + 4);
//    nLength = [Wrapper xxteaEncode:(const unsigned char *)strTest.c_str() output:(unsigned char *)tempBuffer1 size:strTest.length() userKey:NULL];
//    nLength = [Wrapper base64Encode:(const unsigned char *)tempBuffer1 output:(unsigned char *)tempBuffer2 size:nLength];

//    nLength = CEncryptionManager::Base64EncodeConfuse((const unsigned char *)strTest.c_str(), &tempBuffer2, strTest.length());
//    keytime= time(NULL);
//    key_tm = *localtime(&keytime);
//    key_tm.tm_sec = 0;
//    key_tm.tm_min = 0;
//    key_tm.tm_hour = 19;
//    key_tm.tm_yday = 2012-1900;
//    key_tm.tm_mon = 6;
//    key_tm.tm_mday = 10;
//    key_tm.tm_isdst = 0;
//    key_tm.tm_wday = 0;
//    key_tm.tm_yday = 0;
//    keytime = timelocal(&key_tm);
//    sprintf(tempBuffer1, "%ld", keytime);
//
//    dictSend.InsertItem((const char *)tempBuffer1, (const char *)tempBuffer2);
    free(tempBuffer1);
//    free(tempBuffer2);
//
//    return (char *)dictSend.GetDescription();
    return (char *)dictTest.GetDescription().c_str();
}

+(void)TestSortVector{
    std::vector<std::string>::iterator iter;
    std::vector<std::string>    keys;
    keys.push_back("Log1329021360.apl");
    keys.push_back("Log1329062200.apl");
 
    keys.push_back("Log1329062189.apl");
 
    keys.push_back("Log1329062177.apl");
 
    keys.push_back("Log1329062149.apl");
 
    keys.push_back("Log1329062195.apl");
 
//    keys.push_back("Log1329021360.apl");
    
    
    std::vector<std::string> fileNames;
    for (iter = keys.begin(); iter != keys.end(); ++iter)
    {
        std::string keyStr = *iter;
        
//        printf("befor sort the file name is %s\r\n\n", keyStr.c_str());
        fileNames.push_back(keyStr);
    }   
    sort(fileNames.begin(), fileNames.end());
    for (iter = fileNames.begin(); iter != fileNames.end(); ++iter)
    {
        std::string keyStr = *iter;
        
//        printf("after sort the file name is %s\r\n\n", keyStr.c_str());
    } 
}
+(void)testLocalSettingManager
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cachesDirectory = [paths objectAtIndex:0];
    NSLog(@"%@", cachesDirectory);

    CApparkSDK apparkSDK;
    apparkSDK.m_strLogPath = [cachesDirectory cStringUsingEncoding:NSUTF8StringEncoding];

    CLocalSettingManager testManager;
    testManager.Init(apparkSDK.m_strLogPath.c_str(), (void *)&apparkSDK);

//    assert(testManager.SaveLocalSetting(testManager.m_strSettingFile.c_str()));
//    testManager.m_bUploadBy3G = 0;
//    testManager.m_nForceUploadTime = 10000;
//    testManager.m_nLastUpdateTime = 1;
//    testManager.m_nLogFileSizeLimit = 20 * 1024;
//    testManager.m_nUpdateGap = 18 * 60 * 60;
//    testManager.m_nUploadTimeBegin = 1;
//    testManager.m_nUploadTimeEnd = 1;
//
//    assert(testManager.ReadLocalSetting(testManager.m_strSettingFile.c_str()));
//    assert(testManager.m_bUploadBy3G != 0);
//    assert(testManager.m_nForceUploadTime != 10000);
//    assert(testManager.m_nLastUpdateTime != 1);
//    assert(testManager.m_nLogFileSizeLimit != 20 * 1024);
//    assert(testManager.m_nUpdateGap != 18 * 60 * 60);
//    assert(testManager.m_nUploadTimeBegin != 1);
//    assert(testManager.m_nUploadTimeEnd != 1);
}

+(void)testThreadFunc
{
//    pthread_t tid;
//    int nRet = pthread_create(&tid,
//                              (const pthread_attr_t *)NULL,
//                              (void *(*)(void *))&threadFunc,
//                              (void *)NULL);
//    NSLog(@"create thread return value : %d", nRet);

    int i;
    char szTemp[32];
    ZeroMemory(szTemp, 32);
    vector<string>::iterator iter;
    vector<string> testarray;
    vector<int>::iterator iterInt;
    vector<int> testintarray;
    for (i = 0; i < 10; i++)
    {
        sprintf(szTemp, "test string %d", i);
        string strTemp = szTemp;
        testarray.push_back(strTemp);
        if (i%2)
            testintarray.push_back(i);
    }

    i = 0;
    for (iterInt = testintarray.begin(); iterInt != testintarray.end(); iterInt++)
    {
        iter = testarray.begin();
        testarray.erase(iter + *iterInt - i);
        i++;
    }

    i = 0;
    for (iter = testarray.begin(); iter != testarray.end(); iter++)
    {
//        printf("%d : %s\n", i, iter->c_str());
        i++;
    }
}

void * threadFunc(void * param)
{
    for (int i = 0; i < 10; i++)
    {
        NSLog(@"thread running : %d", i);
        sleep(1);
    }
    NSLog(@"Thread function will exist");
    return NULL;
}

+(void)testCrash
{
    NSArray * myArray = [NSArray arrayWithObject:@"123"];
    NSLog(@"%@", [myArray objectAtIndex:1]);    
}


void FormatTime(time_t time, std::string& outputString)
{
    tm * key_tm;
    key_tm = localtime(&time);
    char timeStamp[32];
    sprintf(timeStamp, "%04d-%02d-%02d%s%02d:%02d:%02d", key_tm->tm_year+1900, 
            key_tm->tm_mon + 1, key_tm->tm_mday,"%20", 
            key_tm->tm_hour,key_tm->tm_min, key_tm->tm_sec);
    string temp = string(timeStamp);
    outputString = temp;
}

+(void)testTimeFormat
{
    time_t  tim = time(0); 
    clock_t tim_clock   = clock();
    
    char timeKey[32] = {0};
    sprintf(timeKey, "%ld_%lu",tim, tim_clock);
    std::string sTimeKey(timeKey);
    printf("\ntime key is : %s\n\n", sTimeKey.c_str());

    FormatTime(tim, sTimeKey);
    printf("\nformat time is : %s\n\n", sTimeKey.c_str());
}

+(void)testChaosInt
{
    CChaosNumber chaosInt;
    chaosInt.SetLongValue(0x12345678);
    long nTemp = chaosInt;
    NSLog(@"read out value : %X", (int)nTemp);
    chaosInt.SetFloatValue(12.34);
    float fTest, fTemp = chaosInt;
    NSLog(@"read out float : %f", fTemp);
    fTest = 100.0;
    fTest++;
    if (nTemp == fTest)
    {
        NSLog(@"OK");
    }
}


+(void)testDecodeDict:(NSString *)strFileName
{
    string strFile = [strFileName UTF8String];
    FILE * f = fopen("/var/mobile/Applications/D1B30DC9-B508-4D9D-8E88-4D5AF3B6F7C7/Library/Caches/ApparkLog/2.log", "rb");
    if (f)
    {
        int nSize = 0;
        fseek(f, 0, SEEK_END);
        nSize = ftell(f);
        rewind(f);
        if (nSize > 0)
        {
            char * pszBuf = (char *)malloc(nSize + 4);
            ZeroMemory(pszBuf, nSize + 4);
            nSize = fread(pszBuf, 1, nSize, f);
            fclose(f);
            CDictionaryDataGather dict;
            dict.InitWithDescription(pszBuf);
            vector<std::string>::iterator iter;
            vector<std::string> list;
            list = dict.GetAllMemberNames();
            for (iter = list.begin(); iter != list.end(); iter++)
            {
                const char * pszValue = dict.GetItemStringValue(iter->c_str());
                int nLength = strlen(pszValue);
                char * pszDecode = (char *)malloc(nLength + 4);
                ZeroMemory(pszDecode, nLength + 4);
                strcpy(pszDecode, dict.GetItemStringValue(iter->c_str()));
                CEncryptionManager::ConfuseString(pszDecode);
                NSLog(@"After confuse : %s", pszDecode);
                char * pszOring = (char *)malloc(nLength + 4);
                ZeroMemory(pszOring, nLength + 4);
                CEncryptionManager::Base64Decode((const unsigned char *)pszDecode, (unsigned char *)pszOring);
                NSLog(@"%s = %s", iter->c_str(), pszOring);
                ZeroMemory(pszDecode, nLength + 4);
                free(pszOring);
                free(pszDecode);
            }
            free(pszBuf);
        }
        fclose(f);
    }
    else
    {
        NSLog(@"File not find!\n");
    }
}

#include "FileManger_Wrapper.h"
+(void)deCodeLogs
{
    CFileManager fm;
    string strFull = fm.fullPathForFile("2.log");
    [Wrapper testDecodeDict:[NSString stringWithCString:strFull.c_str() encoding:NSUTF8StringEncoding]];
}

@end