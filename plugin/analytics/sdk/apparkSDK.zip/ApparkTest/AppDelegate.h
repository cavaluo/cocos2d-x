//
//  AppDelegate.h
//  ApparkTest
//
//  Created by 叶 博 on 12-1-31.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
