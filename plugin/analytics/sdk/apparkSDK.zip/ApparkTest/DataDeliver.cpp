//
//  DataDeliver.cpp
//  ApparkTest
//
//  Created by XiaoFeng on 12-4-7.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#include <iostream>
#include "DataDeliver.h"
#include "DictionaryDataGather.h"
#include "HttpRequest.h"
#include "GameDataManager.h"
#include <pthread.h>
#include "md5.h"

using namespace ApparkSDK;


CDataDeliver::CDataDeliver()
{
    m_bInitialized  = false;
    m_strHost.clear();
    m_strUDID.clear();
    m_strAppID.clear();
    m_strAppVersion.clear();
    m_strRequestURL.clear();
    m_strSaveFile.clear();
    m_strAsynDownloadUrl.clear();
    m_pCallbackFunc = NULL;
    m_pCallbackParam = NULL;
    m_pCommitCallBack = NULL;
    m_pCommitCallbackParam = NULL;
    m_pAsynCallback = NULL;
    m_pAsynCallbackParam = NULL;
    m_nCurrentVersion = VERSION_NOT_INIT;
}


void CDataDeliver::InitDeliver(const char * pszHost, const char * pszAppID, 
                               const char * pszAppVersion, const char * pszUDID)
{
    m_strHost = (NULL == pszHost ? "" : pszHost);
    m_strAppID = (NULL == pszAppID ? "" : pszAppID);
    m_strAppVersion = (NULL == pszAppVersion ? "" : pszAppVersion);
    m_strUDID = (NULL == pszUDID ? "" : pszUDID);

    m_bInitialized = (!m_strHost.empty() && !m_strAppID.empty() 
                      && !m_strAppVersion.empty() && !m_strUDID.empty());
}


bool CDataDeliver::IsInitialized()
{
    return m_bInitialized;
}


void * CDataDeliver::UpdateThreadFunction(void * pParam)
{
    CDataDeliver * pDataDeliver = (CDataDeliver *)pParam;
    pDataDeliver->DoUpdateFile();
    return NULL;
}


bool CDataDeliver::UpdateData(const char * pszFileID, const char * pszFullPathSaveName, 
                              DELIVER_CALLBACK pCallBackFunc, void * pCallbackParam, 
                              int nCurVersion)
{
    bool bRet = false;
    if (m_bInitialized && pszFileID && pszFullPathSaveName && pCallBackFunc && pCallbackParam)
    {
        m_strSaveFile = pszFullPathSaveName;
        m_pCallbackFunc = pCallBackFunc;
        m_pCallbackParam = pCallbackParam;
        m_nCurrentVersion = nCurVersion;
        m_strFileID = pszFileID;

        m_strRequestURL = m_strHost + PARAM_URL_UDID;
        m_strRequestURL += m_strUDID;
        m_strRequestURL += "&";
        m_strRequestURL += PARAM_URL_FILEID;
        m_strRequestURL += pszFileID;
        m_strRequestURL += "&";
        m_strRequestURL += PARAM_URL_APPID;
        m_strRequestURL += m_strAppID + "&";
        m_strRequestURL += PARAM_URL_APPVER;
        m_strRequestURL += m_strAppVersion;

        pthread_t tid;
        int nRet = pthread_create(&tid,
                                  (const pthread_attr_t *)NULL,
                                  &UpdateThreadFunction,
                                  (void *)this);
        bRet = !nRet;
#ifdef DEBUG
        if (bRet)
            printf("\n%s\n", "Data deliver thread function start OK.");
        else
            printf("\n%s\n", "Data deliver thread function start failed!");
#endif
    }

    return bRet;
}


void CDataDeliver::DoUpdateFile()
{
    bool bUpdateResult = false;
    char * pszBuffer = NULL;
    int nNewVersion = VERSION_NOT_INIT;
    CGameDataManager * pDataManager = new CGameDataManager();
    pDataManager->DownloadToBuffer(m_strRequestURL.c_str(), &pszBuffer, EncryptOperationTypeNone);
    if (pszBuffer && *pszBuffer)
    {
        CDictionaryDataGather descript;
        descript.InitWithDescription(pszBuffer);
        const char * pszStatus = descript.GetItemStringValue(DATA_DESCRIPT_STATUS);
        if (0 == strcmp(pszStatus, DATA_DESCRIPT_STATUSOK))
        {
            CDictionaryDataGather * pFileInfo = descript.GetSubDictionary(DATA_DESCRIPT_INFO);
#ifdef DEBUG
            printf("\n\n%s\n\n", pFileInfo->GetDescription().c_str());
#endif
            nNewVersion = pFileInfo->GetItemIntValue(DATA_DESCRIPT_VERSION, VERSION_NOT_INIT);
            if (nNewVersion > m_nCurrentVersion)
            {
                pszStatus = pFileInfo->GetItemStringValue(DATA_DESCRIPT_URL);
                if (pszStatus && *pszStatus)
                {
                    bUpdateResult = pDataManager->DownloadGameData(pszStatus, (char *)m_strSaveFile.c_str(), EncryptOperationTypeNone);
                }
            }
            SafeDeletePtr(pFileInfo);
        }
        SafeFreePtr(pszBuffer);
    }
    m_pCallbackFunc(m_pCallbackParam, nNewVersion, bUpdateResult, m_strFileID.c_str());
    delete pDataManager;
}


bool CDataDeliver::CommitUpdate(const char * pszFileID, int nVersion, COMMIT_CALLBACK pCommitCallback, void * pCallbackParam)
{
    bool bRet = false;
    if (pszFileID && *pszFileID && pCallbackParam)
    {
        char szTemp[48] = {0};
        sprintf(szTemp, "%d", nVersion);

        string strParams = PARAM_URL_UDID;
        strParams += m_strUDID;
        strParams += "&";
        strParams += PARAM_URL_FILEID;
        strParams += pszFileID;
        strParams += "&";
        strParams += PARAM_URL_NUMBER;
        strParams += szTemp;
        strParams += "&";
        strParams += PARAM_URL_TIMEKEY;
        sprintf(szTemp, "%ld", time(NULL));
        strParams += szTemp;
        strParams += "&";
        strParams += PARAM_URL_MD5KEY;

        ZeroMemory(&szTemp[0], 48);
        lutil_md5_data((const unsigned char *)strParams.c_str(), strParams.length(), szTemp);
        m_strCommitURL = COMMIT_URL + strParams + szTemp;

        m_pCommitCallBack = pCommitCallback;
        m_pCommitCallbackParam = pCallbackParam;
        m_strCommitID = pszFileID;

        pthread_t tid;
        int nRet = pthread_create(&tid,
                                  (const pthread_attr_t *)NULL,
                                  &CommitThreadFunction,
                                  (void *)this);
        bRet = !nRet;
#ifdef DEBUG
        if (bRet)
            printf("\n%s\n", "Commit thread function start OK.");
        else
            printf("\n%s\n", "commit thread function start failed!");
#endif
    }
    return bRet;
}


void CDataDeliver::DoCommit()
{
    char * pszResult = NULL;
    bool bResult = false;
    const char * pszURL = m_strCommitURL.c_str();
#ifdef DEBUG
    printf("%s", pszURL);
#endif
    CGameDataManager dm;
    if(dm.DownloadToBuffer(pszURL, &pszResult, EncryptOperationTypeNone))
    {
        if (pszResult)
        {
            if (strstr(pszResult, "ok"))
            {
                bResult = true;
            }
            //没有malloc就不需要 free(pszResult);
        }
    }

    m_pCommitCallBack(m_pCommitCallbackParam, bResult, m_strCommitID.c_str());
}


void * CDataDeliver::CommitThreadFunction(void * pParam)
{
    CDataDeliver * pDataDeliver = (CDataDeliver *)pParam;
    pDataDeliver->DoCommit();
    return NULL;
}


bool CDataDeliver::LoadLocalFile(const char * pszFullPath, char ** ppszBuffer)
{
    bool bRet = false;
    *ppszBuffer = NULL;
    FILE * f = fopen(pszFullPath, "rb");
    if (f)
    {
        fseek(f, 0, SEEK_END);
        size_t nSize = ftell(f);
        rewind(f);
        if (nSize)
        {
            char * pszTempBuf = (char *)malloc(nSize + 4);
            ZeroMemory(pszTempBuf, nSize + 4);
            nSize = fread(pszTempBuf, 1, nSize, f);
            if (nSize)
            {
                CGameDataManager::Decrypt((const unsigned char *)pszTempBuf, (unsigned char **)ppszBuffer, NULL);
                if (*ppszBuffer)
                    bRet = true;
            }
            free(pszTempBuf);
        }
        fclose(f);
    }
    return bRet;
}


bool CDataDeliver::SaveLocalFile(const char * pszFullPath, char * pszBuffer)
{
    bool bRet = false;
    char * pszEncryptData = NULL;
    FILE * f = fopen(pszFullPath, "wb+");
    if (f)
    {
        
        if(CGameDataManager::Encrypt((const unsigned char *)pszBuffer, (unsigned char **)&pszEncryptData, NULL))
        {
            int nSize = fwrite(pszEncryptData, 1, strlen(pszEncryptData), f);
            if (nSize)
                bRet = true;
        }
        SafeFreePtr(pszEncryptData);
        fclose(f);
    }

    return bRet;
}


bool CDataDeliver::AsynDownloadToBuffer(const char * pUrl, ASYNDOWN_CALLBACK pAsynCallback,
                                        void * pCallbackParam)
{
    bool bRet = false;
    if (pAsynCallback && pCallbackParam)
    {
        m_strAsynDownloadUrl.assign(pUrl);
        m_pAsynCallback = pAsynCallback;
        m_pAsynCallbackParam = pCallbackParam;

        pthread_t tid;
        int nRet = pthread_create(&tid,
                                  (const pthread_attr_t *)NULL,
                                  &AsynDownThreadFunction,
                                  (void *)this);
        bRet = !nRet;
#ifdef DEBUG
        if (bRet)
            printf("\n%s\n", "Data deliver thread function start OK.");
        else
            printf("\n%s\n", "Data deliver thread function start failed!");
#endif
    }

    return bRet;
}


void * CDataDeliver::AsynDownThreadFunction(void * pParam)
{
    CDataDeliver * pDataDeliver = (CDataDeliver *)pParam;
    pDataDeliver->doAsynDownload();
    return NULL;
}


void CDataDeliver::doAsynDownload()
{
    char * pszResult = NULL;
    bool bResult = false;
    const char * pszURL = m_strAsynDownloadUrl.c_str();
#ifdef DEBUG
    printf("Asyn download URL : %s\n", pszURL);
#endif
    CGameDataManager dm;
    if(dm.DownloadToBuffer(pszURL, &pszResult, EncryptOperationTypeNone))
        bResult = true;

    m_pAsynCallback(m_pAsynCallbackParam, bResult, pszResult);
}


