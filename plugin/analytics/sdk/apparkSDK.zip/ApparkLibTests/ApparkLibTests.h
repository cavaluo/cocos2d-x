//
//  ApparkLibTests.h
//  ApparkLibTests
//
//  Created by 叶 博 on 12-1-31.
//  Copyright (c) 2012年 PunchBox. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface ApparkLibTests : SenTestCase

@end
