var searchData=
[
  ['logevent',['logEvent',['../classcom_1_1flurry_1_1android_1_1_flurry_agent.html#aa64abbb33f0ac309732a663ee611423d',1,'com.flurry.android.FlurryAgent.logEvent(String eventId)'],['../classcom_1_1flurry_1_1android_1_1_flurry_agent.html#a998ee28bb819f444c178f9a6952cbcbc',1,'com.flurry.android.FlurryAgent.logEvent(String eventId, Map&lt; String, String &gt; parameters)'],['../classcom_1_1flurry_1_1android_1_1_flurry_agent.html#a3a428996cc9511c3eb3775c57c1b9c74',1,'com.flurry.android.FlurryAgent.logEvent(String eventId, boolean timed)'],['../classcom_1_1flurry_1_1android_1_1_flurry_agent.html#ab0c7ea87d901c481663a287c32348baa',1,'com.flurry.android.FlurryAgent.logEvent(String eventId, Map&lt; String, String &gt; parameters, boolean timed)']]]
];
