Welcome to Flurry!

The Flurry Android Agent allows you to track the usage and behavior of your application on users' phones for viewing in the Flurry system. You can also choose to use the Flurry platform to serve advertisements inside your application and earn revenue from your users. It is designed to  be as easy as possible with a basic setup complete in under 5 minutes.

To set up Flurry Analytics to track user behavior, see the documentation available at: http://support.flurry.com/index.php?title=Analytics/GettingStarted/Android

To set up Flurry Ads to earn revenue from advertisements, see the documentation available at: http://support.flurry.com/index.php?title=Publisher/GettingStarted/TechnicalQuickStart/Android

Please let us know if you have any questions. If you need any help, just email support@flurry.com!

Cheers,
The Flurry Team
http://www.flurry.com
support@flurry.com
